/* --------------------------- (C) COPYRIGHT 2020 Fortiortech ShenZhen -----------------------------
    File Name      : MotorControl.h
    Author         : Fortiortech  Appliction Team
    Version        : V1.0
    Date           : 2020-04-11
    Description    : This file contains motor contorl parameter used for Motor Control.
----------------------------------------------------------------------------------------------------
                                       All Rights Reserved
------------------------------------------------------------------------------------------------- */
/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __MOTORCONTROL_H_
#define __MOTORCONTROL_H_


/* Exported types -------------------------------------------------------------------------------*/

typedef enum
{
    mcReady     = 0,
    mcInit      = 1,
    mcCharge    = 2,
    mcTailWind  = 3,
    mcStart     = 4,
    mcRun       = 5,
    mcStop      = 6,
    mcFault     = 7,
    mcBrake     = 8,
}MotStaType;

typedef union
{
  uint8 SetMode;                                                              // 整个配置模式使能位
    struct
    {
        uint8 CalibFlag        :1;                                              // 电流校准的标志位
        uint8 ChargeSetFlag    :1;                                              // 桥驱测试标志位
        uint8 StartSetFlag     :1;                                              // 启动配置标志位
    } SetFlag;
}MotStaM;



/* Exported variables ---------------------------------------------------------------------------*/
extern MotStaType mcState;
extern MotStaM    McStaSet;
extern uint16     TimeCnt;
/* Exported functions ---------------------------------------------------------------------------*/
extern void MC_Control(void);


#endif
