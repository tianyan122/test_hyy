/* --------------------------- (C) COPYRIGHT 2020 Fortiortech ShenZhen -----------------------------
    File Name      : Self_Learn.h
    Author         : 自学习
    Version        : V1.0
    Date           : 2020-04-11
    Description    : This file contains .C file function used for Motor Control.
----------------------------------------------------------------------------------------------------
                                       All Rights Reserved
------------------------------------------------------------------------------------------------- */
#ifndef __SELF_LEARN_H_
#define __SELF_LEARN_H_


/* Exported types ------------------------------------------------------------*/
typedef struct
{
    uint8 LearnFlag;  //自学习标志 为1，开始自学习 15自学习成功，16自学习失败
    uint16 LearnTime; // over自学习时间计数器 计时使用
} SelfLearn;          //故障检测

extern SelfLearn idata AGS_SelfLearn;
extern void Self_Learn(void);

#endif