#include <MyProject.h>
uint16 WatchDogtime=0;
/*-----------------------------------------------------------------------------------
	Function Name ：WatchDogConfig(Value ,Status)
	Description   ：看门狗定时函数初始化，看门狗使能和复位使能，定时配置
	Input         ：Value--定时时间，单位ms，最小定时时间8ms，最大定时1800ms
                  Statue--使能控制，Disable或Enable	
  Output				：None
-----------------------------------------------------------------------------------*/
void WatchDogConfig(void) 	
{
	WDT_ARR = ((uint16)(65532-(uint32)1000*32768/1000) >> 8);  //200MS
}


/*-----------------------------------------------------------------------------------
	Function Name ：WatchDogRefresh(Value ,Status)
	Description   ：喂狗
	Input         ：None
  Output				：None
-----------------------------------------------------------------------------------*/
void WatchDogRefresh(void)
{
	SetBit(WDT_CR, WDTRF);			
}
