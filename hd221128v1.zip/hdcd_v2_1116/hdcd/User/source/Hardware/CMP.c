/*  --------------------------- (C) COPYRIGHT 2020 Fortiortech ShenZhen -----------------------------
    File Name      : CMP.c
    Author         : Fortiortech  Appliction Team
    Version        : V1.0
    Date           : 2020-04-11
    Description    : This file contains .C file function used for Motor Control.
    ----------------------------------------------------------------------------------------------------
                                       All Rights Reserved
    ------------------------------------------------------------------------------------------------- */
#include "MyProject.h"

/*  ----------------------------------------------------------------------------------------------*/
/*  Function Name  : CMP0_Init
    /*  Description    : CMP0初始化
    /*  Date           : 2020-09-06
    /*  Parameter      : None
    /*  描述：配置为使用内部虚拟中性点的模式
    /*  ----------------------------------------------------------------------------------------------*/
void CMP0_Open_Init(void)
{
    // CMP_CR0：CMP0 CMP1 CMP2都不产生中断

    SetBit(P1_AN, P14 | P16); // CMP0/1 Pin设置为模拟模式  +
    SetBit(P2_AN, P21);       // CMP2 Pin设置为模拟模式  +

    SetReg(CMP_CR0, CMP0IM0 | CMP0IM1 | CMP1IM0 | CMP1IM1 | CMP2IM0 | CMP2IM1, 0x00);
    SetReg(CMP_CR2, CMP0MOD0 | CMP0MOD1, CMP0MOD0);            // CMPMOD：01,内置虚拟中心点电阻的BEMF模式
    SetReg(CMP_CR2, CMP0SEL0 | CMP0SEL1, 0x00);                // CMP0SEL：00,  3比较器轮询模式
    SetReg(CMP_CR1, CMP0HYS0 | CMP0HYS1 | CMP0HYS2, 0X07); //迟滞电压选择 100: +-5mV
    SetBit(CMP_CR2, CMP0EN);                                   //开三个比较器
    SetReg(CMP_CR3, SAMSEL1 | SAMSEL0, SAMSEL1);               // SAMSEL：10,只在ON时采样
    CMP_SAMR = 0x84;
   // SetReg(CMP_CR1, HALLSEL, HALLSEL); // HALL信号输入P1.4/P1.6/P2.1                                        // CMP_SAMR:  比较器的延迟“开启”采样时间 和 延迟“关闭”采样时间

}

/*  -------------------------------------------------------------------------------------------------
    Function Name : void CMP3_Iint(void)
    Description   : 比较器3初始化,用于硬件过流保护
    Input         : 无
    Output        : 无

    运放正端               (+)----- P20/P23/P27(可选)
    运放负端               (-)----- 1.片外分压电阻(P2.6输入)； 2.片内DAC
    -------------------------------------------------------------------------------------------------*/

uint16 test;
void CMP3_Init(void)
{
    SetBit(P2_AN, P27);        // CMP3 Pin设置为模拟模式  +
    ClrBit(CMP_CR1, CMP3MOD1); // 00-->P27-单比较器模式    01-->P20/P23-双比较器模式
    ClrBit(CMP_CR1, CMP3MOD0); // 1X-->P20/P23/P27-三比较器模式
    /******************************
            0: 正常模式，DAC输出电压范围为0到VREF
            1: 半电压转换模式，DAC输出电压范围为VHALF到VREF
    ****************************/
    ClrBit(DAC_CR, DACMOD);
    test = DAC_OvercurrentValue;
    /*设置DAC过流值*/
    if (DAC_OvercurrentValue % 2 == 0)
    {
        ClrBit(DAC1_DR, DAC0_DR_0);
    }
    else
    {
        SetBit(DAC1_DR, DAC0_DR_0); /* DAC0最低位设置 */
    }
    DAC0_DR = (DAC_OvercurrentValue >> 1); /* DAC0高8位设置 */
    SetBit(DAC_CR, DAC0_1EN);              /*母线电流保护触发信号源 0-CMP3,1-INT0*/
    ClrBit(EVT_FILT, EFSRC);               /*DAC0 使能*/
    /*
        触发硬件保护后硬件关闭驱动输出MOE配置
        00--MOE不自动清零
        01--MOE自动清零
        10--在DRV计数器的上溢下溢事件和每隔 10us 自动使能MOE
        11--在DRV计数器的上溢下溢事件和每隔 5us 自动使能MOE
    */
    ClrBit(EVT_FILT, MOEMD1);
    ClrBit(EVT_FILT, MOEMD0);
    /*
        母线电流保护时间滤波宽度
        00-不滤波
        01-4cpu clock
        10-8cpu clock
        11-16cpu clock
    */
    SetBit(EVT_FILT, EFDIV1);
    SetBit(EVT_FILT, EFDIV0);
    /*CMP3运放输出端中断设置*/
    ClrBit(CMP_CR1, CMP3HYS);                        /* CMP3的迟滞配置 */
    ClrBit(CMP_CR1, CMP0HYS2 | CMP0HYS1 | CMP0HYS0); /* 无迟滞 */
    SetBit(CMP_CR1, CMP3EN);                         /* CMP3 Enable */
}

/*  ----------------------------------------------------------------------------------------------*/
/*  Function Name  : CMP3_Interrupt_Init
    /*  Description    : CMP3中断配置
    /*  Date           : 2020-09-06
    /*  Parameter      : None
    /*  ----------------------------------------------------------------------------------------------*/
void CMP3_Interrupt_Init(void)
{
    ClrBit(CMP_SR, CMP3IF);
    /*
        比较器中断模式配置
        00: 不产生中断
        01: 上升沿产生中断
        10: 下降沿产生中断
        11: 上升/下降沿产生中断
    */
    ClrBit(CMP_CR0, CMP3IM1);
    SetBit(CMP_CR0, CMP3IM0); /* 上升沿触发硬件过流中断 */
    PCMP31 = 1;
    PCMP30 = 1; // 中断优先级别3
}
