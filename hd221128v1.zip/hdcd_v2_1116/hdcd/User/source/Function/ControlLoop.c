/*  -------------------------- (C) COPYRIGHT 2020 Fortiortech ShenZhen ---------------------------*/
/*  File Name      : ControlLoop.c
/*  Author         : Fortiortech  Appliction Team
/*  Version        : V1.0
/*  Date           : 2021-03-21
/*  Description    : 电机控制环路
/*  ----------------------------------------------------------------------------------------------*/
/*                                     All Rights Reserved
/*  ----------------------------------------------------------------------------------------------*/

#include "MyProject.h"

uint16 xdata ControlLoopOut;
int16 HW_One_PI(int16 Xn1)
{
    PI3_EK = Xn1;          //填入EK
    SetBit(PI_CR, PI3STA); // Start PI
    while (ReadBit(PI_CR, PIBSY))
        ;
    return PI3_UKH;
}

uint16 speed1 = 0;
uint16 speed2 = 0;
uint16 DRV_value = 0;
int16 PI1_value = 0;
int16 PI2_value = 0;
uint8 INCe = 0;
void Duty_Function(void)
{

    /*切换至硬件运行状态以后在进行DUTY的调整*/
    if (BL_S.BLDCSetFlag == 2)
    {
        MotorSpeed.DelayPeriod++;
        if (MotorSpeed.DelayPeriod > SPEED_LOOP_TIME)
        {
            MotorSpeed.DelayPeriod = 0;
            if (BL_S.PItime < 5000)
                BL_S.PItime++;

            if (BL_S.PItime > 100)
            {
                MotorSpeed.DelayPeriod = 0;
                speed1 = TIM1_BCOR;
                speed2 = TIM1__BCCR;
                DRV_value = DRV_DR;
                /* 启动500ms内pi计算的增量不能过大 */
                /* PI计算使用电流计算的方法 */
                if (((speed1 > (MotorSpeed.TargetValue))) || /* 速度小于设定的度速 */
                    ((speed1 < (MotorSpeed.TargetValue)))    /* 速度大于设定的度速 */
                )
                {
                    PI1_value = HW_One_PI(speed1 - MotorSpeed.TargetValue);
                    DRV_DR = PI1_value; // HW_One_PI
                }
            }
            else
            {
                if (mcFocCtrl.mcDcbusFlt<V95_VALUE)/* 电压低于9.5V */
                {
                     DRV_DR = DRV_DR + 2;
                }
                else if (mcFocCtrl.mcDcbusFlt<V105_VALUE)/* 电压低于10.5V */
                {
                     DRV_DR = DRV_DR + 1;
                }
               
            }
        }
    }
}
