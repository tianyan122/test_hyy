///* --------------------------- (C) COPYRIGHT 2020 Fortiortech ShenZhen -----------------------------
//    File Name      : TailWind.c
//    Author         : Ray
//    Version        : V0.1
//    Date           : 2021-04-07
//    Description    : 顺逆风处理函数
//----------------------------------------------------------------------------------------------------
//                                       All Rights Reserved
//------------------------------------------------------------------------------------------------- */
//#include <MyProject.h>


//TailWind_TypeDef   xdata  Tailwind;

///*转向判断数组*/
//unsigned char code Hall_CWNext[6]  = {3, 6, 2, 5, 1, 4};   
///*

//		W      V      U      
//                         ---》  电机正转转对应的HALL跳变为 4 - 5 - 1 - 3 - 2 - 6 - 4
//  HALLC  HALLB  HALLA

//*/




//void WindFunction(void)
//{
//		/*
//		Tips: 注意，在电机到达一定转速时才会建立足够的反电动势波形，尤其针对反电动势系数较小的散热风扇电机，故电机位于低速震荡的情况可以使用BCCR或者BCOR的读数
//		对电机当前的状态进行判断。
//		*/
//		Tailwind.Last_Wind_BCCR      = Tailwind.Wind_BCCR;                                  //记录“上上一个扇区”的BCCR数值
//		Tailwind.Wind_BCCR           = TIM1_BCOR;                                          //记录“上一个扇区”的BCCR数值
//		

//		//电机处于静止状态下启动 
//		if( ReadBit(TIM1_SR, T1BOIF) && (Tailwind.Wind_FR == 0)) 
//		{				
//				if(Tailwind.Stop_CNT++>= 3)
//				{						
//						Tailwind.Stop_CNT = 0;
//						Tailwind.Wind_FR  = 0;    
//						Tailwind.CW_CNT   = 0;			
//						Tailwind.CCW_CNT  = 0;			
//						Wind_Brake();						
//						mcFocCtrl.State_Count = Low_Speed_BrakeTime;
//						mcState               = mcCharge;
//				}	
//				ClrBit(TIM1_SR, T1BOIF);
//		}

//		if( Tailwind.Wind_FR == 0x01)                
//		{						
//				 if(Tailwind.Wind_BCCR <= Motor_BldcWind_SpeedUp)                                                              //超速
//				 {
//						//超速不做处理，等待自然降速
//				 }
//				 else if( (Tailwind.Wind_BCCR > Motor_BldcWind_SpeedUp) && (Tailwind.Wind_BCCR <= Motor_BldcWind_SpeedDown) )  //顺风启动转速
//				 {										 
//						Wind_Start();
//					  
//				 }
//				 else                                                                                                           //低速
//				 {

//							Tailwind.Stop_CNT = 0;
//					 		Tailwind.Wind_FR  = 0;    
//						  Tailwind.CW_CNT   = 0;			
//						  Tailwind.CCW_CNT  = 0;			
//							Wind_Brake();									 
//							mcFocCtrl.State_Count = Low_Speed_BrakeTime;
//							mcState =  mcCharge;
//				 }																	 
//		}
//		else if(Tailwind.Wind_FR == 0x02)
//		{		
//			  if( Tailwind.Wind_BCCR <= Motor_BldcWind_CCWSpeed )
//				{

//				}
//				else
//				{

//						 Wind_Brake();
//						 Tailwind.Wind_FR  = 0;    
//						 Tailwind.Stop_CNT = 0;
//						 Tailwind.CW_CNT   = 0;			
//						 Tailwind.CCW_CNT  = 0;				
//						 mcFocCtrl.State_Count = CCW_Speed_BrakeTime;
//						 mcState =  mcCharge;					

//				}
//			
//		}

//}

////顺逆风检测初始化
//void TailWindInit(void)
//{
//	
//// CMP_CR2： 有内置电阻3比较器模式，负短接虚拟中性点，正端接三相反电动势，比较结果输出至 CMP0OUT CMP1OUT CMP2OUT
//	ClrBit(CMP_CR2, CMP0MOD1);    
//    SetBit(CMP_CR2, CMP0MOD0);	
//	SetBit(CMP_CR2, CMP0EN);	         //CMP0使能
///*----采样区间
//00;    在ON和OFF均采样，没有延迟采样开启
//01;    只在OFF采样，根据CMP_SAMR延迟采样开启
//10;    只在ON采样，根据CMP_SAMR延迟采样开启
//11;    在ON和OFF均采样，根据CMP_SAMR延迟采样开启
//----*/
//	ClrBit(CMP_CR3, SAMSEL1);                         	       //只在ON采样
//	ClrBit(CMP_CR3, SAMSEL0);
//	
//// CMP_SAMR:  比较器的延迟“开启”采样时间 和 延迟“关闭”采样时间
//	CMP_SAMR = 0xcc;      

//	
///*-------------------------------------------------------------------------------------------------
//Tim1_CR0
//[7]    T1RWEN            T1RCEN操作允许位
//[6:5]  T1CFLT1 T1CFLT0   00:1个换相时间  01:2个换相平均时间  10:4个换相平均时间  11:8个换相平均时间  作为60度基准
//[4]    T1FORC            60度强制换相使能  0：禁止  1：使能
//[3:2]  T1OPS1  T1OPS0    TIM1_DBRx寄存器写入DRV_CMR寄存器的传输方式，即写入时序事件/换相
//	                       00：软件写UPD 或者 写TIM1_CR4  01:Reload定时器上溢中断触发(延迟换相结束后触发)
//	                       10：位置检测触发(有感方波)     11:保留
//[1]    T1BCEN            基本定时器的计数器使能     0:禁止  1：启动
//[0]    T1RCEN            重载定时器的计数器使能     0:禁止  1：启动 （软件必须写RWEN为1才能操作T1RCEN）
//-------------------------------------------------------------------------------------------------*/
//	SetBit(TIM1_CR0, 0x80);     //RCEN禁止
//	
//	ClrBit(TIM1_CR0, T1BCEN);   //0:禁止基本定时器  1:使能基本定时器
//	
//	SetBit(TIM1_CR0, T1CFLT1);
//	SetBit(TIM1_CR0, T1CFLT0);  //对换相周期进行滤波，8次平均
//	
//	ClrBit(TIM1_CR0, T1FORC);   //禁止强制换相
//	
//  ClrBit(TIM1_CR0, T1OPS1);   //比较器换相
//	SetBit(TIM1_CR0, T1OPS0);
//	
///*-------------------------------------------------------------------------------------------------
//Tim1_CR1
//[7]    T1BAPE   TIM1__BARR自动装载使能     0:不使能  1：使能 
//       (当基本定时器因为位置检测事件或者写入时序事件复位时，将60度基准值存至TIM1__BARR寄存器)
//[6:0]  BSEL 屏蔽续流角度选择
//-------------------------------------------------------------------------------------------------*/
//	ClrBit(TIM1_CR1, T1BAPE);                           //不使能
//	ANGLE_MASK(2);                                     //续流屏蔽
///*-------------------------------------------------------------------------------------------------
//Tim1_CR2
//[7]    T1BRS   基本定时器复位源选择     0:写入时序复位和60度强制自动换相复位  1：位置检测复位
//[6:0]  CSEL    换相角度选择
//-------------------------------------------------------------------------------------------------*/
//	SetBit(TIM1_CR2, T1BRS);                           //顺逆风检测阶段，需要依靠PDIF中断复位
//	ANGLE_DELAY(2);                                   //延迟换向
//	
///*-------------------------------------------------------------------------------------------------
//Tim1_CR3
//[7]    保留
//[6:4]  T1PSC    定时器时钟分频选择
//[3:2]  T1TIS    输入源（TI0/TI1/TI2）选择
//         00：GPIO作为输入，根据CMP_CR1[7]选择（P1.4/P1.6/P2.1）还是（P0.2/P3.7/P3.6），CMP_SR的结果通过GPIO产生
//			   01：比较器（CMP0/CMP1/CMP2）的输出作为输入，CMP_SR的结果通过CMP产生
//				 10：ADC
//       	 11：比较器（CMP0/CMP1/CMP2）&ADC	比较器优先级高
//[1:0]  T1INM    输入TI0/TI1/TI2噪声脉宽选择
//         00: 不滤波  01：8个时钟周期滤波  10：32个时钟周期滤波  11：64个时钟周期滤波
//-------------------------------------------------------------------------------------------------*/
//	ClrBit(TIM1_CR3, T1PSC2);
//	SetBit(TIM1_CR3, T1PSC1);                             //010    6MHz   
//	ClrBit(TIM1_CR3, T1PSC0);

///***************采样相关设置***************/
//	ClrBit(TIM1_CR3, T1TIS1);                            //输入来源CMP
//  SetBit(TIM1_CR3, T1TIS0);    	

///***************采样相关设置***************/
//  ClrBit(TIM1_CR3, T1INM1);
//	SetBit(TIM1_CR3, T1INM0);                            //8个时钟周期滤波
//	
//	
///*-------------------------------------------------------------------------------------------------
//Tim1_DBRx
//[14:12]  T1CPE   跳变沿检测设置以及使能
//[11:0]           输出设置选择
//-------------------------------------------------------------------------------------------------*/
//	TIM1_DBR1 = UH_PWM_VL_ON + CMP_W_DO;
//	TIM1_DBR2 = UH_PWM_WL_ON + CMP_V_UP;
//	TIM1_DBR3 = VH_PWM_WL_ON + CMP_U_DO;
//	TIM1_DBR4 = VH_PWM_UL_ON + CMP_W_UP;
//	TIM1_DBR5 = WH_PWM_UL_ON + CMP_V_DO;
//	TIM1_DBR6 = WH_PWM_VL_ON + CMP_U_UP;
//	TIM1_DBR7 = UVW_OFF  +  CMP_UVW_ALL;	
//	
///*-------------------------------------------------------------------------------------------------
//TIM1_IER            TIMER1中断控制
//[7]      T1UPD （当OPS=00时，软件对UPD写一触发数据传输）
//[6]      T1MAME 
//[5]      保留
//[4]      T1BOIE    0：禁止基本定时器上溢中断  1：使能基本定时器上溢中断
//[3]      T1ROIE    0: 禁止重载定时器上溢中断  1: 使能重载定时器上溢中断
//[2]      T1WTIE    0: 禁止写入时序中断        1: 使能写入时序中断
//[1]      T1PDIE    0: 禁止位置检测中断        1: 使能位置检测中断          (过零点检查)
//[0]      T1BDIE    0: 禁止屏蔽续流结束中断    1: 使能屏蔽续流结束中断
//-------------------------------------------------------------------------------------------------*/
//	ClrBit(TIM1_IER, T1UPD);
//	ClrBit(TIM1_IER, T1MAME);
//	ClrBit(TIM1_IER, T1ADIE);
//  ClrBit(TIM1_IER, T1BOIE);                       //发生上溢事件，意味着电机转速很慢或者已经停止
//	ClrBit(TIM1_IER, T1ROIE);
//	ClrBit(TIM1_IER, T1WTIE);
//	SetBit(TIM1_IER, T1PDIE);                       //位置检测事件，电机在转动；可在通过对转速的分析来判断电机状态
//	ClrBit(TIM1_IER, T1BDIE);
//	
///*-------------------------------------------------------------------------------------------------
//TIM1_SR            TIMER1中断标志位
//[7]      保留
//[6]      保留 
//[5]      T1ADIF    0: ADC中断标志位
//[4]      T1BOIF    0：基本定时器上溢中断  
//[3]      T1ROIF    0: 重载定时器上溢中断标记
//[2]      T1WTIF    0: 写入时序中断标记
//[1]      T1PDIF    0: 位置检测中断标记          (过零点检查)
//[0]      T1BDIF    0: 屏蔽续流结束中断标记
//-------------------------------------------------------------------------------------------------*/
// TIM1_SR = 0x00;

//	
///*-------------------------------------------------------------------------------------------------   
//[15:0]  TIM1_BCOR   捕获基本定时器计数值滤波值。主要用来读取数据
//[15:0]  TIM1__BCNTR 基本定时器的计数值，用于60度换相时间的计数
//[15:0]  TIM1__BCCR  捕获基本定时器计数值
//[15:0]  TIM1__BARR  基本定时器自动重载值
//[15:0]  TIM1__RARR  重载定时器自动重载值
//[15:0]  TIM1__RCNTR 重载定时器计数值
//[15:0]  TIM1__ITRIP 滤波后的母线电流 默认ADC通道4取值范围（0,32767）
//-------------------------------------------------------------------------------------------------*/
//  TIM1_BCOR   = 0;
//	TIM1__BCNTR = 0;
//	TIM1__BCCR  = 0;	
//	TIM1__BARR  = 65535;			
//  TIM1__RARR  = 65535;
//	TIM1__RCNTR = 0;
//// TIM1__ITRIP   只读寄存器


// SetBit(TIM1_CR0, T1BCEN);            //使能timer1的基本定时器
// SetBit(TIM1_CR0, T1RWEN|T1RCEN);     //使能重装载定时器
// 
////设置TIM1中断优先级       设置中断优先级为0
//	PTIM11 = 1;             
//	PTIM10 = 0;
//  TIM1_CR4 = 7;	

//}






////顺风处理函数
//void TailWindFunction(void)
//{
//	
//	
//  Tailwind.Last_Hall_Status    = Tailwind.Hall_Status;                                //记录上一次的hall状态值 
//	Tailwind.Hall_Status         = CMP_SR & 0x07;                                       //读取当前的CMP_OUT值
//	WindFR_DetermineFunction();                                                         //判断电机的转向
//	

//}








///*根据霍尔信号判断转向*/
///*
//		状态：  初始状态——0x00  正转——0x01		反转——0x02   


//		W      V      U      
//                         ---》  电机正转转对应的HALL跳变为 4 - 5 - 1 - 3 - 2 - 6 - 4
//  HALLC  HALLB  HALLA

//eg: 
//		                                Hall_CWNext[6]  =  {3, 6, 2, 5, 1, 4}

//    该数组中存放对应霍尔信号状态下正转时下一排的霍尔状态值

//		若电机正转，且当前霍尔信号读数为“5”，下一拍对应的霍尔信号区间应该为“1”，上一拍的霍尔信号值为“4”
//		则 Hall_CWNext[4-1] = 5 既当前的状态

//		若电机反转，且当前霍尔信号读数为“5”，下一拍对应的霍尔信号区间应该为“4”，上一拍的霍尔状态为“1”
//    则 Hall_CWNext[5-1] = 1既为上一拍的状态

//*/

//void WindFR_DetermineFunction(void)
//{

//		if( Tailwind.Hall_Status == Hall_CWNext[ Tailwind.Last_Hall_Status  - 1 ] )                        //正转
//		{

//           if(Tailwind.CW_CNT++>= 3)
//					 {
//						 Tailwind.CW_CNT  = 3;
//						 Tailwind.Wind_FR = 0x01;                         //正转标志位
//						 
//					 }
//					 Tailwind.CCW_CNT = 0;
//			     
//		}
//		else if( Tailwind.Last_Hall_Status == Hall_CWNext[ Tailwind.Hall_Status  - 1 ] )                   //反转
//		{
//			
//					if(Tailwind.CCW_CNT++ >= 3)
//					{
//						Tailwind.CCW_CNT  = 3;
//						Tailwind.Wind_FR  = 0x02;                        //反转标志位
//						
//					}
//					Tailwind.CW_CNT = 0;
//		}

//}




////顺风刹车函数
//void Wind_Brake(void)
//{
//    TIM1_CR0 = 0;
//    TIM1_CR1 = 0;
//    TIM1_CR2 = 0;
//    TIM1_CR3 = 0;
//    TIM1_CR4 = 7;
//    TIM1_IER = 0;
//    FOC_CR1    = 0x00;
//    DRV_DR     = 0;    //刹车力度
//    ClrBit(DRV_CR, FOCEN);
//    Driver_Init();
//    ClrBit(DRV_CR, OCS);
//    DRV_DR     = DRV_ARR + 1;  //刹车力度
//    DRV_CMR   |= 0x0015;
//    MOE        = 1;
//}





////顺逆风检测初始化
//void WindStartInit(void)
//{
//	
//// CMP_CR0：CMP0 CMP1 CMP2都不产生中断
//		ClrBit(CMP_CR0, CMP0IM0);   
//    ClrBit(CMP_CR0, CMP0IM1);	
//	
//		ClrBit(CMP_CR0, CMP1IM0);   
//    ClrBit(CMP_CR0, CMP1IM1);	
//	
//		ClrBit(CMP_CR0, CMP2IM0);   
//    ClrBit(CMP_CR0, CMP2IM1);	
//	
//// CMP_CR1： 

//	
//// CMP_CR2： 有内置电阻3比较器模式，负短接虚拟中性点，正端接三相反电动势，比较结果输出至 CMP0OUT CMP1OUT CMP2OUT
//		ClrBit(CMP_CR2, CMP0MOD1);    
//    SetBit(CMP_CR2, CMP0MOD0);	
//	
//		ClrBit(CMP_CR2, CMP0SEL1);    
//    ClrBit(CMP_CR2, CMP0SEL0);	
//	
//	  SetBit(CMP_CR2, CMP0EN);	
//		
//// CMP_CR3： 使能比较器CMP0~2和ADC的采样功能
///*----采样区间
//00;    在ON和OFF均采样，没有延迟采样开启
//01;    只在OFF采样，根据CMP_SAMR延迟采样开启
//10;    只在ON采样，根据CMP_SAMR延迟采样开启
//11;    在ON和OFF均采样，根据CMP_SAMR延迟采样开启
//----*/
//	ClrBit(CMP_CR3, SAMSEL1);                         	       //只在ON采样
//	ClrBit(CMP_CR3, SAMSEL0);
//	
//// CMP_CR4： CMP0_FS -- CMP1/2功能转移使能
//	ClrBit(CMP_CR4, CMP0_FS);                                  // 0 - 不使能  1 - 使能，仅当使用虚拟中性点时有效
//	
//// CMP_SAMR:  比较器的延迟“开启”采样时间 和 延迟“关闭”采样时间
//	CMP_SAMR = 0x00;     
//	
///*-------------------------------------------------------------------------------------------------
//Tim1_CR0
//[7]    T1RWEN            T1RCEN操作允许位
//[6:5]  T1CFLT1 T1CFLT0   00:1个换相时间  01:2个换相平均时间  10:4个换相平均时间  11:8个换相平均时间  作为60度基准
//[4]    T1FORC            60度强制换相使能  0：禁止  1：使能
//[3:2]  T1OPS1  T1OPS0    TIM1_DBRx寄存器写入DRV_CMR寄存器的传输方式，即写入时序事件/换相
//	                       00：软件写UPD 或者 写TIM1_CR4  01:Reload定时器上溢中断触发(延迟换相结束后触发)
//	                       10：位置检测触发(有感方波)     11:保留
//[1]    T1BCEN            基本定时器的计数器使能     0:禁止  1：启动
//[0]    T1RCEN            重载定时器的计数器使能     0:禁止  1：启动 （软件必须写RWEN为1才能操作T1RCEN）
//-------------------------------------------------------------------------------------------------*/
//	SetBit(TIM1_CR0, 0x80);     //RCEN禁止
//	
//	ClrBit(TIM1_CR0, T1BCEN);   //0:禁止基本定时器  1:使能基本定时器
//	
//	ClrBit(TIM1_CR0, T1CFLT1);
//	SetBit(TIM1_CR0, T1CFLT0);  //1个平均换相时间作为60度的时间基准--在启动强拖阶段，对换相周期不进行滤波
//	
//	ClrBit(TIM1_CR0, T1FORC);   //禁止强制换相
//	
//  ClrBit(TIM1_CR0, T1OPS1);   //软件换相，在启动的强拖阶段需要进行软件换向
//	SetBit(TIM1_CR0, T1OPS0);
//	
///*-------------------------------------------------------------------------------------------------
//Tim1_CR1
//[7]    T1BAPE   TIM1__BARR自动装载使能     0:不使能  1：使能 
//       (当基本定时器因为位置检测事件或者写入时序事件复位时，将60度基准值存至TIM1__BARR寄存器)
//[6:0]  BSEL 屏蔽续流角度选择
//-------------------------------------------------------------------------------------------------*/
//	ClrBit(TIM1_CR1, T1BAPE);                           //不使能
//	ANGLE_MASK(15);                                     //续流屏蔽
//	
///*-------------------------------------------------------------------------------------------------
//Tim1_CR2
//[7]    T1BRS   基本定时器复位源选择     0:写入时序复位和60度强制自动换相复位  1：位置检测复位
//[6:0]  CSEL    换相角度选择
//-------------------------------------------------------------------------------------------------*/
//	SetBit(TIM1_CR2, T1BRS);                           //强拖阶段，基本定时器按照软件换向之间的时间计数
//	ANGLE_DELAY(15);                                   //延迟换向

///*-------------------------------------------------------------------------------------------------
//Tim1_CR3
//[7]    保留
//[6:4]  T1PSC    定时器时钟分频选择
//[3:2]  T1TIS    输入源（TI0/TI1/TI2）选择
//         00：GPIO作为输入，根据CMP_CR1[7]选择（P1.4/P1.6/P2.1）还是（P0.2/P3.7/P3.6），CMP_SR的结果通过GPIO产生
//			   01：比较器（CMP0/CMP1/CMP2）的输出作为输入，CMP_SR的结果通过CMP产生
//				 10：ADC
//       	 11：比较器（CMP0/CMP1/CMP2）&ADC	比较器优先级高
//[1:0]  T1INM    输入TI0/TI1/TI2噪声脉宽选择
//         00: 不滤波  01：8个时钟周期滤波  10：32个时钟周期滤波  11：64个时钟周期滤波
//-------------------------------------------------------------------------------------------------*/
//	ClrBit(TIM1_CR3, T1PSC2);
//	SetBit(TIM1_CR3, T1PSC1);                             //100    6MHz   
//	ClrBit(TIM1_CR3, T1PSC0);

///***************采样相关设置***************/
//	ClrBit(TIM1_CR3, T1TIS1);                            //输入来源CMP
//  SetBit(TIM1_CR3, T1TIS0);    	

///***************采样相关设置***************/
//  ClrBit(TIM1_CR3, T1INM1);
//	SetBit(TIM1_CR3, T1INM0);                            //8个时钟周期滤波
//	
//	
///*-------------------------------------------------------------------------------------------------
//Tim1_CR4
//[7:3]  RSV     
//[6:0]  T1CST    换相状态机
//-------------------------------------------------------------------------------------------------*/
//	TIM1_CR4 = 1;                                       // 启动的第一拍
//	
///*-------------------------------------------------------------------------------------------------
//Tim1_DBRx
//[14:12]  T1CPE   跳变沿检测设置以及使能
//[11:0]           输出设置选择
//-------------------------------------------------------------------------------------------------*/
//	TIM1_DBR1 = UH_PWM_VL_ON + CMP_W_DO;
//	TIM1_DBR2 = UH_PWM_WL_ON + CMP_V_UP;
//	TIM1_DBR3 = VH_PWM_WL_ON + CMP_U_DO;
//	TIM1_DBR4 = VH_PWM_UL_ON + CMP_W_UP;
//	TIM1_DBR5 = WH_PWM_UL_ON + CMP_V_DO;
//	TIM1_DBR6 = WH_PWM_VL_ON + CMP_U_UP;
//	TIM1_DBR7 = UVW_OFF  +  CMP_UVW_ALL;
//	
///*-------------------------------------------------------------------------------------------------
//TIM1_IER            TIMER1中断控制
//[7]      T1UPD （当OPS=00时，软件对UPD写一触发数据传输）
//[6]      T1MAME 
//[5]      保留
//[4]      T1BOIE    0：禁止基本定时器上溢中断  1：使能基本定时器上溢中断
//[3]      T1ROIE    0: 禁止重载定时器上溢中断  1: 使能重载定时器上溢中断
//[2]      T1WTIE    0: 禁止写入时序中断        1: 使能写入时序中断
//[1]      T1PDIE    0: 禁止位置检测中断        1: 使能位置检测中断          (过零点检查)
//[0]      T1BDIE    0: 禁止屏蔽续流结束中断    1: 使能屏蔽续流结束中断
//-------------------------------------------------------------------------------------------------*/
//	ClrBit(TIM1_IER, T1UPD);
//	ClrBit(TIM1_IER, T1MAME);
//	ClrBit(TIM1_IER, T1ADIE);
//  ClrBit(TIM1_IER, T1BOIE);                       //发生上溢事件，意味着电机转速很慢或者已经停止
//	ClrBit(TIM1_IER, T1ROIE);
//	ClrBit(TIM1_IER, T1WTIE);
//	SetBit(TIM1_IER, T1PDIE);                       //位置检测事件，电机在转动；可在通过对转速的分析来判断电机状态
//	ClrBit(TIM1_IER, T1BDIE);
//	
///*-------------------------------------------------------------------------------------------------
//TIM1_SR            TIMER1中断标志位
//[7]      保留
//[6]      保留 
//[5]      T1ADIF    0: ADC中断标志位
//[4]      T1BOIF    0：基本定时器上溢中断  
//[3]      T1ROIF    0: 重载定时器上溢中断标记
//[2]      T1WTIF    0: 写入时序中断标记
//[1]      T1PDIF    0: 位置检测中断标记          (过零点检查)
//[0]      T1BDIF    0: 屏蔽续流结束中断标记
//-------------------------------------------------------------------------------------------------*/
// TIM1_SR = 0x00;

//	
///*-------------------------------------------------------------------------------------------------   
//[15:0]  TIM1_BCOR   捕获基本定时器计数值滤波值。主要用来读取数据
//[15:0]  TIM1__BCNTR 基本定时器的计数值，用于60度换相时间的计数
//[15:0]  TIM1__BCCR  捕获基本定时器计数值
//[15:0]  TIM1__BARR  基本定时器自动重载值
//[15:0]  TIM1__RARR  重载定时器自动重载值
//[15:0]  TIM1__RCNTR 重载定时器计数值
//[15:0]  TIM1__ITRIP 滤波后的母线电流 默认ADC通道4取值范围（0,32767）
//-------------------------------------------------------------------------------------------------*/
//  TIM1_BCOR   = 0;
//	TIM1__BCNTR = 0;
//	TIM1__BCCR  = 0;	
//	TIM1__BARR  = 65500;			
//  TIM1__RARR  = 65500;
//	TIM1__RCNTR = 0;
//// TIM1__ITRIP   只读寄存器


// SetBit(TIM1_CR0, T1BCEN);            //使能timer1的基本定时器
// SetBit(TIM1_CR0, T1RWEN|T1RCEN);     //使能重装载定时器
// 
////设置TIM1中断优先级       设置中断优先级为0
//	PTIM11 = 1;             
//	PTIM10 = 0;

//}

////顺风启动
//void Wind_Start(void)
//{
//	
//	if(Tailwind.StartStep == 0)
//	{
//		WindStartInit();
//		Tailwind.StartStep = 1;

//	}
//	else if( Tailwind.StartStep == 1)
//	{

//		 if(TIM1_CR4 == 6)
//		 {
//			 Tailwind.StartStep = 0;
//			 BL_S.BLDCSetFlag = 2;
//			 SetBit(CMP_CR3, SAMSEL1);                         	       //只在ON采样
//	     ClrBit(CMP_CR3, SAMSEL0);
//			 CMP_SAMR = cmp_samr;  
//			 DRV_DR = (DRV_ARR *0.1);
//			 ControlLoopOut = DRV_DR;					            //给定当前DUTY，防止输出突然降低
//			 mcState =  mcRun; 
//			 MOE = 1;

//		 }
//	}



//}






