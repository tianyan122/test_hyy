/* --------------------------- (C) COPYRIGHT 2020 Fortiortech ShenZhen -----------------------------
	File Name      : MotorControl.c
	Author         : Ray
	Version        : V0.1
	Date           : 2021-01-18
	Description    : 状态机以及状态机函数.
----------------------------------------------------------------------------------------------------
									   All Rights Reserved
------------------------------------------------------------------------------------------------- */
#include <MyProject.h>
/* Private variables ----------------------------------------------------------------------------*/
volatile MotStaType mcState;
volatile MotStaM McStaSet;
volatile uint16 tese;
volatile uint8 NewRun = 0; //首次运行标志

/* -------------------------------------------------------------------------------------------------
	Function Name  : MC_Control
	Description    : 电机控制状态机
	Date           : 2021-01-18
	Parameter      : None
------------------------------------------------------------------------------------------------- */
void MC_Control(void)
{

	switch (mcState)
	{
	case mcReady:
	{
		Motor_Ready();
		if ((MotorSpeed.FlagONOFF == 1) && (mcCurOffset.OffsetFlag == 1))
		{
			mcFocCtrl.State_Count = 0;
			mcState = mcInit;
			Uset.Brake_flag = 2;
		}
	}
	break;

	case mcInit:
	{
		if (mcFocCtrl.State_Count == 0) //为了使得初始化只进行一次，思考使用联合体 McStaSet.SetFlag.ChargeSetFlag 设置标志位
		{
			Motor_Init();					   //电机相关参数初始化
			if (Uset.Set_post > Uset.New_post) /*设置AGS运动方向*/
			{
				FR = CLOSE;
			}
			else
			{
				FR = OPEN;
			}
			if (F_CCW ? (FR == OPEN) : (FR == CLOSE)) //强拖阶段还要再次设置正反转设置
			{										  //自动换向之后不用在对换向信息修改
				ClrBit(DRV_CR, DDIR);				  // 反转					   // 正转/* code */
			}
			else
			{
				SetBit(DRV_CR, DDIR); // 反转
			}
			mcState = mcStart;			 /* 进入启动状态 */
			BEMFDetect.BEMFRun = 0;		 /* 清除手动检测的状态 */
			Motor_Hold();				 /* 锁步 */
			mcFocCtrl.State_Count = 100; /* 运行开始之前先锁步一下保证启动成功率 */
		}
	}
	break;

	case mcStart:
	{
		if (mcFocCtrl.State_Count == 0)
		{
			Motor_Start(); //电机启动函数相关变量初始化
			if (MotorSpeed.FlagONOFF == 0)
			{
				MOE = 0;
				mcState = mcBrake;
				Uset.Brake_flag = 2;
			}
			if (BL_S.BLDCSetFlag == 2)
			{
				mcState = mcRun;
			}
		}
	}
	break;

	case mcRun:
	{
		if (MotorSpeed.FlagONOFF == 0)
		{
			MOE = 0;
			mcState = mcBrake;
		}
	}
	break;

	case mcStop:
	{
		if ((BEMFDetect.BEMFRun == 0) && (mcFocCtrl.State_Count == 0))
		{
			MOE = 0;
			TIM1_CR0 = 0;
			TIM1_CR1 = 0;
			TIM1_CR2 = 0;
			AGS_DATA.MoveStatus = 0;
			BEMFInit(); /* 初始化BEMF */
			BEMFDetect.BEMFRun = 1;
		}

		if (MotorSpeed.FlagONOFF == 1)
		{
			mcState = mcReady;
			Uset.Brake_flag = 1;
		}
	}
	break;

	case mcBrake:
	{ /* Uset.Brake_flag：，(0错误状态) ，(1锁定电机)，(2停止输出进入手动模式) ，(3锁定模式再次启动) */
		BEMFDetect.BEMFRun = 0;
		AGS_DATA.MoveStatus = 0;
		BL_S.BLDCSetFlag = 0; /* 清除电机运行标志位 */
		if ((MotorSpeed.FlagONOFF == 0) &&
			(Uset.Brake_flag == 1)) /* 电机锁定除了正常运行堵转外还有自学习 */
		{
			Uset.Brake_flag = 3; /* 电机锁定标志位 */
			Motor_Hold();
		}
		else if ((MotorSpeed.FlagONOFF == 0) &&
				 (Uset.Brake_flag == 2)) /* 电机锁定除了正常运行堵转外还有自学习 */ /* 电机进入手动检测模式 */
		{
			mcState = mcStop;
			MOE = 0;
			ClrBit(DRV_CR, DRVEN); // 关闭DRV
			DRV_CMR = 0;
			mcFocCtrl.State_Count = 300; /* 释放弹力，防止再次触发手动模式 */
		}

		if ((MotorSpeed.FlagONOFF == 1) && (Uset.Brake_flag == 3)) /* 等待再次启动 */
		{
			mcState = mcReady;
			MOE = 0;
			Uset.Brake_flag = 2;
			ClrBit(DRV_CR, DRVEN); // 关闭DRV
			DRV_CMR = 0;
		}
	}
	break;

	case mcFault:
	{
		MOE = 0;
		mcState = mcStop;
	}
	break;

	default:
		break;
	}
}
