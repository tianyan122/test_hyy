/*  --------------------------- (C) COPYRIGHT 2020 Fortiortech ShenZhen -----------------------------
	File Name      : Interrupt.c
	Author         : Fortiortech  Appliction Team
	Version        : V1.0
	Date           : 2020-04-10
	Description    : This file contains .C file function used for Motor Control.
	----------------------------------------------------------------------------------------------------
									   All Rights Reserved
	------------------------------------------------------------------------------------------------- */
#include "MyProject.h"

void motoronoff(void);
uint16 xdata spidebug[4] = {0};
/*  -------------------------------------------------------------------------------------------------
	Function Name  : LVW_TSD_INT
	Description    : LVW interrupt，芯片低压预警中断
	Date           : 2020-04-10
	Parameter      : None
	------------------------------------------------------------------------------------------------- */
void LVW_TSD_INT(void) interrupt 0 // LVW & TSD interrupt
{
	if (ReadBit(LVSR, LVWIF))
	{
		if (ReadBit(LVSR, LVWF))
		{
			ClrBit(LVSR, LVWF);
		}

		ClrBit(LVSR, LVWIF);
	}

	if (TSDIF)
	{
		TSDIF = 0;
	}
}

/*  -------------------------------------------------------------------------------------------------
	Function Name  : PO0_INT
	Description    : PO0_INT外部中断0，
	Date           : 2020-04-10
	Parameter      : None
	------------------------------------------------------------------------------------------------- */
void PO0_INT(void) interrupt 1 /* LIN同步信号检测*/
{
	uint16 time = 0;
	if (IF0)
	{
		if (GP01 == 0) /*接收到下降沿*/
		{
			if (Lin.RUN_flag == 0)
			{
				Lin.RUN_flag = 1;
				ClrBit(TIM3_CR1, T3EN); /*先停止计数*/
				TIM3__CNTR = 1;			/*清除time3的计数器*/
				Lin.Timeblank = 0;
				SetBit(TIM3_CR1, T3EN); /*使能计数*/
			}
		}
		else
		{
			if (Lin.RUN_flag == 1)
			{							/*低电平持续时间满足13位的同步间隔断要求*/
				ClrBit(TIM3_CR1, T3EN); /*先停止计数*/
				Lin.Timeblank = TIM3__CNTR;
				/*19200对应的同步时间 13位  0.677MS  2031计数值  同步阶段误差5%可以接收*/
				if ((Lin.Timeblank < 3230) && (Lin.Timeblank > 1830))
				{
					Lin.RUN_flag = 11;
					MODE_UART(); /*切换到串口模式*/
				}
				else
				{
					Lin.Err = ERR_BLANK;
					Lin.RUN_flag = 0;
				}
				/*数据超时错误使用防止无法出串口中断 */
				/*数一组数据最大不会停留7ms 根据发送调度表计算*/
				TIM3__CNTR = 1;			/*清除time3的计数器*/
				SetBit(TIM3_CR1, T3EN); /*使能计数*/
			}
		}
		IF0 = 0; /* clear P01 interrupt flag*/
	}
}

void DRV_ISR(void) interrupt 3
{
	static uint8 Section = 0;

	if (ReadBit(DRV_SR, DCIF)) /* 比较中断*/
	{
		BL_S_Function(&BL_S); /*启动函数*/
		Duty_Function();	  /* Duty调整函数   速度闭环计算*/

		if (Uset.Current_flag == 1)
		{
			if (mcFocCtrl.CurrentCnt < 128)
			{
				mcFocCtrl.RunCurrent = mcFocCtrl.RunCurrent + TIM1__ITRIP;
				mcFocCtrl.CurrentCnt++;
			}
			else if (mcFocCtrl.CurrentCnt == 128)
			{
				mcFocCtrl.RunCurrent = mcFocCtrl.RunCurrent >> 7; /* 获取电机运行电流 */
				mcFocCtrl.CurrentCnt++;
				Uset.Current_flag = 0;
			}
		}
		/**************计换相次数 记录位置移动圈数************************/
		if ((mcState == mcRun) || (mcState == mcStart))
		{
			if (TIM1_CR4 != Section) /*记圈*/
			{
				if (FR == CLOSE)
				{
					Uset.New_post++;
				}
				else
				{
					Uset.New_post--;
				}
			}
			Section = TIM1_CR4;
		}
		SetReg(DRV_SR, 0xFF, SYSTIE | FGIF | DCIM1 | SYSTIF);
	}
}

/* -------------------------------------------------------------------------------------------------
	Function Name  : TIM1_INT
	Description    : TIM1为方波专用
	Date           : 2020-04-10
	Parameter      : None
------------------------------------------------------------------------------------------------- */
void TIM1_INT(void) interrupt 5
{
	if (ReadBit(TIM1_SR, T1PDIF)) //位置检测中断标志位
	{
		ClrBit(TIM1_SR, T1PDIF);
	}
	if (ReadBit(TIM1_SR, T1WTIE)) //写入时序中断，TIM1_DBR写入DRV_CMR 寄存器和 CMP_CR2 寄存器的 CMP0_SEL
	{
		ClrBit(TIM1_SR, T1WTIE);
		StartPos = TIM1_CR4 & 0x07;
	}
}
/* -------------------------------------------------------------------------------------------------
	Function Name  : TIM2_INT
	Description    : 顺风检测是BMFS 转速检测，方向检测使用
	Date           : 2020-04-10
	Parameter      : None
------------------------------------------------------------------------------------------------- */
void TIM2_INT(void) interrupt 4
{
	if (ReadBit(TIM2_CR1, T2IR))
	{
		ClrBit(TIM2_CR1, T2IR);
	}
	if (ReadBit(TIM2_CR1, T2IP))
	{
		ClrBit(TIM2_CR1, T2IP);
	}
	if (ReadBit(TIM2_CR1, T2IF)) //溢出中断,用于判断静止,时间为319ms。
	{
		// if()/* 长时间没有检测到比较换向开始清空 */

		ClrBit(TIM2_CR1, T2IF);
	}
}
/*---------------------------------------------------------------------------*/
/*  Name     :   void CMP_ISR(void) interrupt7
	/* Input    :   NO
	/* Output   :   NO
	/* Description: 比较器0，1，2中断，检测电机当前的转动状态
/*---------------------------------------------------------------------------*/
void CMP_ISR(void) interrupt 7
{
	if (ReadBit(CMP_SR, CMP0IF) || ReadBit(CMP_SR, CMP1IF) || ReadBit(CMP_SR, CMP2IF)) //当检测到比较器中断时
	{
		/* -----通过BEMF做顺逆风检测功能----- */
		BEMFDetectFunc();
		ClrBit(CMP_SR, CMP0IF | CMP1IF | CMP2IF);
	}
}
/*---------------------------------------------------------------------------*/
/*  Name     :   void TIM3_INT(void) interrupt 9
	/* Input    :   NO
	/* Output   :   NO
	/* Description: LIN总线计时使用
/*---------------------------------------------------------------------------*/
void TIM3_INT(void) interrupt 9
{
	if (ReadBit(TIM3_CR1, T3IP)) /*比较中断事件*/
	{
		ClrBit(TIM3_CR1, T3IP);
	}
	if (ReadBit(TIM3_CR1, T3IR)) /*比较中断事件*/
	{
		if (Lin.RUN_flag == 1)
		{
			Lin.Err = ERR_BLANK;
			// Cutover_IO; /*同步间隔段超时错误*/
		}
		else if (Lin.RUN_flag == 11)
		{

			Lin.Err = ERR_SYNC; /*同步信号超时错误*/
		}
		else if (Lin.RUN_flag == 12)
		{
			Lin.Err = ERR_PID; /*接收ID信号超时错误*/
		}
		else if (Lin.RUN_flag == 13)
		{
			Lin.Err = ERR_DATA; /*接收数据超时错误*/
		}
		Cutover_IO; /*切换回io模式*/
		ClrBit(TIM3_CR1, T3IR);
	}

	if (ReadBit(TIM3_CR1, T3IF)) /*溢出中断事件*/
	{
		ClrBit(TIM3_CR1, T3IF);
	}
}
/*  -------------------------------------------------------------------------------------------------
	Function Name  : SYStick_INT
	Description    : 1ms定时器中断（SYS TICK中断），用于处理附加功能，如控制环路响应、各种保护等。中断优先级低于FO中断和FOC中断。
	Date           : 2020-04-10
	Parameter      : None
	---------------------------	 ---------------------------------------------------------------------- */

uint16 test_DCbus;
void SYStick_INT(void) interrupt 10
{
	// SYS TICK中断
	if (ReadBit(DRV_SR, SYSTIF))
	{
		SetBit(ADC_CR, ADCBSY);
		Fault_Stall();
		if (mcFocCtrl.State_Count)
			mcFocCtrl.State_Count--;
		if (StickTime) /* 1ms定时时基 */
			StickTime--;
		if (AGS_SelfLearn.LearnTime) /* 自学习计时 */
			AGS_SelfLearn.LearnTime--;
		if (Uset.Post_time) /* 运行时间计时 */
			Uset.Post_time--;
		if (WatchDogtime) /* 看门狗计时 */
			WatchDogtime--;
		if (Lin.Time4s) /*lin总线4s无信号的休眠计数器 为0表示可以进入休眠*/
			Lin.Time4s--;

		if (Uset.run_time) /*lin总线4s无信号的休眠计数器 为0表示可以进入休眠*/
			Uset.run_time--;
		if (Uset.ManualDelayTime)
			Uset.ManualDelayTime--;

		if (!Lin.Time4s)
		{
			AGS_DATA.FaultCommunicationError = 1; /*置一表示总线4s无信号开始休眠*/
			Lin.Sleep_flag = 1;
		}
		SetReg(DRV_SR, 0xFF, SYSTIE | FGIF | DCIF | DCIM1);
	}
}

/*  -------------------------------------------------------------------------------------------------
	Function Name  : TIM4_INT
	Description    : TIM4主要用于150度方波的插入
	Date           : 2021-03-30
	Parameter      : None
	------------------------------------------------------------------------------------------------- */
void TIM4_INT(void) interrupt 11
{

	uint8 TIM1_CR4_150;

	if (ReadBit(TIM4_CR1, T4IF))
	{
		ClrBit(TIM4_CR1, T4EN); //关闭TIM4
		ClrBit(TIM4_CR1, T4IF); //清除上溢中断标志位
	}
}

/*  -------------------------------------------------------------------------------------------------
	Function Name  : CMP3_INT
	Description    : CMP3：硬件比较器过流保护，关断输出，中断优先级最高
	Date           : 2020-04-10
	Parameter      : None
	------------------------------------------------------------------------------------------------- */
void CMP3_INT(void) interrupt 12
{
	if (ReadBit(CMP_SR, CMP3IF))
	{
		ClrBit(CMP_SR, CMP3IF);
	}
}
/* -------------------------------------------------------------------------------------------------
	Function Name  : LIN_IRQ
	Description    : LIN中断函数
	Date           : 2020-07-20
	Parameter      : None
------------------------------------------------------------------------------------------------- */
uint8 uar[10] = 0;
uint8 uar_len = 0;
void LIN_IRQ(void) interrupt 14
{
	uint8 i = 0;
	/* -----检测是否收到帧头----- */
	if (ReadBit(UT2_CR, UT2RI)) /*接收完成中断*/
	{
		ClrBit(UT2_CR, UT2RI); /*清除接收中断*/
		switch (Lin.RUN_flag)
		{
		/**************接收同步信号***********/
		case 11:
		{
			Lin.Syn = UT2_DR;
			if (Lin.Syn == 0X55) /*同步信号*/
			{
				Lin.RUN_flag = 12;
			}
			else
			{
				Lin.Err = 9;
			}
		}
		break;

		/**************注意此处接收的不是ID而是PID，PID是id加前两位校验组合得到的注意,注意,注意,注意,注意***********/
		case 12:
		{
			Lin.PID = UT2_DR;
		  uar_len=0;
			/*--------数据列表-----------*/
			LIN_list(Lin.PID);
			Lin.Count = 0;
			/*--------数据列表-----------*/
		}
		break;

		/************接收数据阶段数据长度一定要匹配上***********/
		case 13:
		{
			if (Lin.Count == Lin.Leng) /*接收最后一个校验位 注意接收的数据长度Leng一定要正确*/
			{
				Lin.Check = UT2_DR;
				if (Lin.Check == LinCheck(Lin.CheckMode, Lin.PID, Lin.Leng, &Lin.Data))
				{
					//Lin.Err = 0;
					if (Lin.Err_Count)
						Lin.Err_Count--; /* 接收到正常数据错误计数减一*/

					/*--------数据列表处理-----------*/
					ReceiveSYS(Lin.PID);
					/*--------数据列表处理-----------*/
				}
				else /*数据校验错误*/
				{
					Lin.Err = 5; /*暂时不做错检测*/
				}
				Cutover_IO;
			}
			else /*接收定长数据*/
			{
				Lin.Data[Lin.Count] = UT2_DR;
				Lin.Count++;
			}
		}
		break;

			/***********无效数据接收***********/
		case 14:
			if (Lin.Count <= Lin.Leng)
			{
				Lin.Check = UT2_DR;
				if (Lin.Count == Lin.Leng)
				{
					Cutover_IO;
				}
				Lin.Count++;
			}
			break;

			/************数据发送***********/
		case 23:
			if(uar_len < 10)
				uar_len++;
			uar[uar_len] = UT2_DR;
			
			if(uar_len == 9)
			{
				Cutover_IO;
				for(i = 0;i<9;i++)
				{
					if(uar[i+1]!= DMAudata[i])
					{
						Lin.Err = ERR_CHECK;
					}
				}
			}
			break;

		/************接收到其他数据返回IO检测***********/
		default:
		{
			//  Cutover_IO;
			break;
		}
		}
	}
}


void DMA_IRQ1(void) interrupt 15
{
	if (ReadBit(DMA0_CR0, DMAIF))
	{
		ClrBit(DMA0_CR0, DMAIF);
//		Cutover_IO; /*切换回io模式*/
	}
}
