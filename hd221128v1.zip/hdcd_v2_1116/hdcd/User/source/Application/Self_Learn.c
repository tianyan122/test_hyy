/* --------------------------- (C) COPYRIGHT 2020 Fortiortech ShenZhen -----------------------------
    File Name      : Self_Learn.c
    Author         : 自学习
    Version        : V1.0
    Date           : 2020-04-11
    Description    : This file contains .C file function used for Motor Control.
----------------------------------------------------------------------------------------------------
                                       All Rights Reserved
------------------------------------------------------------------------------------------------- */
#include <MyProject.h>

SelfLearn idata AGS_SelfLearn; //格栅自学习使用变量
/*****************************************************************************
    \brief          : Self_learn自学习 自学习完成时格栅处于关闭状态
    \param          : None
    \retval         : None
        /*主动自学习：A. 上电复位 B. 热保护*
    /*被动自学习：ECM信号包括堵转、多点火周期等*
    /*自学习电机直接打开到最大位置,运行，中间发生 堵转认为到达最大位置并重置位置*
    /*自学习电机直接打开到最大位置,运行，中间发生 堵转认为到达最大位置并重置位置*
/*全流程学习标志位，表示要学习整个机械的运行角度*
*****************************************************************************/
void Self_Learn(void)
{
    static uint8 LearnAll_Flag = 0; /*全流程学习标志位，表示要学习整个机械的运行角度*/

    /* 自学习方式先关闭格栅，在打开格栅
       停止2s之后全部打开   ，故障必须要在自学习成功之后才能清除 */

    switch (AGS_SelfLearn.LearnFlag)
    {
        /*********关闭位置点学习*********/
    case 0:                               /* 需要开始自学习 */
        if (AGS_SelfLearn.LearnTime == 0) /*上电等待自检结束 */
        {
            Uset.Run_cont = 0;                             /* 多次运行之后进行自学习 */
            AGS_DATA.SelflearnStatus = 1;                  /* 0=成功 1=自学  2=失败 */
            Uset.Run_flag = 0;                             /* 清除正常运行的标志位 */
            FR = CLOSE;                                    /* 设置转动方向为关闭 */
            Uset.New_post = 0;                             /* 重置当前位置 为最大 */
            Uset.Set_post = SELF_MAX_POST;                 /* 设置目标位置 为关闭 */
            MotorSpeed.FlagONOFF = 1;                      /* 启动电机 */
            MotorSpeed.TargetValue = Motor_Run_Speed_BCOR; /* 设置运行duty */
            StallFault = 0;
            /*设置运行的扭矩*/
            Voltage_Compensa(); /* 根据当前母线电压对运行duty进行补偿 */
            /* 设置扭矩  */
            AGS_SelfLearn.LearnFlag = 1;     /* 进行下一步骤等待堵转  */
            AGS_SelfLearn.LearnTime = 10000; /* 设置10秒超时判定为机械故障  */
            LearnAll_Flag = 1;
        }
        break;

    case 1: /*等待关闭止点发生堵转*/
        if (StallFault == 1)
        {
            AGS_SelfLearn.LearnFlag = 2; /* 上止点自学习完成标志 */
            Brake_STOP;                  /* 锁定电机 */
            AGS_SelfLearn.LearnTime = 200;
        }
        else if ((Uset.New_post >= Uset.Set_post) || (AGS_SelfLearn.LearnTime == 0)) /* 运行到最大位置还没有堵转 可能结构损坏 */
        {
            AGS_SelfLearn.LearnFlag = 16;      /* 自学习失败，没有找到上下终止点 */
            BEMF_STOP;                        /* 锁定电机 */
            MotorSpeed.TargetValue = 0;        /* 关闭输出 */
            AGS_SelfLearn.LearnTime = 100;     /* 自学习完成后等待150ms */
            AGS_DATA.FaultMechanicalBreak = 1; /* 长时间没有检测到堵转认为机械结构故障 */
            AGS_DATA.SelflearnStatus = 2;      /* 自学习失败 */
        }
        break;

    case 2:                               /* 开启到达最大位置 */
        if (AGS_SelfLearn.LearnTime == 0) /* 上电等待自检结束 */
        {
            Uset.New_post = SELF_MAX_POST; /* 当前在最大位置 */
            AGS_SelfLearn.LearnFlag = 6;   /* 打开点自学习完成标志 */
            AGS_SelfLearn.LearnTime = 1900;
        }
        break;

    case 6: /*开始打开AGS自学习 */
        if (AGS_SelfLearn.LearnTime == 0)
        {
            Uset.Set_post = 0;                             /* 设置目标位置为0 表示全部打开 */
            FR = OPEN;                                     /* 设置转动方向为打开 */
            StallFault = 0;                                /* 清除堵转故障 */
            MotorSpeed.FlagONOFF = 1;                      /* 打开电机 */
            MotorSpeed.TargetValue = Motor_Run_Speed_BCOR; /* 设置运行duty */
            AGS_SelfLearn.LearnTime = 10000;               /* 设置运行时间 */
            AGS_SelfLearn.LearnFlag = 7;
            Uset.New_post = SELF_MAX_POST; /* 当前在最大位置 */
        }
        break;
        ///////////**************客户演示增加了 ||(Uset.New_post <= Uset.Set_post)（机械结构故障）   注意注意注意注意注意注意注意注意注意注意后面要去除
    case 7: /*达到自学习发生堵转，认为到达自学习的位置*/

        if (StallFault == 1) //|| (Uset.New_post <= Uset.Set_post)) /*当前位置*/
        {
            if (LearnAll_Flag)                                                          /* 全流程学习时候此时堵转就是整个机械的最大角度*/
            {                                                                           /* 得到最大的机械角度=最大值-当前角度-1个机械止点回退角度 只有关闭有回退，打开没有 */
                Uset.Max_post = SELF_MAX_POST - Uset.New_post - AGS_SELF_REVERSE; // AGS_SELF_REVERSE*2; /* 得到最大的机械角度 */
                /* 最大位置需要保存—************************* */
            }
            Uset.New_post = 0; //设置行程下限70°，行程上限110°，机构行程120°，使用学习到的行程角度。
            Uset.Set_post = 0;

            if (Uset.Max_post < SELF_MIN_POST) /* 运行角度小于80° */
            {
                AGS_SelfLearn.LearnFlag = 16; /* 自学习失败，没有找到上下终止点 */
                AGS_DATA.SelflearnStatus = 2; /* 自学习失败 */
                AGS_DATA.FaultStall = 1;      /* 设置为堵转故障 */
				BEMF_STOP;
            }
            else
            {
                Uset.New_post = 0;           /* 设置行程下限70°，行程上限110°，机构行程120°，使用学习到的行程角度。 */
                Uset.Set_post = 0;           /* 设置允许位置为0 */
                AGS_SelfLearn.LearnFlag = 8; /* 自学习打开堵转完成标志*/
				          Brake_STOP;                     /* 锁定电机 */
            }
  
            AGS_SelfLearn.LearnTime = 1000; /* 自学习完成后等待200ms */
        }
        else if ((Uset.New_post <= Uset.Set_post) || (AGS_SelfLearn.LearnTime == 0))
        {
            AGS_SelfLearn.LearnFlag = 16;      /* 自学习失败，没有找到上下终止点 */
            AGS_DATA.SelflearnStatus = 2;      /* 自学习失败 */
            BEMF_STOP;                        /* 锁定电机 */
            MotorSpeed.TargetValue = 0;        /* 关闭运行duty */
            AGS_DATA.FaultMechanicalBreak = 1; /* 长时间没有检测到堵转认为机械结构故障 */
        }

        break;

    case 8:
        if (AGS_SelfLearn.LearnTime == 0)
        {
			  AGS_SelfLearn.LearnFlag = 9;
            Uset.Set_post = AGS_OPEN_REVERSE * 2;          // 9 : 1 degree  AGS_SELF_REVERSE*2         /* 设置目标位置为0 表示全部打开 */
            FR = CLOSE;                                    /* 设置转动方向为打开 */
            StallFault = 0;                                /* 清除堵转故障 */
            MotorSpeed.FlagONOFF = 1;                      /* 打开电机 */
            MotorSpeed.TargetValue = Motor_Run_Speed_BCOR; /* 设置运行duty */
          
        }
        break;

    case 9: /* 反转角度释放齿轮压力 */
        if (Uset.New_post >= Uset.Set_post)
        {
            AGS_SelfLearn.LearnFlag = 10;  /* 自学习打开堵转完成标志*/
            BEMF_STOP;                     /* 锁定电机 */
            AGS_SelfLearn.LearnTime = 100; /* 自学习完成后等待2s */
            StallFault = 0;                /* 清除堵转 */
        }
        break;

    case 10: /*反转位置结束，开始重置0点位置*/
        if (AGS_SelfLearn.LearnTime == 0)
        {
            Uset.New_post = 0;
            Uset.Set_post = 0;
            AGS_DATA.VCU_Target1 = 0x7f;
            AGS_SelfLearn.LearnFlag = 15;      /* 自学习完成标志位15 */
            AGS_DATA.SelflearnStatus = 0;      /* 清空自学习状态 */
            AGS_DATA.FaultMechanicalBreak = 0; /* 机械故障状态清空 */
            StallFault = 0;                    /* 清除堵转故障 */
            Lin.Time4s = 4000;                 /* 总线4s无数据时候触发 总线休眠 */
            AGS_DATA.VCU_Self1=0;
			One_flag=1;
			TargetCnt=3;
			AGS_DATA.FaultStall = 0;      /* 设置为堵转故障 */
            WriteMaxpos(Uset.Max_post);        /* 保存当前的位置信息数据 */
        }
        break;

    default:
        break;
    }
}
