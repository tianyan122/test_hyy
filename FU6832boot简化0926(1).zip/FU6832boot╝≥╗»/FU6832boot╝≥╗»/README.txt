工程中包含的文件及其内容:
* main.c    
    * flash基本操作函数
    * I2C通讯框架(基本收发)
    * 超时机制, 防止长时间卡在bootloader

* main.h
    * 与bootloader相关的配置选项

* IRQVector.asm
    * 中断向量表

