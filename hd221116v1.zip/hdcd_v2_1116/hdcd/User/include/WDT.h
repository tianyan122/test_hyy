#ifndef __WTD_H__
#define __WTD_H__
#define WDT   200U       /***ms 看门狗复位时间***/

extern void WatchDogConfig(void); 	
extern void WatchDogRefresh(void);
extern uint16 WatchDogtime;
#endif