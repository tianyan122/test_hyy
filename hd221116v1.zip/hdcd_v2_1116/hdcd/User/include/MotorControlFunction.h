/* --------------------------- (C) COPYRIGHT 2020 Fortiortech ShenZhen -----------------------------
    File Name      : MotorControlFunction.h
    Author         : Fortiortech  Appliction Team
    Version        : V1.0
    Date           : 2020-04-11
    Description    : This file contains motor contorl parameter used for Motor Control.
----------------------------------------------------------------------------------------------------
                                       All Rights Reserved
------------------------------------------------------------------------------------------------- */
/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __MOTORCONTROLFUNCTION_H_
#define __MOTORCONTROLFUNCTION_H_
#include "FU68xx_4.h"
#include "Customer.h"
#include "Parameter.h"
#include "AddFunction.h"

typedef struct
{
  uint8 BEMFRun : 1;   //反电动势检测标志位
  uint8 BEMFState : 3; //反电动势检测状态机
  uint8 CCWStep : 4;   //推算正转得步值

  uint8 CWStep : 4;  //推算反转得步值
  uint8 OldStep : 4; //上一次的的比较器值

  uint8 BEMFStatus : 4; //当前运行的比较器值
  uint8 FRStatus : 4;   //正反转 0xf：未检测到方向
  uint16 StepTime;      //单拍的计数值

  uint16 BEMFStep;      //拍的计数
  uint32 BEMFSpeedBase; //反电动势检测的速度基准

  uint16 BEMFTimeCount; //反电动势检测时间
  uint16 BEMFSpeed;     //反电动势检测的速度
} BEMFDetect_TypeDef;

/* Define to prevent recursive inclusion -------------------------------------*/
typedef struct
{
  int16 Iw_busOffset;    // Iw或Ibus的偏置电压
  int32 Iw_busOffsetSum; // Iw或Ibus的偏置电压总和
  int16 OffsetCount;     //偏置电压采集计数
  int8 OffsetFlag;       //偏置电压结束标志位
} CurrentOffset;

extern CurrentOffset xdata mcCurOffset;
extern FaultVarible idata mcFaultDect;
extern BEMFDetect_TypeDef xdata BEMFDetect; /* BEMF检测 */
extern uint8 StartPos;/* 记录定时器1的位置参数 */
extern void Motor_Ready(void);
extern void Motor_Init(void);
extern void Motor_Start(void);
extern void Motor_Hold(void);
extern void VariablesPreInit(void);
extern void GetCurrentOffset(void);
extern void MotorcontrolInit(void);
extern void Fault_Detection(void);
extern void BEMFInit(void);
extern void BEMFDetectFunc(void);

#endif