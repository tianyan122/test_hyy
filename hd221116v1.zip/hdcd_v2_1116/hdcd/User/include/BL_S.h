#ifndef __BL_S_H_
#define __BL_S_H_
//思路		1.首先完成强拖程序的编写，然后分析观察如何强拖能更好的将电机拖动
//			 	2.编写程序，在强拖的过程中观测过零点并将过零点信号使用IO口打出来
//				3.切换的条件，当连续几次检测到正确的过零点以后即可切入正常运行状态
//启动算法的整体思路：在启动过程中使用“边拖边检”的思路，一边强拖一边检测，但是注意：首先，只检测下降沿，不检测上升沿，且当检测到下降沿以后延迟一段时间(换向延迟)以后进行换向。
//其次，强拖过程中上升边沿的时间小于下降沿的检测时间，这样电机强拖会使得拖动更加顺滑（待验证？？？）。

#define UpEdge (0)	 //上升沿
#define DownEdge (1) //下降沿

#define MAX_Commutation (uint16)(6) //强拖阶段最大换相拍数

//强制换相参数
//思考： 1.负载较大的场景，强拖的时间尽量的拉长；负载较小的场景，强拖时间则需要相应的减小。
//       microchip有一篇应用手册中根据电机的转动惯量去计算电机的强拖力矩，可以在此处进行借鉴
//       2.每进行一次换相则进行DUTY的增长，此处的DUTY增长按照设置的DUTY值进行，考虑是否可以按照一定的线性
//       关系对DUTY进行线性的提升。可以参考市面上的开源电调方案对DUTY的操作进行优化提升。
#define Min_START_Duty (0.42) // 启动最小DUTY
#define OpenDuty_Add1 (0.01)  // DUTY增加量
#define OpenDuty_Add2 (0.02)  // DUTY增加量
#define OpenDuty_Add3 (0.02)  // DUTY增加量

#define BLS_OpenUP_MS (10.0) //强拖时上升沿对应的时间长度
#define BLS_OpenUP_PWMCOUNT (uint16)(BLS_OpenUP_MS * PWM_FREQUENCY)

#define BLS_OpenDOWN_MS (10.0) //强拖时下降沿对应的时间长度
#define BLS_OpenDOWN_PWMCOUNT (uint16)(BLS_OpenDOWN_MS * PWM_FREQUENCY)

#define BLS_OpenDOWN_MS1 (40.0) //强拖时下降沿对应的时间长度
#define BLS_OpenDOWN_PWMCOUNT1 (uint16)(BLS_OpenDOWN_MS1 * PWM_FREQUENCY)

#define BLS_OpenDOWN_MS2 (20.0) //强拖时下降沿对应的时间长度
#define BLS_OpenDOWN_PWMCOUNT2 (uint16)(BLS_OpenDOWN_MS2 * PWM_FREQUENCY)

#define BLS_OpenDOWN_MS3 (10.0) //强拖时下降沿对应的时间长度
#define BLS_OpenDOWN_PWMCOUNT3 (uint16)(BLS_OpenDOWN_MS3 * PWM_FREQUENCY)

//续流屏蔽参数设置
//思考： 1.在强拖阶段设置的续流屏蔽时间应该如何设置？
//       面对不同的电机、不同的启动DUTY启动时的实际续流时间是不同的，在强拖阶段可以设置一个较为通用的续流屏蔽时间，遇到不同的情况再进行调整。
//       ***电机的续流时间能否通过一个数学公式或者是数学模型进行计算，如此则可以将这个参数省略***
#define BLS_MaskAngle_MS (1.0) //强拖启动时的续流屏蔽时间
#define BLS_MaskAngle_PWMCOUNT (uint16)(BLS_MaskAngle_MS * PWM_FREQUENCY)

//过零点滤波参数
//思考： 1.现有的这种滤波方式为连续几个载波检测，跳变沿都已经发生改变，那么就认为确实发生了换相事件
//       microchip的应用手册AN1175中有一种一种软件滤波算法，用于滤除CMP上的干扰信号，后期可以尝试添加入该代码中
#define BLS_ZeroFlt_MS (0.25) //过零点信号的滤波时间
#define BLS_ZeroFlt_PWMCOUNT (uint16)(BLS_ZeroFlt_MS * PWM_FREQUENCY)

//延迟换相参数设置
//思考：	1.在强拖阶段的的延迟换相时间设置。
//  	 	换相越来越快，延迟换相时间叶越来越短，是否有办法能够智能设置延迟换相时间，而不用对参数进行一个一个的更改
#define BLS_DelayAngle_MS0 (27.5) //延迟换相时间
#define BLS_ZeroFlt_PWMCOUNT0 (uint16)(BLS_DelayAngle_MS0 * PWM_FREQUENCY)

#define BLS_DelayAngle_MS1 (25.0) //延迟换相时间
#define BLS_ZeroFlt_PWMCOUNT1 (uint16)(BLS_DelayAngle_MS1 * PWM_FREQUENCY)

#define BLS_DelayAngle_MS2 (12.5) //延迟换相时间
#define BLS_ZeroFlt_PWMCOUNT2 (uint16)(BLS_DelayAngle_MS2 * PWM_FREQUENCY)

typedef struct
{

	uint8 BLDCSetFlag : 2; //状态标志位  0：启动前的状态,对寄存器进行初始化  1：强拖阶段   2：切换至硬件运行
	uint8 Hard_Count;
	uint8 Old_Count; //上次换向的状态
	uint16 Startime; //状态标志位  0：启动前的状态,对寄存器进行初始化  1：强拖阶段   2：切换至硬件运行
	uint16 PItime; //PI启动优化事件
} BL_S_TypeDef;

extern bit idata Dir_Comm;
extern BL_S_TypeDef idata BL_S;
extern uint8 xdata CW_CMPOUT[7];
extern uint8 xdata CCW_CMPOUT[7];

extern void BL_S_ParaInit(void);
extern void BL_S_Function(BL_S_TypeDef *BLS);
extern void TIM1_BLS_Init(void);
extern void TIM1_TO_Hardware(void);

#endif