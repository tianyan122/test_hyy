#ifndef __BLDC_H_
#define __BLDC_H_



                                        /*方波驱动设置*/
#define cmp_samr                           (uint8)(0xff)                                                     //方波反电动势采样点的设置		

#define ANGLE_MASK(ANGLE_M)                  {TIM1_CR1  =(TIM1_CR1 &(0x80)) | (ANGLE_M*127/60);}             //续流屏蔽角度

#define ANGLE_DELAY(ANGLE_D)                 {TIM1_CR2  =(TIM1_CR2 &(0x80)) | (ANGLE_D*127/60);}             //延迟换向角度     

#define BLDC150_AngleDely            				  _Q16((15.0-Motor_Advance_Angle)/60.0)                          //用于计算150度方波驱动时的插入时间

#define ANGLE_MASK_R(ANGLE_M_R)       			 (uint8)(ANGLE_M_R*127.0/60.0)

#define ANGLE_DELAY_R(ANGLE_D_R)      			 (uint8)(ANGLE_D_R*127.0/60.0)


                                        /*150度方波驱动设置*/




                                        /*斩波方式选择*/
//Tips:6832驱动方式为上桥臂为PMOS，下桥臂为NMOS。正常驱动信号应该是上管“低有效”，下管“高有效”，6832系列芯片内部进行了上桥臂驱动信号逻辑反转，在配置驱动电平时仅需要按照“全高有效”配置即可。

//有效电平设置
#define ActiveLowEnable                 (0x0540)                                //低电平有效       0101 0100 0000
#define ActiveHighEnable                (0)                                     //高电平有效       0000 0000 0000

#define H_MOSActive                     (ActiveHighEnable)                      //上桥预驱电平
#define L_MOSActive                     (ActiveHighEnable)                      //下桥预驱电平

#define PWM_BITCON                      (L_MOSActive+H_MOSActive*2)             //H_MOSActive*2 其实是将上桥驱动的有效电平对应数据左移一位


#define TUVW_OFF                        0x0000                                  //UVW全关
#define TULVLWL_ON                      0x0540                                  //开三相下桥       0101 0100 0000——下桥禁止输出（0）+ 低电平有效(1) -> 下桥输出高电平 ； 上桥禁止输出（0）+ 高电平有效(0) -> 下桥输出低电平




//斩波方式

//上PWM下ON：	上桥PWM波斩波，下桥全开
#define UH_pwm_VL_on                    0x0102                                  //0000 0000 0010——U相上桥使能输出(1) + 高电平有效(0) -> 上桥PWM  ；   0001 0000 0000——V相下桥禁止输出（0）+ 低电平有效(1) -> 下桥输出高电平

#define UH_pwm_WL_on                    0x0402                                  //0000 0000 0010——U相上桥使能输出(1) + 高电平有效(0) -> 上桥PWM  ；   0100 0000 0000——W相下桥禁止输出（0）+ 低电平有效(1) -> 下桥输出高电平

#define VH_pwm_WL_on                    0x0408                                  //0000 0000 1000——V相上桥使能输出(1) + 高电平有效(0) -> 上桥PWM  ；   0100 0000 0000——W相下桥禁止输出（0）+ 低电平有效(1) -> 下桥输出高电平

#define VH_pwm_UL_on                    0x0048                                  //0000 0000 1000——V相上桥使能输出(1) + 高电平有效(0) -> 上桥PWM  ；   0000 0100 0000——U相下桥禁止输出（0）+ 低电平有效(1) -> 下桥输出高电平

#define WH_pwm_UL_on                    0x0060                                  //0000 0010 0000——W相上桥使能输出(1) + 高电平有效(0) -> 上桥PWM  ；   0000 0100 0000——U相下桥禁止输出（0）+ 低电平有效(1) -> 下桥输出高电平

#define WH_pwm_VL_on                    0x0120                                  //0000 0010 0000——W相上桥使能输出(1) + 高电平有效(0) -> 上桥PWM  ；   0001 0000 0000——V相下桥禁止输出（0）+ 低电平有效(1) -> 下桥输出高电平

  /*插入150度换相的导通方式*/
#define UH_pwm_VWL_on                   0x0502                                  //0000 0000 0010——U相上桥使能输出(1) + 高电平有效(0) -> 上桥PWM  ；   0101 0000 0000——VW相下桥禁止输出（0）+ 低电平有效(1) -> 下桥输出高电平

#define UVH_pwm_WL_on                   0x040A                                  //0000 0000 1010——UV相上桥使能输出(1) + 高电平有效(0) -> 上桥PWM ；   0100 0000 0000——W相下桥禁止输出（0）+ 低电平有效(1) -> 下桥输出高电平

#define VH_pwm_UWL_on                   0x0448                                  //0000 0000 1000——V相上桥使能输出(1) + 高电平有效(0) -> 上桥PWM  ；   0100 0100 0000——UW相下桥禁止输出（0）+ 低电平有效(1) -> 下桥输出高电平

#define VWH_pwm_UL_on                   0x0068                                  //0000 0010 1000——V相上桥使能输出(1) + 高电平有效(0) -> 上桥PWM  ；   0000 0100 0000——U相下桥禁止输出（0）+ 低电平有效(1) -> 下桥输出高电平

#define WH_pwm_UVL_on                   0x0160                                  //0000 0010 0000——W相上桥使能输出(1) + 高电平有效(0) -> 上桥PWM  ；   0001 0100 0000——UV相下桥禁止输出（0）+ 低电平有效(1) -> 下桥输出高电平

#define WUH_pwm_VL_on                   0x0122                                  //0000 0010 0010——WU相上桥使能输出(1) + 高电平有效(0) -> 上桥PWM ；   0001 0000 0000——V相下桥禁止输出（0）+ 低电平有效(1) -> 下桥输出高电平


//上PWM互补下on：  上桥PWM(互补)波斩波，下桥on
#define UH_pwm_com_VL_on                0x0103                                   //0000 0000 0011——U相上桥使能输出(1) + 高电平有效(0) -> 上桥PWM  ；   0001 0000 0000——V相下桥禁止输出（0）+ 低电平有效(1) -> 下桥输出高电平

#define UH_pwm_com_WL_on                0x0403                                   //0000 0000 0011——U相上桥使能输出(1) + 高电平有效(0) -> 上桥PWM  ；   0100 0000 0000——W相下桥禁止输出（0）+ 低电平有效(1) -> 下桥输出高电平

#define VH_pwm_com_WL_on                0x040c                                   //0000 0000 1100——V相上桥使能输出(1) + 高电平有效(0) -> 上桥PWM  ；   0100 0000 0000——W相下桥禁止输出（0）+ 低电平有效(1) -> 下桥输出高电平

#define VH_pwm_com_UL_on                0x004c                                   //0000 0000 1100——V相上桥使能输出(1) + 高电平有效(0) -> 上桥PWM  ；   0000 0100 0000——U相下桥禁止输出（0）+ 低电平有效(1) -> 下桥输出高电平

#define WH_pwm_com_UL_on                0x0070                                   //0000 0011 0000——W相上桥使能输出(1) + 高电平有效(0) -> 上桥PWM  ；   0000 0100 0000——U相下桥禁止输出（0）+ 低电平有效(1) -> 下桥输出高电平

#define WH_pwm_com_VL_on                0x0130                                   //0000 0011 0000——W相上桥使能输出(1) + 高电平有效(0) -> 上桥PWM  ；   0001 0000 0000——V相下桥禁止输出（0）+ 低电平有效(1) -> 下桥输出高电平




//上PWM下PWM：  上桥PWM波斩波，下桥PWM斩波
#define UH_pwm_VL_pwm                  0x0006                                   //0000 0000 0010——U相上桥使能输出(1) + 高电平有效(0) -> 上桥PWM  ；   0000 0000 0100——V相下桥使能输出（0）+ 高电平有效(0) -> 下桥输出高电平

#define UH_pwm_WL_pwm                  0x0012                                   //0000 0000 0010——U相上桥使能输出(1) + 高电平有效(0) -> 上桥PWM  ；   0000 0001 0000——W相下桥使能输出（0）+ 高电平有效(0) -> 下桥输出高电平

#define VH_pwm_WL_pwm                  0x0018                                   //0000 0000 1000——V相上桥使能输出(1) + 高电平有效(0) -> 上桥PWM  ；   0000 0001 0000——W相下桥使能输出（0）+ 高电平有效(0) -> 下桥输出高电平

#define VH_pwm_UL_pwm                  0x0009                                   //0000 0000 1000——V相上桥使能输出(1) + 高电平有效(0) -> 上桥PWM  ；   0000 0000 0001——U相下桥使能输出（0）+ 高电平有效(0) -> 下桥输出高电平

#define WH_pwm_UL_pwm                  0x0021                                   //0000 0010 0000——W相上桥使能输出(1) + 高电平有效(0) -> 上桥PWM  ；   0000 0000 0001——U相下桥使能输出（0）+ 高电平有效(0) -> 下桥输出高电平

#define WH_pwm_VL_pwm                  0x0024                                   //0000 0010 0000——U相上桥使能输出(1) + 高电平有效(0) -> 上桥PWM  ；   0000 0000 1000——V相下桥使能输出（0）+ 高电平有效(0) -> 下桥输出高电平





//DBR
//三相全关闭 and 开三相下桥 
#define UVW_OFF                        (TUVW_OFF^PWM_BITCON)

#define ULVLWL_ON                      (TULVLWL_ON^PWM_BITCON)

//上PWM下ON：	上桥PWM波斩波，下桥全开
#define UH_PWM_VL_ON                   (UH_pwm_VL_on^PWM_BITCON)  

#define UH_PWM_WL_ON                   (UH_pwm_WL_on^PWM_BITCON) 

#define VH_PWM_WL_ON                   (VH_pwm_WL_on^PWM_BITCON) 

#define VH_PWM_UL_ON                   (VH_pwm_UL_on^PWM_BITCON) 

#define WH_PWM_UL_ON                   (WH_pwm_UL_on^PWM_BITCON) 

#define WH_PWM_VL_ON                   (WH_pwm_VL_on^PWM_BITCON) 

		/*插入150度换相的导通方式*/
	#define UH_PWM_VWL_ON 							 (UH_pwm_VWL_on^PWM_BITCON)                                            

	#define UVH_PWM_WL_ON                (UVH_pwm_WL_on^PWM_BITCON)              

	#define VH_PWM_UWL_ON                (VH_pwm_UWL_on^PWM_BITCON)            

	#define VWH_PWM_UL_ON                (VWH_pwm_UL_on^PWM_BITCON)               

	#define WH_PWM_UVL_ON                (WH_pwm_UVL_on^PWM_BITCON)           

	#define WUH_PWM_VL_ON                (WUH_pwm_VL_on^PWM_BITCON)           


//上PWM下on：  上桥PWM胡波斩波，下桥on
#define UH_PWM_COM_VL_ON           (UH_pwm_com_VL_on^PWM_BITCON) 

#define UH_PWM_COM_WL_ON           (UH_pwm_com_WL_on^PWM_BITCON) 

#define VH_PWM_COM_WL_ON           (VH_pwm_com_WL_on^PWM_BITCON) 

#define VH_PWM_COM_UL_ON           (VH_pwm_com_UL_on^PWM_BITCON) 

#define WH_PWM_COM_UL_ON           (WH_pwm_com_UL_on^PWM_BITCON) 

#define WH_PWM_COM_VL_ON           (WH_pwm_com_VL_on^PWM_BITCON) 



//上PWM下PWM：  上桥PWM波斩波，下桥PWM斩波
#define UH_PWM_VL_PWM               (UH_pwm_VL_pwm^PWM_BITCON) 

#define UH_PWM_WL_PWM               (UH_pwm_WL_pwm^PWM_BITCON) 

#define VH_PWM_WL_PWM               (VH_pwm_WL_pwm^PWM_BITCON) 

#define VH_PWM_UL_PWM               (VH_pwm_UL_pwm^PWM_BITCON) 

#define WH_PWM_UL_PWM               (WH_pwm_UL_pwm^PWM_BITCON) 

#define WH_PWM_VL_PWM               (WH_pwm_VL_pwm^PWM_BITCON) 













//跳变沿检测
//  001——U相上升沿     010——W相下降沿    	 011——V相上升沿      100——U相下降沿    101——W相上升沿     110——V相下降沿    111——三相边沿检测
#define CMP_U_UP                       0x1000 

#define CMP_W_DO                       0x2000  

#define CMP_V_UP                       0x3000 

#define CMP_U_DO                       0x4000

#define CMP_W_UP                       0x5000 

#define CMP_V_DO                       0x6000 

#define CMP_UVW_ALL                    0x7000  




#endif






