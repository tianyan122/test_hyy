/*  -------------------------- (C) COPYRIGHT 2020 Fortiortech ShenZhen ---------------------------*/
/*  File Name      : Protect.h
/*  Author         : Fortiortech  Appliction Team
/*  Version        : V1.0
/*  Date           : 2020-08-18
/*  Description    : 主要用于电机运行保护条件参数设置.
/*  ----------------------------------------------------------------------------------------------*/
/*                                     All Rights Reserved
/*  ----------------------------------------------------------------------------------------------*/

/*  Define to prevent recursive inclusion --------------------------------------------------------*/
#ifndef __PROTECT_H_
#define __PROTECT_H_

 /*硬件过流保护比较值来源*/
 #define Compare_Mode                   (Compare_DAC)                      		  // 硬件过流值的来源
 #define OverHardcurrentValue           (1.3)                                	// (A) DAC模式下的硬件过流值

 /*软件过流保护*/
 #define OSCurrentProtectEnable         (1)                                     // 软件过流保护，0,不使能；1，使能
 #define OverSoftCurrentValue           I_Value(0.8)                            // (A) 软件过流值
 #define OverSoftCurrentTime            (1000)                                   // (ms)一级软件过流检测时间		

 /*过热保护*/ //值需要根据电路重新设置
 #define OverHeat_Min     _Q15(0.05)                                               // (ms)最大温度130对应的电阻值电压
 #define OverHeat_Max     _Q15(0.95)                                               // (ms)最小温度对应电阻值 100K
 #define OverHeatTime     (5000)                                                // (ms)连续过温时间5S
 
 #define OverHeatUPRES    (10000)                                               // (ms)上拉电阻值10k
 #define OverHeat_Temp     (850.0)                                               // (ms)105°对应电阻值 850R
 
 #define OverHeatValue    _Q15(OverHeat_Temp/(OverHeatUPRES+OverHeat_Temp))       //电压0.392v                                                 // Max 对应ad值  0.392

 /*过欠压保护 按照*/
 #define VoltageProtectEnable           (1)                                     // 电压保护，0,不使能；1，使能
 #define Diode_Voltage                  (0.829)                                 // (V) 防反接电路使用的二极管压降，在进行功率计算时需要考虑进去
 
 #define Over_Protect_Voltage           (18.0)                                  // (V) 直流电压过压保护值
 #define Over_Recover_Vlotage           (17.2)                                  // (V) 直流电压过压保护恢复值
 
 #define Low_MaxVoltalge_Vlotage        (13.0)                                   //(V)低温高限压
 
 #define Under_Protect_Voltage          (8.1)                                 	// (V) 直流电压欠压保护值
 #define Under_Recover_Vlotage          (8.6)                                   // (V) 直流电压欠压保护恢复值
 #define Under_Compensa_Vlotage         (10.0)                                  // (V) 直流电压欠压保护恢复值


 #define UnderV_flash_Protect           (10.0)                                 	// (V) 低压禁止 写flash保护
 #define OverV_flash_Protect            (16.0)                                 	// (V) 低压禁止 写flash保护
 
 #define DIODE_Vlotage                  (0.22)                                   // (V) 输入端二极管的压降

 #define Over_Voltage_Time              (400)                                 	// (V) 过压持续时间400ms
 #define Under_Vlotage_Time             (700)                                   // (V) 欠压持续时间700ms
 #define Voltage_Recover_Time           (100)                                 	// (V) 过欠压恢复时间100ms
 /*电压检测电路故障*/
 #define Sensor_Min_Voltage          (5.0)                                 	// (V) 电压检测电路故障最小值
 #define Sensor_Max_Vlotage          (30.0)                                 // (V) 电压检测电路故障最大值
 #define Sensor_Vlotage_COUNT        (100)                                  // (V) 电压检测电路故障时间

 /*启动保护*/
 #define StartProtectEnable             (1)                                     // 启动保护，0,不使能；1，使能

 /*堵转保护*/
 #define StallProtectEnable             (1)                                     // 堵转保护，0,不使能；1，使能
 #define MOTOR_STALL_COUNT              (200)                                 // (ms) 启动运行时间
 #define MOTOR_StallSPEED_RPM           (2600.0)                                // 堵转失步速度，单位RPM
 #define MOTOR_StallSPEED_MIN           (1300.0)                                // 堵转最小速度，单位RPM
 #define MOTOR_RunSPEED_MIN             (2100.0)                                // 堵转最小速度，单位RPM
 #define MOTOR_Arrive_SPEED             (1500.0)                                // 软着落速度，单位RPM

/*过热保护*/ //值需要根据电路重新设置
 #define OverHeat_Min     _Q15(0.05)                                               // (ms)最大温度130对应的电阻值电压
 #define OverHeat_Max     _Q15(0.95)                                               // (ms)最小温度对应电阻值 100K
 #define OverHeatTime       (5000)                                                // (ms)连续过温时间5S
 
 
 #define OverHeatUPRES     (10000.0)                                               // (ms)上拉电阻值10k
#define RecoverHeat_Temp  (300.0)                                               // (ms)120°对应电阻值 599R
 #define OverHeat_Temp     (250.0)                                               // (ms)125°对应电阻值 550R
 #define OverHeat_Temp2    (200.0)                                               // (ms)135°对应电阻值 200R
 #define OverHeat_Temp3    (12000.0)                                              // (ms)0°对应电阻值 13000R
 
                                              // (ms)135°对应电阻值 480R
 #define OverHeatValue1    _Q15(OverHeat_Temp/(OverHeatUPRES+OverHeat_Temp))         //电压0.26v                                                 // Max 对应ad值  0.392
 #define OverHeatValue2    _Q15(OverHeat_Temp2/(OverHeatUPRES+OverHeat_Temp2))       //电压0.26v   
 #define RecoverHeatValue  _Q15(RecoverHeat_Temp/(OverHeatUPRES+RecoverHeat_Temp))       //电压0.26v    
 #define Low_Temp          _Q15(OverHeat_Temp3/(OverHeatUPRES+OverHeat_Temp3))     //    




#endif

