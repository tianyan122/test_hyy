/*  -------------------------- (C) COPYRIGHT 2020 Fortiortech ShenZhen ---------------------------*/
/*  File Name      : Develop.h
/*  Author         : Fortiortech  Appliction Team
/*  Version        : V1.0
/*  Date           : 2020-08-31
/*  Description    : This file contains Advanced Applications parameter used for Motor Control.
/*  ----------------------------------------------------------------------------------------------*/
/*                                     All Rights Reserved
/*  ----------------------------------------------------------------------------------------------*/

/*  Define to prevent recursive inclusion --------------------------------------------------------*/
#ifndef __DEVELOP_H_
#define __DEVELOP_H_

/*CPU Parameter*/
#define MCU_CLOCK                      (24.0)                                 // (MHz) 主频

/*single resistor sample Parameter*/
#define MIN_WIND_TIME                  (PWM_DEADTIME + 1.0)                   // (us) 单电阻最小采样窗口，建议值死区时间+0.9us


/*deadtime compensation*/
#define DT_TIME                         (0.4)                                 // 死区补偿时间(us)，适用于双电阻和三电阻，建议值是1/2死区时间
/*min pulse*/
#define GLI_TIME                        (0.5)                                 // 桥臂窄脉宽消除(us),建议值0.5

#define OverModulation                  (0)                                   // 0-禁止过调制，1-使能过调制


#define AMP2x       0
#define AMP4x       1
#define AMP8x       3
#define AMP16x      4
#define AMP32x      5

#define INTERNAL     0
#define EXTERNAL     1

#define Ratio_12     0
#define Ratio_6_5    1

/*Current Calib:enable or disable*/
#define Disable                         (0)
#define Enable                          (1)

/*double resistor sample mode*/
#define DouRes_1_Cycle                  (0)                                    // 1 周期采样完 ia, ib
#define DouRes_2_Cycle                  (1)                                    // 交替采用ia, ib, 2周期采样完成
#define DouRes_Sample_Mode              (DouRes_1_Cycle)

/*运行模式选择设置值----------------------------------------------------------------*/
#define IPMtest                         (0)                                    // IPM测试或者MOS测试，MCU输出固定占空比
#define NormalRun                       (1)                                    // 正常按电机状态机运行

/*环路选择*/
#define OUTLoop_Disable                 (0)                                    // 开环运行
#define OUTLoop_Enable                  (1)                                    // 添加控制环路


/*外环选择速度环*/
#define SPEED_LOOP_CONTROL              (0)                                    //速度环
#define CURRENT_LOOP_CONTROL            (1)                                    //电流环
#define POWER_LOOP_CONTROL              (2)                                    //功率环
#define SPEED_AND_POWER_LOOP_CONTROL    (3)                                    //速度环+功率环
#define SPEED_AND_CURRENT_LOOP_CONTROL  (4)                                    //速度环+电流环


 
/*调速模式*/
#define NONEMODE                        (0)                                    // 直接给定值，不调速
#define PWMMODE                         (1)                                    // PWM调速
#define SREFMODE                        (2)                                    // VSP调速

#define PWM_11                          (0)                                     //GP11作为TIM3的输入IO
#define PWM_01                          (1)                                     //GP01作为TIM3的输入IO
 
#define CW                              (0)                                     //正转
#define CCW                             (1)                                     //反转

#define CLOSE                             (0)                                     //反转
#define OPEN                              (1)                                     //正转


/*电流采样模式*/
#define Single_Resistor                 (0)                                    // 单电阻电流采样模式
#define Double_Resistor                 (1)                                    // 双电阻电流采样模式
#define Three_Resistor                  (2)                                    // 三电阻电流采样模式


/*硬件过流保护比较值来源*/
#define Compare_DAC                     (0)                                   // DAC设置硬件过流值
#define Compare_Hardware                (1)                                   // 硬件设置硬件过流值



#endif

