/* --------------------------- (C) COPYRIGHT 2020 Fortiortech ShenZhen -----------------------------
	File Name      : FLASH.c
	Author         : Fortiortech  Appliction Team
	Version        : V1.0
	Date           : 2020-07-24
	Description    : 读写数据拆分三组，位置数据一组，当前运行次数一组（），诊断数据一组（16Byte）
----------------------------------------------------------------------------------------------------
									   All Rights Reserved
------------------------------------------------------------------------------------------------- */
/******************************************************************************/ // Including Header Files
#include <MyProject.h>

uint16 old_maxpos = 0; /*上次存储的最大角度数据值*/
uint16 old_pos = 0;	   /*上次存储的数据值*/
uint8 FlashWriteStatus = 0;

/* -------------------------------------------------------------------------------------------------
	Function Name  : Flash_Sector_Erase
	Description    : 扇区自擦除: 指定将要擦除的Flash扇区，每个扇区为 256 字节， 共计 128 个扇区扇区0~127对应Flash地址0x0000~0x3fff，
					 通过指定Flash地址来指定要擦除的Flash地址所在扇区。
					 一次只能擦除一个扇区，自擦除数据为任意值，一定要在解锁后才给DPTR赋值。
	Date           : 2020-07-23
	Parameter      : FlashAddress: [输入/出]
------------------------------------------------------------------------------------------------- */
void Flash_Sector_Erase(uint8 xdata *FlashAddress)
{
	if (mcFocCtrl.mcDcbusFlt >= UNDER_PROTECT_VALUE) /* 电压太低不保存数据 */
	{
		SetBit(WDT_CR, WDTRF); /*喂狗*/
		EA = 0;				   // Flash自擦除前先关总中断
		FLA_CR = 0x03;		   //使能自擦除
		FLA_KEY = 0x5a;
		FLA_KEY = 0x1f;		  // flash预编程解锁
		*FlashAddress = 0xff; //写任意数据
		FLA_CR = 0x08;		  //开始预编程，完成后Flash再次上锁
	}
}

/* -------------------------------------------------------------------------------------------------
	Function Name  : Flash_Sector_Write
	Description    : Flash自烧写: 对扇区预编程和自擦除后，可以对扇区内的地址进行Flash烧写，
					一次烧写一个byte,一定要在解锁后才给DPTR赋值
	Date           : 2020-07-23
	Parameter      : FlashAddress: [输入/出]
------------------------------------------------------------------------------------------------- */
void Flash_Sector_Write(uint8 xdata *FlashAddress, uint8 FlashData)
{
	EA = 0;		   // Flash自烧写前先关总中断
	FLA_CR = 0x01; // 使能Flash编程
	FLA_KEY = 0x5a;
	FLA_KEY = 0x1f;			   // flash预编程解锁
	*FlashAddress = FlashData; // 写编程数据
	FLA_CR = 0x08;			   // 开始预编程，完成后Flash再次上锁
}

/*  ----------------------------------------------------------------------------------------------*/
/*  Function Name  : WriteXByte2Flash
/*  Description    : 向目标FLASH中写入X字节的数据
/*  Date           : 2022-03-06
/*  Parameter      : FlashStartAddr: [目标FLASH地址]
**	                 NewData2Flash: [需要存储的数据]
**	                 XByte: [写字节数,XByte[1,255]]
/*  ----------------------------------------------------------------------------------------------*/
uint16 flash_test = 0;
uint8 WriteXByte2Flash(uint8 xdata *BlockStartAddr, uint8 *NewData2Flash, uint8 XByte, uint16 width)
{
	uint16 i, j;
	uint8 xdata *FlashStartAddr = BlockStartAddr;
	uint16 tempofFlashData = 0;
	SetBit(WDT_CR, WDTRF); /*喂狗*/
	for (i = 0; i < width; i++)
	{
		tempofFlashData = *(uint8 code *)(FlashStartAddr + XByte * i); /*查找空白空间*/
		if (tempofFlashData == 0)
		{
			flash_test = i;
			for (j = 0; j < XByte; j++)
			{
				Flash_Sector_Write(FlashStartAddr + XByte * i + j, NewData2Flash[j]);
			}
			return 1;
		}
		else
		{
			if (i == (width - 1)) /* 找到最后没有找到数据 */
			{
				return 0;
			}
		}
	}
	return 0;
}

/* -------------------------------------------------------------------------------------------------
	Function Name  : uint16 Red2Byte(uint8 xdata *BlockStartAddr, uint8 WID)
	Description    : 从目标FLASH扇区读取2字节。Input:	uint8 xdata *BlockStartAddr：目标FLASH扇区
	Date           : 2020-07-23
	Parameter      : None
------------------------------------------------------------------------------------------------- */
uint16 Red2Byte(uint8 xdata *BlockStartAddr, uint8 WID)
{
	uint8 xdata *FlashStartAddr = BlockStartAddr;
	uint16 i;
	uint16 tempofFlashData;
	for (i = 0; i < WID; i++)
	{
		tempofFlashData = *(uint16 code *)(FlashStartAddr + 2 * i);
		if (tempofFlashData == 0) /* 读取到空数据，取前一个有效数据 */
		{
			if (i != 0)
			{
				tempofFlashData = *(uint16 code *)(FlashStartAddr + 2 * (i - 1));
				return tempofFlashData;
			}
			else
			{
				return 0;
			}
		}
		else
		{
			if (i == (POS_MAX_WID - 1)) /* 全都是有效数据取最后一次数据 */
			{
				return tempofFlashData;
			}
		}
	}
	return 1;
}

/* -------------------------------------------------------------------------------------------------
	Function Name  : void WriteMaxpos(uint16 NewData2Flash)
	Description    :FLASH写数据,把自学习的最大位置写入
	Date           : 2022-02-13
	Parameter      : 写入AGS的位置数据，下次上电时候要读取出来当前的位置数据
------------------------------------------------------------------------------------------------- */

void WriteMaxpos(uint16 NewData2Flash)
{

	NewData2Flash = NewData2Flash + 16384;																   /*加上偏移量16384*/
	if (((old_maxpos > NewData2Flash) ? (old_maxpos - NewData2Flash) : (NewData2Flash - old_maxpos)) > 48) /* 新的角度和以前角度相差较大才开始记录 */
	{
		FlashWriteStatus = WriteXByte2Flash(SAVE_MAXADDRESS, &NewData2Flash, 2, POS_MAX_WID);
		if (!FlashWriteStatus) /*数据写入失败，数据写满了*/
		{
			Flash_Sector_Erase(SAVE_MAXADDRESS); /*擦除1个扇区共256字节*/
			FlashWriteStatus = WriteXByte2Flash(SAVE_MAXADDRESS, &NewData2Flash, 2, POS_MAX_WID);
			if (!FlashWriteStatus) /*再次检查防止写入失败*/
			{
				Flash_Sector_Erase(SAVE_MAXADDRESS); /*擦除两个扇区共256字节*/
				FlashWriteStatus = WriteXByte2Flash(SAVE_MAXADDRESS, &NewData2Flash, 2, POS_MAX_WID);
			}
		}
		old_maxpos = NewData2Flash;
		EA = 1; // Flash自烧写前先关总中断
	}
}

/* -------------------------------------------------------------------------------------------------
	Function Name  : void Writepos(uint16 NewData2Flash)
	Description    :FLASH写数据,先把NewData2Flash写入到目标FLASH地址BlockStartAddr后,再将其FLASH值读出来。
	uint8 xdata *BlockStartAddr：目标FLASH地址  NewData2Flash：被写入数据

	Date           : 2020-07-23
	Parameter      : 写入AGS的位置数据，下次上电时候要读取出来当前的位置数据
------------------------------------------------------------------------------------------------- */
void Writepos(uint16 NewData2Flash)
{
	uint8 i = 0;
	NewData2Flash = NewData2Flash + 16384; /* 加上偏移量16384 */
	if (AGS_DATA.SelflearnStatus == 2)	   /* 自学习失败记录位置为100 */
	{
		NewData2Flash = 100;
	}
	if (mcFocCtrl.mcDcbusFlt < UNDER_PROTECT_VALUE) /* 电压太低不保存数据 */
	{
		old_pos = NewData2Flash;
	}
	if (old_pos != NewData2Flash) /*上次保存的值和本次不同才写入防止频繁写入*/
	{
		Lin.Time4s = 4000;
		FlashWriteStatus = WriteXByte2Flash(SAVE_POSADDRESS, &NewData2Flash, 2, POS_WID);
		if (!FlashWriteStatus) /*数据写入失败，数据写满了*/
		{
			/* 连续擦除2个扇区 */
			for (i = 0; i < 2; i++)
			{
				Flash_Sector_Erase(SAVE_POSADDRESS + (FLA_SECTOR_WIDT * i)); /*擦除2个扇区共256字节*/
			}
			FlashWriteStatus = WriteXByte2Flash(SAVE_POSADDRESS, &NewData2Flash, 2, POS_WID);
			if (!FlashWriteStatus) /*再次检查防止写入失败*/
			{
				/* 连续擦除2个扇区 */
				for (i = 0; i < 2; i++)
				{
					Flash_Sector_Erase(SAVE_POSADDRESS + (FLA_SECTOR_WIDT * i)); /*擦除2个扇区共256字节*/
				}
				FlashWriteStatus = WriteXByte2Flash(SAVE_POSADDRESS, &NewData2Flash, 2, POS_WID);
			}
		}
		old_pos = NewData2Flash;
		EA = 1; // Flash自烧写前先关总中断
	}
}

/* -------------------------------------------------------------------------------------------------
	Function Name  : void WriteDeviceAddress(uint16 NewData2Flash)
	Description    :FLASH写数据，把设备当前地址写入Flash
	Date           : 2022-06-12
	Parameter      : 设备地址
------------------------------------------------------------------------------------------------- */
void WriteDeviceAddress(uint16 NewData2Flash)
{
	NewData2Flash = NewData2Flash ;																   /*加上偏移量16384*/
	FlashWriteStatus = WriteXByte2Flash(SAVE_DEVICEADDRESS, &NewData2Flash, 2, POS_MAX_WID);
	if (!FlashWriteStatus) /*数据写入失败，数据写满了*/
	{
			Flash_Sector_Erase(SAVE_DEVICEADDRESS); /*擦除1个扇区共256字节*/
			FlashWriteStatus = WriteXByte2Flash(SAVE_DEVICEADDRESS, &NewData2Flash, 2, POS_MAX_WID);
			if (!FlashWriteStatus) /*再次检查防止写入失败*/
			{
				Flash_Sector_Erase(SAVE_DEVICEADDRESS); /*擦除两个扇区共256字节*/
				FlashWriteStatus = WriteXByte2Flash(SAVE_DEVICEADDRESS, &NewData2Flash, 2, POS_MAX_WID);
			}
	}
	EA = 1; // Flash自烧写前先关总中断
}

/* -------------------------------------------------------------------------------------------------
	Function Name  : void ReadDeviceAddress
	Description    : 从目标FLASH扇区读取2字节最新写入的数据。Input:	uint8 xdata *BlockStartAddr：目标FLASH扇区
	Date           : 2022-06-12
	Parameter      : None
------------------------------------------------------------------------------------------------- */
uint16 ReadDeviceAddress(void)
{
	uint16 tempofFlashData;

	tempofFlashData = Red2Byte(SAVE_DEVICEADDRESS, DEVICE_WID);
	if (tempofFlashData == 0xA878)
	{
		return 1;
	}
	else if (tempofFlashData == 0x0849)
	{
		return 2;
	}
	else if (tempofFlashData == 0)
	{
		return 3;
	}

	return 0;
}

/* -------------------------------------------------------------------------------------------------
	Function Name  : uint16 RedMaxpos(void)
	Description    : 从目标FLASH扇区读取2字节的区间数据。
	Date           : 2020-07-23
	Parameter      : None
------------------------------------------------------------------------------------------------- */
uint16 RedMaxpos(void)
{
	old_maxpos = Red2Byte(SAVE_MAXADDRESS, POS_MAX_WID);
	return old_maxpos;
}
/* -------------------------------------------------------------------------------------------------
	Function Name  : uint16 RedPos(void)
	Description    : 从目标FLASH扇区读取2字节的位置数据。
	Output:	读出天窗电机的位置数据
	Date           : 2020-07-23
	Parameter      : None
------------------------------------------------------------------------------------------------- */
uint16 RedPos(void)
{
	old_pos = Red2Byte(SAVE_POSADDRESS, POS_WID);
	return old_pos;
}

