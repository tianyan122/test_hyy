/* --------------------------- (C) COPYRIGHT 2020 Fortiortech ShenZhen -----------------------------
    File Name      : LIN.c
    Author         : Fortiortech  Appliction Team
    Version        : V1.0
    Date           : 2020-07-28
    Description    : This file contains LIN function used for Motor Control.
----------------------------------------------------------------------------------------------------
                                       All Rights Reserved
------------------------------------------------------------------------------------------------- */
#include "MyProject.h"

LIN_Struc xdata Lin = {0};
uint8 xdata DMAudata[9] = {0};

uint8 AGS_New_NAD = 0; /*新NAD*/
uint8 LINIOflag = 0;
/*配置串口2的rx管脚为外部中断*/
void MODE_IO(void)
{
     
    if (LINIOflag == 1) /* 防止频繁进入 */
        return;
    LINIOflag = 1;
//    Lin.Sleep_flag = 0;         /*总线休眠标志位*/
    ClrBit(UT2_BAUD, UART2IEN); /*关闭 UART2 中断进入io模式*/
    ClrBit(P0_OE, PIN1);        /*输入模式*/
    ClrBit(P0_PU, PIN1);        /*上拉禁止*/
    /*设置EXT0==0001：配置 P0.1 为外部中断 0 接口*/
    ClrBit(LVSR, EXT0CFG2); /* P01 接口外部中断 0 配置*/
    ClrBit(LVSR, EXT0CFG1);
    SetBit(LVSR, EXT0CFG0);
    /*配置为下降沿触发中断*/
    IT01 = 1; /*电平变化触发中断*/
    IT00 = 0; /*电平变化触发中断*/
    /*配置中断优先级*/
    PX00 = 1;
    PX01 = 1;
    /*清除外部中断*/
    IF0 = 0;
    /*配置中断优先级*/
    EX0 = 1; /* 使能外部中断0*/
}

void MODE_UART(void)
{
    LINIOflag = 0;
    EX0 = 0;                 /* 关闭外部中断0  进入串口模式*/
    SetBit(PH_SEL, UART2EN); /* P3[6]as UART2_RXD; P3[7]as UART2_TXD*/
    UT2_CR = 0x50;
    UT2_BAUD = 0x604D; /*波特率可设置 = 24000000/(16/(1+ UT_BAUD[BAUD_SEL]))/(UT_BAUD+1)*/

    PSPI_UT21 = 1; /*中断优先级时最低*/
    PSPI_UT20 = 0;

    /* 配置dma传输 */
    DMA0_CR0 = 0x00;
    DMA0_LEN = 8;
    DMA0_BA = DMAudata;                                    /* DMA通道设置 */
    SetBit(DMA0_CR0, DMAIE | DMACFG0 | DMACFG2 | DMACFG1); /* 设置通道方向 */
}

/*  ----------------------------------------------------------------------------------------------*/
/*  Function Name  : LIN_Send
    /*  Description    : put_char
    /*  Date           : 2020-09-06
    /*  Parameter      : c: [输入/出]
    /*  ----------------------------------------------------------------------------------------------*/
void LIN_Send(uint8 *str, uint8 Check, uint8 Leng)
{
    uint8 i = 0;
    DMA0_LEN = Leng; /* 设置DMA长度,长度要增加一个校验数据 */
    for (i = 0; i < Leng; i++)
    {
        DMAudata[i] = str[i];
    }
    DMAudata[i] = Check;              /* 添加校验和数据 */
    ClrBit(DMA0_CR0, DMAIF);          /* 清除中断 */
    SetBit(DMA0_CR0, DMAEN | DMABSY); /* 启动DMA0，传输 */
}
/*  ----------------------------------------------------------------------------------------------*/
/*  Function Name  : LinCheck 计算数据的校验和
    /*  Description    : 输入CheckMode:校验模式 ;
                             PID:PDI;
                             Leng:数据长度;
                             str：计算数组;
    /*  Date           : 2020-09-06
    /*  Parameter      : 返回校验和
    /*  ----------------------------------------------------------------------------------------------*/
uint8 LinCheck(uint8 CheckMode, uint8 PID, uint8 Leng, uint8 *str)
{
    uint16 CheckDATA = 0;
    uint8 i = 0;
    if (CheckMode) /*增强型校验*/
    {
        CheckDATA = PID;
    }

    for (i = 0; i < Leng; i++)
    {
        CheckDATA = CheckDATA + str[i];
        if (CheckDATA > 0xff) /*校验方法*/
        {
            CheckDATA = CheckDATA - 0xff;
        }
    }
    CheckDATA = 0xff - CheckDATA;
    return (uint8)CheckDATA;
}
/*---------------------------------------------------------------------------*/
/*  Name     :   void TIM3_Init(void)
    /* Input    :   NO
    /* Output   :   NO
    /* Description: Timer3的初始化，只用于计数器使用  。5.28ms触发定时器
/*---------------------------------------------------------------------------*/
void TIM3_Init(void)
{
    ClrBit(PH_SEL, T3SEL); /* Timer3端口不使能*/
    TIM3_CR0 = 0x79; /* 011-->3M */
    TIM3_CR1 = 0x09;
    /*注意溢出中断的时间要小于调度表的时间  当前设定时间10ms*/
    TIM3__ARR = 22000; /*  IR比较中断 重装载寄存器*/
    TIM3__DR = 22000;  /*设定10ms中断  IF溢出中断 没有使能*/
    TIM3__CNTR = 1;

    PTIM31 = 1;
    PTIM30 = 0;
}

