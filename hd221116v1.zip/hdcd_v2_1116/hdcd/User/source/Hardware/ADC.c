/*  --------------------------- (C) COPYRIGHT 2020 Fortiortech ShenZhen -----------------------------
	File Name      : ADC.c
	Author         : Fortiortech  Appliction Team
	Version        : V1.0
	Date           : 2020-04-11
	Description    : This file contains .C file function used for Motor Control.
	----------------------------------------------------------------------------------------------------
									   All Rights Reserved
	------------------------------------------------------------------------------------------------- */
#include "Myproject.h"

/*  -------------------------------------------------------------------------------------------------
	Function Name : void ADC_Init(void)
	Description   : ADC硬件设备初始化配置，使能ADC，通道配置，采样时间配置，中断配置
	Input         : 无
	Output        : 无
	-------------------------------------------------------------------------------------------------*/

void ADC_Init(void)
{
	/********************ADC 端口模拟功能设置************************/
	/*
   每个通道的采样时钟周期最小值为 3
	 AD2 和 AD14 通过 FOC_CR0[UCSEL]位选择其中一个用于母线电压触发采样，硬件自动启动的 ADC 结果不会更新至ADC2_DR或者ADC14_DR寄存器，需要调用母线电压时需要设置BUSY位

	[内部]  CH14EN ADC 第 14 通道，如果只使用 FOC 自动采样母线电压功能，CH14EN 无需配置为 1
	[P1.5]  CH13EN ADC 第 13 通道
	[P1.3]  CH12EN ADC 第 12 通道
	[P2.6]  CH11EN ADC 第 11 通道
	[P1.4]  CH10EN ADC 第 10 通道
	[P1.6]  CH9EN  ADC 第 9  通道
	[P2.1]  CH8EN  ADC 第 8  通道
	[P3.4]  CH7EN  ADC 第 7  通道
	[P3.3]  CH6EN  ADC 第 6  通道
	[P3.2]  CH5EN  ADC 第 5  通道
	[P2.7]  CH4EN  ADC 第 4  通道                                                            //单电组模式：4通道母线电流采样		  三电阻模式：4通道Ic采样
	[P2.5]  CH3EN  ADC 第 3  通道                                                            //通常作为RC滤波以后的母线电流采集
	[P2.4]  CH2EN  ADC 第 2  通道，如果只使用 FOC 自动采样母线电压功能，CH2EN 无需配置为 1
	[P2.3]  CH1EN  ADC 第 1  通道                                                            //双电阻模式：1通道Ib采样  		 		  三电阻模式：1通道Ib采样
	[P2.0]  CH0EN  ADC 第 0  通道                                                            //双电阻模式：0通道Ia采样  				  三电阻模式：0通道Ia采样
	*/
	/****************************************************************/
//	ClrBit(VREF_VHALF_CR, VHALFEN); //关闭VHALF使能

    SetBit(P2_AN, P20);
	SetBit(ADC_MASK, CH0EN);
	/*母线电流采样AMP0使能*/
	SetBit(P2_AN, P27);
	SetBit(ADC_MASK, CH4EN);
	/*母线电流采样AD使能*/
	SetBit(P2_AN, P24); /*母线电流采样AD2，一般是经过RC滤波以后的母线电流*/
	SetBit(ADC_MASK, CH2EN);
	/*ntc电阻AD使能*/
	//SetBit(P3_AN, P32);
	//SetBit(ADC_MASK, CH5EN);
	/*母线电压采样AD使能*/
	SetBit(FOC_CR0, UCSEL);	  /*内部ad14采样母线电压*/
	SetBit(ADC_MASK, CH14EN); /*使能14通道*/
	ClrBit(DAC_CR, ADCRATIO); /*14 采 VCC 电压使用的分压比1/12 分压*/

	/*数据对其方式 注意左对齐时候最大0x7ff8*/
	SetBit(ADC_CR, ADCALIGN); /* ADC数据次高位对齐使能  0-->Disable 1-->Enable  */

	ADC_SYSC = 0x33; /*采样时间配置，AD0~AD7 以及 AD14 3个ADC时钟周期*/

	ClrBit(DAC_CR, ADC_SYSCH1 | ADC_SYSCH1 | ADC_SYSCH1 | ADC_SYSCH0);
	SetBit(DAC_CR, ADC_SYSCH1 | ADC_SYSCH0); /*采样时间配置，AD8~AD13 3个ADC时钟周期*/
	ClrBit(ADC_CR, ADCIE);					 /*关闭ADC中断使能*/
	ClrBit(ADC_CR, ADCIF);					 /*清除ADC中断标志位*/
	SetBit(ADC_CR, ADCEN);					 /* Enable ADC0*/
}
