/* --------------------------- (C) COPYRIGHT 2020 Fortiortech ShenZhen -----------------------------
    File Name      : MotorSpeedFunction.c
    Author         : Fortiortech  Appliction Team
    Version        : V1.0
    Date           : 2020-04-10
    Description    : This file contains .C file function used for Motor Control.
----------------------------------------------------------------------------------------------------
                                       All Rights Reserved
------------------------------------------------------------------------------------------------- */
#include <MyProject.h>

volatile CurrentOffset xdata mcCurOffset;
volatile BEMFDetect_TypeDef xdata BEMFDetect; /* BEMF检测 */
volatile uint8 BEMF2SECTION[7] = {5, 1, 3, 2, 6, 4, 7};
void Time2_BMEF_Init(void);

/* -------------------------------------------------------------------------------------------------
    Function Name  : Motor_Ready
    Description    : 电机等待状态
    Date           : 2021-01-18
    Parameter      : None
------------------------------------------------------------------------------------------------- */
void Motor_Ready(void)
{
    if (McStaSet.SetFlag.CalibFlag == 0)
    {
        MOE = 0;
        McStaSet.SetFlag.CalibFlag = 1;
        ClrBit(DRV_CR, FOCEN); //该模块关闭FOC模块
        ClrBit(DRV_CR, DRVEN); //该操作会停止DRV内部的计数，关闭载波中断
        SetBit(ADC_MASK, CH4EN | CH2EN | CH1EN | CH0EN | CH7EN);
    }
}

/* -------------------------------------------------------------------------------------------------
    Function Name  : Motor_Init
    Description    : 电机变量初始化
    Date           : 2021-01-18
    Parameter      : None
------------------------------------------------------------------------------------------------- */
void Motor_Init(void)
{
    ClrBit(ADC_MASK, CH4EN | CH1EN); // 关闭软件电流采样的ADC  FOC模块会自动根据采样模式进行采样，在初始化开启这三个通道是为了采集偏置电压
    VariablesPreInit();              // 电机相关变量初始化
    SetBit(DRV_CR, DRVEN);           // 使能DRV内部的计数，开启载波中断
}

/* ------------------------------------------------------------------------------------------------
    Function Name  : Motor_Start
    Description    : 电机启动函数
    Date           : 2021-01-18
    Parameter      : None
------------------------------------------------------------------------------------------------- */
void Motor_Start(void)
{
    if (BL_S.BLDCSetFlag == 0)
    {
        ClrBit(DRV_CR, DRVEN);                 // 关闭DRV
        TIM1_BLS_Init();                       // TIM1的CMP模式初始化
        if (mcFocCtrl.mcNtcTempFlt > Low_Temp) //温度小于0度
        {
            DRV_DR = 800;
        }
        else
        {
            DRV_DR = 700;
        }
		PI3_UKH = DRV_DR;
        BL_S.PItime = 0;
        BL_S.BLDCSetFlag = 1;  // BLDC启动时
        SetBit(DRV_CR, DRVEN); // 使能DRV
        MOE = 1;               // 使能输出
        AGS_DATA.MoveStatus = 1;
    }
}

/* ------------------------------------------------------------------------------------------------
    Function Name  : Motor_hold
    Description    : 电机启动函数
    Date           : 2021-01-18
    Parameter      : None
------------------------------------------------------------------------------------------------- */
void Motor_Hold(void)
{
    ClrBit(DRV_CR, OCS);                   /* 关闭dev比较器 */
    ClrBit(DRV_CR, DRVEN);                 /* 关闭DRV */
    DRV_DR = 300;                          /* 启动时的最小DUTY */
    ClrBit(TIM1_CR0, T1OPS0);              /* 01：16位重载定时器用于换相时间计时的上溢触发数据传输 */
    DRV_CMR = UH_PWM_COM_VL_ON + CMP_W_DO; /* 控制输出 */
    SetBit(DRV_CR, DRVEN);                 /* 使能DRV */
    MOE = 1;                               /* 关闭全局输出 */
}
/* -------------------------------------------------------------------------------------------------
    Function Name  : MotorcontrolInit
    Description    : 控制变量初始化清零,包括保护参数的初始化、电机状态初始化
    Date           : 2021-01-18
    Parameter      : None
------------------------------------------------------------------------------------------------- */
void MotorcontrolInit(void)
{
    /* -----保护参数初始化----- */
    memset(&mcFaultDect, 0, sizeof(FaultVarible)); // FaultVarible变量清零
    /*电机状态机时序变量*/
    McStaSet.SetMode = 0;
    /*外部控制环*/
    // memset(&mcFocCtrl, 0, sizeof(FOCCTRL)); // mcFocCtrl变量清零
    /*电流偏置校准变量初始化*/
    memset(&mcCurOffset, 0, sizeof(CurrentOffset)); // mcCurOffset变量清零
                                                    /* -----外部控制环参数初始化----- */
    memset(&mcFocCtrl, 0, sizeof(FOCCTRL));         // mcFocCtrl变量清零
    mcCurOffset.Iw_busOffsetSum = 16383;
    /*速度环响应参数初始化*/
    memset(&MotorSpeed, 0, sizeof(MCRAMP)); // mcSpeedRamp变量清零
}

/* -------------------------------------------------------------------------------------------------
    Function Name  : VariablesPreInit
    Description    : 初始化电机参数
    Date           : 2020-04-10
    Parameter      : None
------------------------------------------------------------------------------------------------- */
void VariablesPreInit(void)
{
    mcFaultSource = 0;
    /* -----保护参数初始化----- */
    memset(&mcFaultDect, 0, sizeof(FaultVarible)); // FaultVarible变量清零
    /* -----外部控制环参数初始化----- */
    // memset(&mcFocCtrl, 0, sizeof(FOCCTRL)); // mcFocCtrl变量清零
    /*****电机状态机时序变量***********/
    McStaSet.SetMode = 0x01; //电流校准标志位置1，其它置0
    mcFocCtrl.State_Count = 0;
}

/* -------------------------------------------------------------------------------------------------
    Function Name  : GetCurrentOffset
    Description    : 上电时，先对硬件电路的电流进行采集，写入对应的校准寄存器中。
                     调试时，需观察mcCurOffset结构体中对应变量是否在范围内。采集结束后，OffsetFlag置1。
    Date           : 2020-04-10
    Parameter      : None
------------------------------------------------------------------------------------------------- */
void GetCurrentOffset(void)
{
    if (!mcCurOffset.OffsetFlag)
    {
        SetBit(ADC_CR, ADCBSY); // 使能ADC
        while (ReadBit(ADC_CR, ADCBSY))
            ;
        mcCurOffset.Iw_busOffsetSum += ((ADC2_DR & 0x7ff8));
        mcCurOffset.Iw_busOffset = mcCurOffset.Iw_busOffsetSum >> 4;
        mcCurOffset.Iw_busOffsetSum -= mcCurOffset.Iw_busOffset;
        mcCurOffset.OffsetCount++;
        if (mcCurOffset.OffsetCount > Calib_Time)
        {
            mcCurOffset.OffsetFlag = 1;
        }
    }
}

/* -------------------------------------------------------------------------------------------------
    Function Name  : Time2_BMEF_Init
    Description    : BMF对应Time2的初始化
    Date           : 2020-04-10
    Parameter      : None
------------------------------------------------------------------------------------------------- */
void Time2_BMEF_Init(void)
{
    /*-------------------------------------------------------------------------------------------------
    先停止计数，配置完寄存器后，最后启动计数
    -------------------------------------------------------------------------------------------------*/
    ClrBit(TIM2_CR1, T2CEN); // 0，停止计数；1,使能计数

    /*-------------------------------------------------------------------------------------------------
    时钟分频设置(T2PSC)
    000:cpuclk(24MHz)         001:cpuclk/2^1(12MHz)   010:cpuclk/2^2(6MHz)    011:cpuclk/2^3(3MHz)
    100:cpuclk/2^4(1.5MHz)    101:cpuclk/2^5(750KHz)  110:cpuclk/2^6(375KHz)  111:cpuclk/2^7(187.5KHz)
    -------------------------------------------------------------------------------------------------*/
    SetBit(TIM2_CR0, T2PSC2); // 111:cpuclk/2^7(187.5KHz)尽量慢快了计数器可能溢出
    SetBit(TIM2_CR0, T2PSC1);
    SetBit(TIM2_CR0, T2PSC0);
    /*-------------------------------------------------------------------------------------------------
    /模式选择
    T2MODE1，T2MODE0
    00--输入Timer模式；01--输出模式
    10--输入Count模式；11--QEP或者ISD模式
    -------------------------------------------------------------------------------------------------*/
    ClrBit(TIM2_CR0, T2OCM);  // 0-->Timer模式       1-->输出模式
    ClrBit(TIM2_CR0, T2IRE);  // 比较匹配中断/脉宽检测中断
    ClrBit(TIM2_CR0, T2CES);  // 周期沿选择
    ClrBit(TIM2_CR0, T2MOD1); // 01--输出模式
    SetBit(TIM2_CR0, T2MOD0);

    ClrBit(TIM2_CR1, T2IR); /* 清除标志位 比较中断*/
    ClrBit(TIM2_CR1, T2IP); /* 清除标志位*/
    ClrBit(TIM2_CR1, T2IF); /* 清除标志位 溢出中断*/

    ClrBit(TIM2_CR1, T2IPE); /*输入Timer PWM周期检测中断使能 0-->Disable  1-->Enable*/
    SetBit(TIM2_CR1, T2IFE); /*计数器上溢中断使能 0-->Disable  1-->Enable*/

    TIM2__ARR = 60000; // TIM2 Period = 0.32s
    TIM2__DR = TIM2__ARR;
    TIM2__CNTR = 0;

    SetBit(TIM2_CR1, T2CEN); /* TIM3使能    0-->Disable  1-->Enable*/

    PTIM21 = 1;
    PTIM20 = 0;
}
/* -------------------------------------------------------------------------------------------------
    Function Name  : BEMFInit
    Description    : 初始化检测bemf
    Date           : 2020-04-10
    Parameter      : None
------------------------------------------------------------------------------------------------- */
void BEMFInit(void)
{
    MOE = 0;                                           /* 检测前先关闭输出 */
    ClrBit(DRV_CR, DRVEN);                             // 关闭DRV
    BEMFDetect.BEMFState = 0;                          /* 初始化状态机 */
    BEMFDetect.BEMFSpeed = 0;                          /* 清空速度 */
    BEMFDetect.BEMFSpeedBase = 0;                      /* 清空速度 */
    BEMFDetect.BEMFStatus = 0;                         /*  */
    BEMFDetect.FRStatus = 0xFF;                        /* 方向 */
    BEMFDetect.BEMFTimeCount = BEMF_START_DETECT_TIME; /* 初始化检测时间200ms */
    BEMFDetect.BEMFStep = 0;                           /* 初始化计数值 */
    /* 初始化定时器2 用来计数 */
    Time2_BMEF_Init(); /* 初始化定时器2用来计算速度 */

    /* 初始比较器 中断*/

    // CMP_CR2： 有内置电阻3比较器模式，负短接虚拟中性点，正端接三相反电动势，比较结果输出至 CMP0OUT CMP1OUT CMP2OUT
    /*****AMP 端口模拟功能设置******/
    SetBit(P1_AN, P14); /*AMP0 Pin设置为模拟模式  +*/
    SetBit(P1_AN, P16); /*AMP0 Pin设置为模拟模式  -*/
    SetBit(P2_AN, P21); /*AMP0 Pin设置为模拟模式  O*/
    ClrBit(CMP_CR2, CMP0EN);
    SetReg(CMP_CR2, CMP0MOD0 | CMP0MOD1, CMP0MOD0);        // CMPMOD：01,内置虚拟中心点电阻的BEMF模式
    SetReg(CMP_CR2, CMP0SEL0 | CMP0SEL1, 0x00);            // CMP0SEL：00,  3比较器轮询模式
    SetReg(CMP_CR1, CMP0HYS0 | CMP0HYS1 | CMP0HYS2, 0X07); //迟滞电压选择 100: +-5mV
    ClrBit(CMP_CR3, SAMSEL1);                              // CMP_CR3： 使能比较器CMP0~2和ADC的采样功能
    ClrBit(CMP_CR4, CMP0_FS);                              // CMP1/2功能转移	仅CMP0_MOD=01时有效
    ClrBit(CMP_SR, CMP0IF | CMP1IF | CMP2IF);              // SAMSEL：10,只在ON时采样
    CMP_SAMR = cmp_samr;
    SetReg(CMP_CR0, CMP0IM0 | CMP0IM1 | CMP1IM0 | CMP1IM1 | CMP2IM0 | CMP2IM1, 0x3f); // CMP1/2功能转移	仅CMP0_MOD=01时有效
    PCMP1 = 0;
    PCMP0 = 1;
    SetBit(CMP_CR2, CMP0EN); //开三个比较器
}

/* -------------------------------------------------------------------------------------------------
    Function Name  : GetBEMFStatus
    Description    : 读反电动势状态
    Date           : 2020-04-10
    Parameter      : None
------------------------------------------------------------------------------------------------- */
uint8 GetBEMFStatus(void)
{
    uint8 BEMFStatus = 0;
    if (ReadBit(CMP_SR, CMP2OUT))
        BEMFStatus += 4; //比较器2的比较结果
    if (ReadBit(CMP_SR, CMP1OUT))
        BEMFStatus += 2; //比较器1的比较结果
    if (ReadBit(CMP_SR, CMP0OUT))
        BEMFStatus += 1; //比较器0的比较结果
    return BEMFStatus;   //返回比较器的比较结果  BEMFStatus以bit的方式存储比较器的比较结果
}

/* -------------------------------------------------------------------------------------------------
    Function Name  : GetBEMFStatus
    Description    : 根据当前的步数推算上一步正转和反转对应的步值
    Date           : 2020-04-10
    Parameter      : None
------------------------------------------------------------------------------------------------- */
uint8 CalculateStep(uint8 Step)
{
    uint8 i = 0;
    for (i = 0; i < 6; i++)
    {
        if (Step == BEMF2SECTION[i])
        {
            return i;
        }
    }
    return 6; //数据错误返回6
}

/* -------------------------------------------------------------------------------------------------
    Function Name  : BEMFDetectFunc
    Description    : 比较器中断触发，开始检测方向和速度
    Date           : 2021-01-18        BEMF2SECTION[8] = {0, 1, 3, 2, 5, 6, 4, 7};
    Parameter      : None
    BEMF2SECTION  = {5, 1, 3, 2, 6, 4, 7};
------------------------------------------------------------------------------------------------- */
void BEMFDetectFunc(void)
{

    BEMFDetect.BEMFStatus = CalculateStep(GetBEMFStatus()); //实际返回的是123456，步值
    if (BEMFDetect.BEMFStatus < 6)                          /* 读到的节拍值在合理的范围之内开始计算 */
    {
        BEMFDetect.StepTime = TIM2__CNTR;
        TIM2__CNTR = 0;               /* 清除定时器2计数器 */
        switch (BEMFDetect.BEMFState) /* 状态机 */
        {
        case 0:                      /* 第一次比较中断 */
            BEMFDetect.StepTime = 0; /* 首次运行清空计数器 */

            BEMFDetect.OldStep = BEMFDetect.BEMFStatus; /// BEMFDetect.OldStep(0~5)
            BEMFDetect.BEMFState = 1;
            break;

        case 1: /* 通过两次的比较值来判断方向  */

            if (BEMFDetect.BEMFStatus == ((BEMFDetect.OldStep + 1) % 6)) /* 上次值小于本次值 */
            {
                BEMFDetect.FRStatus = CW; /* 方向正*/
                BEMFDetect.BEMFState = 2;
            }
            else if (BEMFDetect.OldStep == ((BEMFDetect.BEMFStatus + 1) % 6)) /* 上次值大于本次值 */
            {
                BEMFDetect.FRStatus = CCW; /* 方向反 */
                BEMFDetect.BEMFState = 2;
            }
            BEMFDetect.OldStep = BEMFDetect.BEMFStatus;
            BEMFDetect.BEMFStep = 0; /* 清空计数器 */
            break;

        case 2: /* 方向确定后计数正确的换向步数 ，换向值错误要返回到1重新计数  */

            if (BEMFDetect.FRStatus == CW) /* 方向正*/
            {
                if (BEMFDetect.BEMFStatus == ((BEMFDetect.OldStep + 1) % 6))
                {
                    BEMFDetect.BEMFStep++;
                }
                else /* 数值不正确 */
                {
                    BEMFDetect.FRStatus = 0xff; /* 重新确定方向 */
                    BEMFDetect.BEMFState = 1;   /* 返回状态机1 */
                    BEMFDetect.BEMFStep = 0;    /* 清空计数器 */
                }
                /* 本次值始值大于上次的数值 */
            }
            else if (BEMFDetect.FRStatus == CCW) /* 反转 */
            {
                if (BEMFDetect.OldStep == ((BEMFDetect.BEMFStatus + 1) % 6)) /* 上次的值始值大于本次的值 */
                {
                    BEMFDetect.BEMFStep++;
                }
                else /* 数值不正确 */
                {
                    BEMFDetect.FRStatus = 0xff; /* 重新确定方向 */
                    BEMFDetect.BEMFState = 1;   /* 返回状态机1 */
                    BEMFDetect.BEMFStep = 0;    /* 清空计数器 */
                }
            }
            BEMFDetect.OldStep = BEMFDetect.BEMFStatus;
            if (BEMFDetect.BEMFStep > 30) /* 正确换向的次数 */
            {

                BEMFDetect.BEMFState = 3;
                CMP0_Open_Init(); /* 关闭比较器中断 */
				
								if (Uset.Stall_cont <= 4)
			{ 
				Motor_Hold();
			}
               
            }
            break;

        default:
            break;
        }
    }
}
