#include <MyProject.h>

bit idata Dir_Comm; //用于记录启动进程中当前扇区需要检测的跳变沿  0：上升沿  1：下降沿

BL_S_TypeDef idata BL_S; //启动算法相关变量
uint8 BLDCSetFlag;

uint8 StartPos = 1;

void TIM1_BLS_Init(void)
{
	memset(&BL_S, 0, sizeof(BL_S_TypeDef)); // 电机启动参数清零
	CMP0_Open_Init();
	SetBit(TIM1_CR0, 0x80);	  // RCEN禁止
	ClrBit(TIM1_CR0, T1BCEN); // 0:禁止基本定时器  1:使能基本定时器
	SetBit(TIM1_CR0, T1CFLT1);
	ClrBit(TIM1_CR0, T1CFLT0); // 1个平均换相时间作为60度的时间基准--在启动强拖阶段，对换相周期不进行滤波
	ClrBit(TIM1_CR0, T1FORC);  //禁止强制换相
	ClrBit(TIM1_CR0, T1OPS1);  //软件换相，在启动的强拖阶段需要进行软件换向
	ClrBit(TIM1_CR0, T1OPS0);
	ClrBit(TIM1_CR1, T1BAPE); //不使能
	ANGLE_MASK(15);			  //续流屏蔽
	ClrBit(TIM1_CR2, T1BRS);  //强拖阶段，基本定时器按照软件换向之间的时间计数
	ANGLE_DELAY(30);		  //延迟换向
	ClrBit(TIM1_CR3, T1PSC2);
	SetBit(TIM1_CR3, T1PSC1); // 010    6MHz
	ClrBit(TIM1_CR3, T1PSC0);
	/***************采样相关设置***************/
	ClrBit(TIM1_CR3, T1TIS1); //输入来源CMP
	SetBit(TIM1_CR3, T1TIS0);
	/***************采样相关设置***************/
	ClrBit(TIM1_CR3, T1INM1);
	SetBit(TIM1_CR3, T1INM0); // 8个时钟周期滤波
	TIM1_CR4 = 1;			  // 强拖启动的第一拍
	TIM1_DBR1 = UH_PWM_COM_VL_ON + CMP_W_DO;
	TIM1_DBR2 = UH_PWM_COM_WL_ON + CMP_V_UP;
	TIM1_DBR3 = VH_PWM_COM_WL_ON + CMP_U_DO;
	TIM1_DBR4 = VH_PWM_COM_UL_ON + CMP_W_UP;
	TIM1_DBR5 = WH_PWM_COM_UL_ON + CMP_V_DO;
	TIM1_DBR6 = WH_PWM_COM_VL_ON + CMP_U_UP;
	TIM1_DBR7 = TIM1_DBR6;

	ClrBit(TIM1_IER, T1UPD);
	ClrBit(TIM1_IER, T1MAME);
	ClrBit(TIM1_IER, T1ADIE);
	ClrBit(TIM1_IER, T1BOIE); //发生上溢事件，意味着电机转速很慢或者已经停止
	ClrBit(TIM1_IER, T1ROIE);
	ClrBit(TIM1_IER, T1WTIE);
	ClrBit(TIM1_IER, T1PDIE); //位置检测事件，电机在转动；可在通过对转速的分析来判断电机状态
	ClrBit(TIM1_IER, T1BDIE);

	TIM1_SR = 0x00;
	TIM1_BCOR = 0xff00;
	TIM1__BCCR = 0xff00;
	TIM1__BARR = 0xfff0;
	TIM1__RARR = 0xfff0;
	TIM1__RCNTR = 0;
	TIM1__BCNTR = 0;

	SetBit(TIM1_IER, T1WTIE);		   // 写入时序中断
	SetBit(TIM1_CR0, T1BCEN);		   //使能timer1的基本定时器
	SetBit(TIM1_CR0, T1RWEN | T1RCEN); //使能重装载定时器
	PTIM11 = 0;
	PTIM10 = 1;
}
// 启动算法
uint8 taper = 0;
void BL_S_Function(BL_S_TypeDef *BLS)
{
		static uint8 BLSTime = 0;
	if(BLS->Hard_Count == 0)
	{
		BLSTime = 40;
	}

	
	if (BLS->BLDCSetFlag == 1) //加速阶段
	{
		BLS->Startime++;

		if (BLS->Startime > BLSTime)
		{
			BLS->Startime = 0;
			SetBit(TIM1_IER, T1UPD); //软件对此位写1触发数据传输
			BLS->Hard_Count++;
			taper = TIM1_CR4 & 0x07;
			BLSTime=BLSTime-2;
		}

		if (BLS->Hard_Count > 6) //换向步数大于6切换到正常模式
		{
			TIM1__RCNTR = 0x1060;
			// SetBit(TIM1_IER, T1UPD); //软件对此位写1触发数据传输
			SetBit(TIM1_CR0, T1OPS0);
			SetBit(TIM1_CR2, T1BRS);  //强拖阶段，基本定时器按照软件换向之间的时间计数
			ControlLoopOut = DRV_DR; //给定当前DUTY，防止输出突然降低
			BLS->BLDCSetFlag = 2;	 //切换至硬件运行状态
		}
	}
}
