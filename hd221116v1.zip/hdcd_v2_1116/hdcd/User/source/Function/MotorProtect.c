/* --------------------------- (C) COPYRIGHT 2020 Fortiortech ShenZhen -----------------------------
    File Name      : MotorControl.c
    Author         : Fortiortech  Appliction Team
    Version        : V1.0
    Date           : 2020-04-10
    Description    : This file contains .C file function used for Motor Control.
----------------------------------------------------------------------------------------------------
                                       All Rights Reserved
------------------------------------------------------------------------------------------------- */
#include <MyProject.h>

/*  -------------------------------------------------------------------------------------------------
    Function Name  : FaultProcess
    Description    : 错误处理函数
    Date           : 2020-04-10
    Parameter      : None
    ------------------------------------------------------------------------------------------------- */
void FaultProcess(void)
{
    MOE = 0;
    BL_S.BLDCSetFlag = 0;
    ClrBit(DRV_CR, DRVEN);
    mcState = mcFault;
}

/*  -------------------------------------------------------------------------------------------------
    Function Name  : Fault_OverUnderVoltage
    Description    : 过压欠压保护函数：程序每5ms判断一次，母线电压大于过压保护值时，计数器加一，计数器值超过20次，判断为过压保护，关闭输出;反之，计数器慢慢减
                     同理，欠压保护。
                     电机过欠压保护状态下，母线电压恢复到欠压恢复值以上，过压恢复值以下时，计数器加一，超过200次后，恢复。根据档位信息来决定恢复到哪个状态。
                     电压电路检测故障  检测到的系统电压小于5v大于40v 认为电压检测故障

    Date           : 2020-04-10
    Parameter      : h_Fault: [输入/出]
    ------------------------------------------------------------------------------------------------- */
void Fault_OverUnderVoltage(void)
{
    /*******************判断电压检测电路是否正常--检测到的电压不在合理的范围之内*******************/
    if ((mcFocCtrl.mcDcbusFlt > SENSOR_MAX_VALUE) || (mcFocCtrl.mcDcbusFlt < SENSOR_MIN_VALUE))
    {
        mcFaultDect.SensorVoltageCnt++;
        if (mcFaultDect.SensorVoltageCnt > Sensor_Vlotage_COUNT)
        {
            AGS_DATA.FaultVoltageSensor = 1;
        }
    }
    else
    {
        mcFaultDect.SensorVoltageCnt = 0;
        AGS_DATA.FaultVoltageSensor = 0;
    }

    /*********下面部分检测过压欠压保护*********/
    /************过压保护*********/
    /* 输入的端电压高于 16.3V 时， 持续超过 400ms 后， 记为过电压故障*/
    if (mcFocCtrl.mcDcbusFlt > OVER_PROTECT_VALUE) //母线电压大于过压保护值时，计数，超过20次，判断为过压保护，关闭输出;反之，计数器慢慢减
    {

        mcFaultDect.OverVoltDetecCnt++;
        if (mcFaultDect.OverVoltDetecCnt > Over_Voltage_Time)
        {
            mcFaultDect.OverVoltDetecCnt = 0;
            mcFaultSource = FaultOverVoltage;
            AGS_DATA.FaultOverVoltage = 1; /*驱动器过压故障*/
        }
    }
    else if (mcFaultDect.OverVoltDetecCnt > 0)
    {
        mcFaultDect.OverVoltDetecCnt = 0;
    }

    /*********欠压保护*********/
    /* 输入的端电压低于 8.5V 时， 持续超过 700ms 后， 记为低电压故障*/
    if (mcFocCtrl.mcDcbusFlt < UNDER_PROTECT_VALUE) /* 一级欠压保护 打开格栅禁止操作 */
    {
        if (mcState != mcRun)
        {
            mcFaultDect.UnderVoltDetecCnt++;
        }
        if (mcFaultDect.UnderVoltDetecCnt > Under_Vlotage_Time)
        {
            mcFaultDect.UnderVoltDetecCnt = 0;
            mcFaultSource = FaultUnderVoltage;
            AGS_DATA.FaultUnderVoltage = 1; /*驱动器欠压故障*/
        }
    }
    else
    {
        if (mcFaultDect.UnderVoltDetecCnt)
            mcFaultDect.UnderVoltDetecCnt = 0;
    }

    /*******过压欠压保护恢复*********/

    if ((mcFocCtrl.mcDcbusFlt < OVER_RECOVER_VALUE) && (mcFocCtrl.mcDcbusFlt > UNDER_RECOVER_VALUE))
    {
        mcFaultDect.VoltRecoverCnt++;
        if (mcFaultDect.VoltRecoverCnt > Voltage_Recover_Time) //连续检测2000ms，若正常则恢复
        {
            if (AGS_DATA.FaultOverVoltage || AGS_DATA.FaultUnderVoltage)
            {
                mcFaultSource = FaultNoSource;
            }

            mcFaultDect.VoltRecoverCnt = 0;
            AGS_DATA.FaultUnderVoltage = 0; //清除驱动器欠压故障
            AGS_DATA.FaultOverVoltage = 0;  //清除驱动器过压故障
        }
    }
    else
    {
        mcFaultDect.VoltRecoverCnt = 0;
    }
}

/*  -------------------------------------------------------------------------------------------------
    Function Name  : Fault_Overcurrent 软件过流保护
    Description    :
    Date           : 2020-04-10
    Parameter      : h_Cur: [输入/出]
    ------------------------------------------------------------------------------------------------- */
unsigned int OverSoftCurrentValue_test;
void Fault_Overcurrent(void)
{
    if (mcFocCtrl.mcIbusFlt >= OverSoftCurrentValue)
    {
        OverSoftCurrentValue_test = OverSoftCurrentValue;
        mcFaultDect.OverCurrentCnt++;
        if (mcFaultDect.OverCurrentCnt >= OverSoftCurrentTime)
        {
            mcFaultDect.OverCurrentCnt = 0;
            // AGS_DATA.MotorElectronicFault = 1; //驱动电机电子模块故障
            //  mcFaultSource = FaultSoftOVCurrent;
            //  FaultProcess();
            //  mcState = mcFault;
        }
    }
    else
    {
        if (mcFaultDect.OverCurrentCnt > 0)
        {
            mcFaultDect.OverCurrentCnt--;
        }
    }
}
/*  -------------------------------------------------------------------------------------------------
    Function Name  : Fault_OverTemp
    Description    : 驱动电机温度 检测，检测电机温度和温度检测电路是否故障
    Date           : 2021-03-19
    Parameter      : h_Fault: [输入/出]
    ------------------------------------------------------------------------------------------------- */
void Fault_OverTemp(void)
{
    /*******温度检测传感器故障，包括传感器短路和开路*********/
    if ((mcFocCtrl.mcNtcTempFlt < OverHeat_Min) || (mcFocCtrl.mcNtcTempFlt > OverHeat_Max))
    {

        mcFaultDect.OverheatCnt++;
        if (mcFaultDect.OverheatCnt > OverHeatTime)
        {
            AGS_DATA.FaultTempSensor = 1; /*驱动电机温度传感器故障 ，检测的温度值不在合理的范围 */
        }
    }
    else /*******温度检测温度*********/
    {
        if (mcFocCtrl.mcNtcTempFlt < OverHeatValue1) /* 一级过温保护 保护温度125度 打开进气格栅*/
        {
            mcFaultDect.OverheatCnt++;
            if (mcFaultDect.OverheatCnt > OverHeatTime)
            {
                AGS_DATA.FaultOverheat = 1;
                mcFaultSource = FaultOverTemp;
            }
        }
        else
        {
            if (mcFaultDect.OverheatCnt)
                mcFaultDect.OverheatCnt--;
        }

        /*******过温保护恢复*********/
        if (mcFocCtrl.mcNtcTempFlt > RecoverHeatValue) /* 温度值小于120度 恢复电机*/
        {
            mcFaultDect.HeatRecoverCnt++;
            if (mcFaultDect.HeatRecoverCnt > Voltage_Recover_Time) /* 连续检测2000ms，若正常则恢复 */
            {
                if (AGS_DATA.FaultOverheat) /* 清除高温故障 */
                    mcFaultSource = FaultNoSource;
                mcFaultDect.HeatRecoverCnt = 0;
                AGS_DATA.FaultOverheat = 0;
            }
        }
        else
        {
            mcFaultDect.HeatRecoverCnt = 0;
        }
    }
}

/*  -------------------------------------------------------------------------------------------------
    Function Name  : Fault_OverTemp
    Description    : 驱动电机电路检查
    Date           : 2021-03-19
    Parameter      : h_Fault: [输入/出]
    ------------------------------------------------------------------------------------------------- */
void CheckCircuit(uint16 checktime)
{
}

/*  -------------------------------------------------------------------------------------------------
    Function Name  : Fault_Detection
    Description    : 保护函数，因保护的时间响应不会很高，采用分段处理，每5个定时器中断执行一次对应的保护
                     常见保护有过欠压、过温、堵转、启动、缺相等保护，调试时，可根据需求，一个个的调试加入。
    Date           : 2020-04-10
    Parameter      : None
    ------------------------------------------------------------------------------------------------- */
void Fault_Detection(void)
{

    if (VoltageProtectEnable == 1) //过压保护使能
    {
        Fault_OverUnderVoltage();
    }

    if (OSCurrentProtectEnable == 1) //软件过流保护
    {
        Fault_Overcurrent();
    }
}

/*  -------------------------------------------------------------------------------------------------
    Function Name  : Fault_Stall
    Description    : 堵转保护函数
                     使用PDIF中断的标志位，若是启动该中断，则堵转保护出错
    Date           : 2021-03-19
    Parameter      : h_Fault: [输入/出]
    ------------------------------------------------------------------------------------------------- */
/* uint16 BCCR_test = 0;
uint16 BCOR_test = 0;
uint16 MINB_SET = 0;
uint16 MAXB_SET = 0; */
uint16 ISPEED = 0; /* 当前运行电流 */
uint16 SPED1 = 0;  /* 当前速度 */
uint16 SPED2 = 0;  /* 当前速度 */
uint16 timecont = 0;
void Fault_Stall(void)
{

    uint8 StallCONT = 0;   /* 堵转计时器 */
    uint16 Stallvalue = 0; /* 设置堵转速度 */
    uint16 StallIbus = 0;  /* 设置堵转的电流 */

    uint16 DRV_value = 0;
    SPED1 = TIM1_BCOR;

    ISPEED = TIM1__ITRIP;

    if (BL_S.BLDCSetFlag == 2)
    {
        timecont++; /* 屏蔽启动加速阶段的额高速大电流 */
    }
    else
    {
        timecont = 0;
        mcFaultDect.Stall_COUNT = 0;
    }

    if ((AGS_SelfLearn.LearnFlag != 15)) /* 自学习运行时候堵转 */
    {
        Stallvalue = Motor_Stall_Speed_MID;
        StallIbus = 3400; /* 堵转电流 */
    }
    else /* 正常运行时候的堵转触发 */
    {
        if (Uset.Run_flag > 2) /* 减速阶段的堵转电流 */
        {
            Stallvalue = MOTOR_StallSPEED_RPM;
            StallIbus = 2200; /* 堵转电流 */
        }
        else
        {
            Stallvalue = Motor_Stall_Speed_MID;
            StallIbus = 3400; /* 堵转电流 */
        }
    }
    if (mcFocCtrl.mcDcbusFlt < V105_VALUE) /* 电压低于10.5V */
    {
        StallIbus = StallIbus + 400;
    }
    if (mcFocCtrl.mcNtcTempFlt > Low_Temp) /* 温度小于0度 */
    {
        if (mcFocCtrl.mcDcbusFlt < V105_VALUE)
            StallIbus = StallIbus + 700; /* 低温不低压 */
        else
            StallIbus = StallIbus + 900; /* 低温低压 */
    }

    if (((BL_S.BLDCSetFlag > 0) && (SPED1 > Stallvalue) && /*TIM1_BCOR>最小切换时间*/
         (timecont >= MOTOR_STALL_COUNT) &&                /*加速启动时间300ms*/
         (mcFocCtrl.mcIbusFlt > StallIbus)) ||
        ((SPED1 < 0x800) && (BL_S.BLDCSetFlag == 2)) /* 运行失步判断 */
    )

    {
        mcFaultDect.Stall_COUNT++;
        if (mcFaultDect.Stall_COUNT > 4)
        {
            StallFault = 1;
        }
    }
    else
    {
        if (mcFaultDect.Stall_COUNT)
            mcFaultDect.Stall_COUNT--;
    }

    /* 判断堵转 */
}