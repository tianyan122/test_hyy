/*  --------------------------- (C) COPYRIGHT 2020 Fortiortech ShenZhen -----------------------------
    File Name      : AMP.c
    Author         : Fortiortech  Appliction Team
    Version        : V1.0
    Date           : 2020-04-11
    Description    : This file contains .C file function used for Motor Control.
    ----------------------------------------------------------------------------------------------------
                                       All Rights Reserved
    ------------------------------------------------------------------------------------------------- */
#include "Myproject.h"

/*  -------------------------------------------------------------------------------------------------
    Function Name : void AMP_Init(void)
    Description   : AMP初始化配置,使能运放电压VHALF，配置运放的电流采样正向输入，反向输入和输出，包括I_BUS,I_U,I_V
                    并使能对应的运放
    Input         : 无
    Output        :   无
    -------------------------------------------------------------------------------------------------*/
void AMP_Init(void)
{
    /*运放端口使能*/
    /*****AMP 端口模拟功能设置******/
    SetBit(P3_AN, P31);     /*AMP0 Pin设置为模拟模式  +*/
    SetBit(P3_AN, P30);     /*AMP0 Pin设置为模拟模式  -*/
    SetBit(P2_AN, P27);     /*AMP0 Pin设置为模拟模式  O*/
    SetBit(AMP_CR, AMP0EN); /*AMP0 Enable*/

    /*
                000-->放大倍数由外部配置
            001-->2X 010-->4X 011-->8X 100-->16X 101-->32X Others-->32X
    */
    SetBit(AMP0_GAIN, AMP0_GAIN2); // 0x80
    ClrBit(AMP0_GAIN, AMP0_GAIN1); // 0x40
    ClrBit(AMP0_GAIN, AMP0_GAIN0); // 0x20
}