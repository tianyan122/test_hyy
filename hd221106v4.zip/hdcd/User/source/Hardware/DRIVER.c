/*  --------------------------- (C) COPYRIGHT 2020 Fortiortech ShenZhen -----------------------------
    File Name      : DRIVER.c
    Author         : Fortiortech  Appliction Team
    Version        : V1.0
    Date           : 2020-04-11
    Description    : This file contains .C file function used for Motor Control.
    ----------------------------------------------------------------------------------------------------
                                       All Rights Reserved
    ------------------------------------------------------------------------------------------------- */
#include "Myproject.h"

/*  -------------------------------------------------------------------------------------------------
    Function Name : void Driver_Init(void)
    Description   : Driver初始化配置
    Input         : 无
    Output                :   无
    -------------------------------------------------------------------------------------------------*/
void Driver_Init(void)
{
    DRV_ARR = PWM_VALUE_LOAD - 1;    /* 载波频率的周期值 2,887*/
    DRV_DTR = PWM_LOAD_DEADTIME - 1; /* 死区时间*/
    DRV_DR = 0;                      /* 输出DUTY*/

    /*空闲电平*/
    DRV_CMR &= 0x003f; /*UH/VH/WH UL/VL/WL设置有效电平  0高电平有效*/
    DRV_OUT &= 0x80;   /*空闲电平全部为低电平*/

    /*清中断标志位*/
    ClrBit(DRV_SR, DCIF);

    /**************************************************
        DRV比较匹配中断模式
        当计数值等于DRV_COMR时，根据DCIM的设置判断是否产生中断标记
        00：不产生中断        01：上升方向
        10：下降方向         11：上升/下降方向
    *************************************************/
    SetBit(DRV_SR, DCIM1);
    ClrBit(DRV_SR, DCIM0);
    ClrBit(DRV_SR, DCIP); /*0-->1个计数周期产生中断  1-->2个计数周期产生中断*/

    /*中断比较值*/
    DRV_COMR = 1; /*在载波的正中间产生中断*/

    /*中断优先级*/
    PDRV1 = 1; /*中断优先级设置为3，*/
    PDRV0 = 0;

    ClrBit(DRV_CR, OCS);   /* 比较值来源 DRV_DR */
    ClrBit(DRV_CR, FOCEN); /*禁止foc*/

    /*  MESEL为0，ME模块工作在BLDC模式
        MESEL为1，ME模块工作在FOC/SVPWM/SPWM模式*/
    ClrBit(DRV_CR, MESEL); /* MESEL为0，ME模块工作在BLDC模式 ---方波程序*/

    SetBit(DRV_CR, DRVEN); /*计数器使能                  0-->Disable     1-->Enable*/
    ClrBit(DRV_CR, DRPE);  /*计数器比较值预装载使能       0-->Disable     1-->Enable*/
    SetBit(DRV_CR, DRVOE); /*Driver输出使能              0-->Disable     1-->Enable*/
}
