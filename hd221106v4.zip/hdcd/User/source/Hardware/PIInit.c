/*  --------------------------- (C) COPYRIGHT 2020 Fortiortech ShenZhen -----------------------------
    File Name      : PIInit.c
    Author         : Fortiortech  Appliction Team
    Version        : V1.0
    Date           : 2020-04-11
    Description    : This file contains PI initial function used for Motor Control.
    ----------------------------------------------------------------------------------------------------
                                       All Rights Reserved
    ------------------------------------------------------------------------------------------------- */
/* Includes -------------------------------------------------------------------------------------*/
#include "Myproject.h"
/*  ----------------------------------------------------------------------------------------------*/
/*  Function Name  : PI3_Init
    /*  Description    : 速度环参数初始化
    /*  Date           : 2021-03-22
    /*  Parameter      : None
    /*  ----------------------------------------------------------------------------------------------*/
void PI3_Init(void)
{
    PI3_KP  = SKP;
    PI3_KI  = SKI;
    PI3_UKH = 0;
    PI3_UKL = 0;
    PI3_EK  = 0;
    PI3_EK1 = 0;
    PI3_KD = SKD;
    PI3_EK2 = 0;
    PI3_UKMAX = SOUTMAX;  //最大限幅外部设置
    PI3_UKMIN = SOUTMIN;
    SetBit(PI_CR, PI3STA);           // Start PI
    while (ReadBit(PI_CR, PIBSY));
}
