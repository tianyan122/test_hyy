/*  -------------------------- (C) COPYRIGHT 2020 Fortiortech ShenZhen ---------------------------*/
/*  File Name      : AddFunction.c
/*  Author         : Fortiortech  Appliction Team
/*  Version        : V1.0
/*  Date           : 2020-08-21
/*  Description    : This file contains  function used for Motor Control.
/*  ----------------------------------------------------------------------------------------------*/
/*                                     All Rights Reserved
/*  ----------------------------------------------------------------------------------------------*/
#include "MyProject.h"
#define MAIN_RUN 0x0D01
/* Private variables ---------------------------------------------------------*/
/*电机保护相关*/
volatile FaultStateType mcFaultSource;   //错误状态标志位
volatile FaultVarible idata mcFaultDect; //错误计数
volatile LINdata xdata AGS_DATA;
/*电机控制变量*/
bit idata FR;         /* 电机运行方向 */
bit idata StallFault; /* 堵转故障 */
volatile FOCCTRL xdata mcFocCtrl;
volatile MCRAMP idata MotorSpeed;
/*转动设置*/
volatile UserSET idata Uset;
volatile uint8 One_flag = 0;
volatile uint8 StickTime = 5;
volatile unsigned char LinBack = 0;
volatile unsigned char PreManualDirection = 2;
volatile unsigned char CurrentManualDirection = 2;
volatile unsigned char EnterBootCnt = 0;
volatile uint16 NoReasonFalutCnt = 0;

void One_flagsys(uint8 Target1);
uint8 TargetCnt = 0; /* 连续接收计数 */
/*  -------------------------------------------------------------------------------------------------
    Function Name  : StarRampDealwith
    Description    :
    Date           : 2020-04-10
    Parameter      : None
    ------------------------------------------------------------------------------------------------- */
void StarRampDealwith(void)
{
    uint8 ANGLE_MTemp, ANGLE_DTemp;

    if ((BL_S.BLDCSetFlag == 2) && (mcState == mcRun))
    {
        /*  -------------------------------------------------------------------------------------------------
                屏蔽续流时间（角度）设置
                -------------------------------------------------------------------------------------------------*/
        ANGLE_MTemp = (uint8)(TIM1_CR1 & 0x7F); //读取当前的续流屏蔽和延迟换相
        ANGLE_DTemp = (uint8)(TIM1_CR2 & 0x7F);

        if (ANGLE_MASK_R(Motor_Mask_Angle) > ANGLE_MTemp) //如果目标的续流屏蔽角度 > 当前续流屏蔽角度
        {
            TIM1_CR1 = (TIM1_CR1 & (0x80)) | (ANGLE_MTemp + 1); //当前续流屏蔽角度+1
        }
        else if (ANGLE_MASK_R(Motor_Mask_Angle) < ANGLE_MTemp) //如果目标的续流屏蔽角度 < 当前续流屏蔽角度
        {
            TIM1_CR1 = (TIM1_CR1 & (0x80)) | (ANGLE_MTemp - 1); //当前续流屏蔽角度-1
        }
        /*  ------------------------------------------------------------------------------------------------
            检测到过零点后的延迟换相时间（角度）设置
            -------------------------------------------------------------------------------------------------*/
        if ((ANGLE_DELAY_R((30 - Motor_Advance_Angle)) + 0x01) > ANGLE_DTemp) //如果目标的延迟换相蔽角度 > 当前延迟换相角度
        {
            TIM1_CR2 = (TIM1_CR2 & (0x80)) | (ANGLE_DTemp + 1); //当前延迟换相角度+1
        }
        else if ((ANGLE_DELAY_R((30 - Motor_Advance_Angle)) + 0x01) < ANGLE_DTemp) //如果目标的延迟换相蔽角度 < 当前延迟换相角度
        {
            TIM1_CR2 = (TIM1_CR2 & (0x80)) | (ANGLE_DTemp - 1); //当前延迟换相角度-1
        }
    }
}

uint8 ceshi = 0;
uint16 Run_post = 0;
void AGS_Move(uint8 post)
{
    // static
    int16 test_post1 = 0, test_post2 = 0;
    switch (Uset.Run_flag)
    {
    case 0: /*电机接收到新的位置信息*/
    {
        if ((AGS_DATA.MoveStatus == 0) && (Uset.run_time == 0) && ((post <= 100))) /* 等待电机停止运行 */
        {
            Uset.Vsp_post = Uset.Max_post / 100.0 * post; /* 计算本次需要移动到的位置 */
            if ((Uset.Vsp_post > (Uset.New_post + 60)) || (Uset.Vsp_post < (Uset.New_post - 60)))
            {
                Run_post = post;

                Uset.Set_post = Uset.Vsp_post; /* 计算需要运行到的位置 */
                if ((post > 0) && (post < 100))
                {
                    Uset.LearnSide_flag = 0; /* 全开边界学习 */
                    if (Uset.Set_post > Uset.New_post)
                    {
                        MotorSpeed.TargetValue = Motor_Run_Speed_BCOR; /* 设置运行关闭的速度 */
                    }
                }
                else
                {
                    if (post == 0)
                    {
                        MotorSpeed.TargetValue = Motor_Start_Speed_BCOR; /* 设置启动运行速度 */
                        Uset.LearnSide_flag = 1;                         /* 全开边界学习 */
                    }
                    else if (post == 100)
                    {
                        Uset.LearnSide_flag = 2;                       /* 全开边界学习 */
                        MotorSpeed.TargetValue = Motor_Run_Speed_BCOR; /* 设置运行duty */
                    }
                }
                Uset.run_time = 15000;    /* 设置最长运行时间15s */
                Voltage_Compensa();       /* 根据当前母线电压对运行duty进行补偿 */
                MotorSpeed.FlagONOFF = 1; /* 运行标志位施使能 */
                Uset.Post_time = 100;     /*延迟一段时间等待电机正确换向*/
                Uset.Run_flag = 1;        /* 进入到减速区域 */
                StallFault = 0;           /* 清除堵转故障 */
            }
        }
    }
    break;

    case 1: /* 启动加速阶段结束 */
    {
        if (FR ? (Uset.New_post > (STEP_POST * 20)) : 1) /* 减速阶段的误差按照10°计算 */
        {
            MotorSpeed.TargetValue = Motor_Run_Speed_BCOR; /*降低电机运行的速度*/
            Uset.Run_flag = 2;
        }
        if (StallFault == 1) /*减速之前发生堵转认为 有堵转事件发生*/
        {
            Uset.Run_flag = 3; /* 进入到3进行堵转判断 */
        }
        if ((Run_post != post) && (post <= 100)) /* 运行过程中接收到反方向的指令 */
        {
            Uset.Run_flag = 11; /* 运行换向 */
        }
    }
    break;

    case 2: /* 电机减速区域减速大约12度 */
    {
        if (FR ? (Uset.Set_post <= (Uset.New_post + AGS_15)) : ((Uset.Set_post + AGS_15) >= Uset.New_post)) /* 减速阶段的误差按照10°计算 */
        {
            MotorSpeed.TargetValue = Motor_Arrive_Speed_BCOR; // Motor_Run_Speed_BCOR;// Motor_Arrive_Speed_BCOR; /*降低电机运行的速度*/
            Uset.Run_flag = 3;
        }
        if (StallFault == 1) /*减速之前发生堵转认为 有堵转事件发生*/
        {
            Uset.Run_flag = 3; /* 进入到3进行堵转判断 */
        }
        if ((Run_post != post) && (post <= 100)) /* 运行过程中接收到反方向的指令 */
        {
            Uset.Run_flag = 11; /* 运行换向 */
        }
    }
    break;

    case 3:
    {                            /*  超过限位50度  或运行时间超过15s  找不到限位 机械故障-----未检测到机械限位  */
        if (Uset.LearnSide_flag) /* 运行到边界 */
        {
            if (Uset.Run_cont == 0) /* 正常运行 */
            {
                test_post1 = AGS_20;
                test_post2 = AGS_20;
            }
            else if (Uset.Run_cont == 1) /* 堵转返回 */
            {

                if (FR)
                {
                    test_post1 = 0;
                    test_post2 = AGS_20;
                }
                else
                {
                    test_post1 = AGS_20;
                    test_post2 = 0;
                }
            }

            if (StallFault == 1) /* 一直等到堵转触发 */
            {
                if (FR ? ((Uset.Max_post - test_post1) < Uset.New_post) : (test_post2 >= Uset.New_post)) /* 堵转发生在合理的范围之内 */
                {
                    StallFault = 0;    /* 正常运转清除堵转清除堵转 */
                    Uset.Run_flag = 4; /* 进入反转状态 */
                    if (One_flag == 0) /* 防止双向堵转后 再次正常运行 */
                        One_flag++;    /* 标志位清空 */

                    if (Uset.Run_cont == 0)
                        Uset.Stall_cont = 0; /* 清除堵转计数 */

                    if (Uset.Run_cont == 0)
                    {
                        TargetCnt = 3;
                    }
                }
                else /* 堵转发生在异常的范围 */
                {
                    // Uset.Run_flag = 0x0f; /* 进入堵转状态堵转异常事件 */
                }
                Brake_STOP;          /* 锁定电机 */
                Uset.run_time = 100; /* 清除计数周期 */
            }
            /*  位置全开或全关，限位20度时找不到限位 机械故障 */
            // if (FR ? ((Uset.Max_post + AGS_40) <= Uset.New_post) : (0 >= Uset.New_post + AGS_40))
            if ((Uset.run_time <= 0) && (AGS_DATA.MoveStatus > 0))
            {
                MotorSpeed.FlagONOFF = 0;          /* 关闭电机 */
                Uset.run_time = 0;                 /* 清除计数周期 */
                AGS_DATA.SelflearnStatus = 2;      /* 自学习状态失败 */
                AGS_DATA.FaultMechanicalBreak = 1; /* 边界故障报警 */
                Uset.Run_flag = 0x0f;              /* 边界故障进入 */
            }
            else if ((Uset.run_time == 0) && (AGS_DATA.MoveStatus == 0) && (3 == Uset.Run_flag))
            {
                MotorSpeed.FlagONOFF = 0;
                Uset.Run_flag = 0x0f;
            }
        }
        else /* 运行到中间位置 */
        {
            if (FR ? (Uset.Set_post <= Uset.New_post) : (Uset.Set_post >= Uset.New_post)) /* 等待运行到设定位置开始停机 */
            {
                Uset.Run_flag = 12; /* 再次回到vcu位置指令中 */
                BEMF_STOP;          /* 手动检测模式 */
                if (Uset.Run_cont == 0)
                    Uset.Stall_cont = 0; /* 清除堵转计数 */
                Uset.run_time = 0;       /* 清除计数周期 */
            }
            if (StallFault == 1) /* 一直等到堵转触发 */
            {
                Brake_STOP;           /* 锁定电机 */
                Uset.Run_flag = 0x0f; /* 进入堵转状态堵转异常事件 */
                Uset.run_time = 0;    /* 清除计数周期 */
            }
        }
    }
    break;

    case 4: /* 电机回退 */
    {
        if (Uset.run_time == 0)
        {
            if (Uset.LearnSide_flag == 1)
            {
                Uset.New_post = 0 - AGS_7;
            }
            else
            {
                Uset.New_post = Uset.Max_post + AGS_7;
            }
            MotorSpeed.FlagONOFF = 1; /* 关闭电机 */
            Uset.Run_flag = 5;        /* 停机等待 */
            Uset.run_time = 5000;
        }
    }
    break;

    case 5: /* 电机回退到位 */
        if (FR ? ((Uset.Set_post) <= Uset.New_post) : (Uset.Set_post >= (Uset.New_post)))
        {                       /* 正常运行到达指定位置 */
            Uset.Run_flag = 12; /* 停机等待 */
            BEMF_STOP;          /* 手动检测模式 */
            Uset.Run_cont = 0;  /* 堵转次数清空 */
        }
        if (StallFault == 1) /* 电机发生堵转, */
        {
            StallFault = 0;
            ceshi = 1; /* 调试用的变量 */
        }
        break;

    case 11: /* 电机运行中接收到新的位置，换向运行 */
    {
        if (Run_post != post) /* 换向运行时候停机 */
        {
            Brake_STOP;          /* 锁定电机 */
            Uset.run_time = 200; /* 锁定200ms */
            Uset.Run_flag = 0;   /* 学习边界位置 堵转后重新设置当前位置不认为堵转 */
        }
    }
    break;

    case 12: /* 电机运行结束 等待到新的位置信息 */
    {
        if (Run_post != post) /* 运行正常时候停机 */
        {
            Uset.run_time = 200; /* 锁定200ms */
            Uset.Run_flag = 0;   /* 学习边界位置 堵转后重新设置当前位置不认为堵转 */
        }
    }
    break;

    case 13: /* 电机运行堵转 回退等待区域 */
    {
        if (Run_post != post) /* 运行正常时候停机 */
        {
            Uset.run_time = 200; /* 锁定200ms */
            Uset.Run_flag = 0;   /* 学习边界位置 堵转后重新设置当前位置不认为堵转 */
        }
    }
    break;

    case 0x0f: /* 电机运行异常，包括堵转，和挡点丢失 */
    {
        MotorSpeed.FlagONOFF = 0; /* 关闭电机 */
        Brake_STOP;               /* 锁定电机 */
        if (Run_post != post)     /* 运行正常时候停机 */
        {
            One_flag = 0;
            Uset.run_time = 200; /* 锁定200ms */
            Uset.Run_flag = 0;   /* 学习边界位置 堵转后重新设置当前位置不认为堵转 */
        }
    }
    break;

    default:

        break;
    }
}

/*****************************************************************************
    \brief          : AGS_Detection 故障检测 AGS_Fault
    \param          : None
    \retval         : None
*****************************************************************************/
void AGS_Detection(void)
{
    Fault_OverTemp();         //温度传感器检测+电机过热检测
    Fault_OverUnderVoltage(); //过压欠压检测 电压检测电路
}

/*****************************************************************************
    \brief          : AGS_handle 电机运行函数
    \param          : None
    \retval         : None
*****************************************************************************/

void AGS_handle(void)
{
    static uint8 stallflag = 0; //发送故障打开AGS时候的运行标志位

    if (Lin.Sleep_flag) /* 接收到休眠指令 */
    {
        if ((AGS_DATA.MoveStatus == 0) && (AGS_SelfLearn.LearnFlag >= 15)) /* 等待运行结束或者自学习结束 */
        {
            GP07 = 0;
            PowerOFF; /* 断电 */
        }
    }
    /*AGs故障时打开格栅  总线通信错误 过压故障，欠压故障，过温故障*/
    if ((mcFaultSource == FaultUnderVoltage) || (mcFaultSource == FaultOverVoltage) || (mcFaultSource == FaultOverTemp)) /* 二级电机保护关闭输出 */
    {
        MotorSpeed.FlagONOFF = 0; /*  关闭电机 */
        stallflag = 0;
        Uset.Run_flag = 0x0c;
        Uset.run_time = 200;
        TargetCnt = 0;
    }
    else /* 无故障电机正常运行 */
    {
        switch (Uset.Run_cont)
        {
        case 0: /* 默认情况是一直正常运行 */
        {
            AGS_Move(AGS_DATA.VCU_Target1); /* 电机运行函数 正常运行 */

            if (Uset.Run_flag == 12) /* 运行检测到堵转 */
            {
                // Uset.Stall_cont = 0; /* 堵转计数加1 */
            }
            if (StallFault && (Uset.Run_flag == 3) && (Uset.run_time <= 100)) /* 运行检测到堵转 */
            {
                if (One_flag == 0) /* 第一次运行堵转不能反偏 */
                {
                    One_flag++;           /* 首次运行标志位清空 */
                    Brake_STOP;           /* 锁定电机 */
                    Uset.Run_flag = 4;    /* 开始反偏操作 */
                    Uset.run_time = 200;  /* 开始反偏操作 */
                    StallFault = 0;       /* 清除堵转事件 */
                    BL_S.BLDCSetFlag = 0; /* 防止再次进入堵转 */
                    if (FR == CLOSE)
                    {
                        Uset.New_post = Uset.Max_post;
                        Uset.Set_post = Uset.Max_post;
                    }
                    else
                    {
                        Uset.New_post = 0;
                        Uset.Set_post = 0;
                    }
                }
                else
                {
                    Uset.Stall_cont++; /* 堵转计数加1 */
                    if (Uset.Stall_cont > 4)
                    {
                        Brake_STOP;         /* 反偏运行一下防止反弹 */
                        StallFault = 0;     /* 清除堵转 */
                        Uset.Run_flag = 11; /* 进入换向等待 */
                        Uset.Run_cont = 2;  /* 进入下个状态反偏运行一下 */
                        if (FR == CLOSE)    /* 停机之前先反转一点角度 */
                        {
                            AGS_DATA.VCU_Target1 = (100.0 * Uset.New_post / Uset.Max_post) - 5;
                        }
                        else
                        {
                            AGS_DATA.VCU_Target1 = (100.0 * Uset.New_post / Uset.Max_post) + 5;
                        }
                        Uset.ManualDelayTime = 40000; /* 手动模式会延时，总线收到合理指令会清空这个计数器 */
                    }
                    else
                    {
                        Uset.Run_cont = 1;    /* 进入堵转事件 */
                        StallFault = 0;       /* 清除堵转事件 */
                        BL_S.BLDCSetFlag = 0; /* 防止再次进入堵转 */
                        Uset.Run_flag = 13;   /* 开始再次启动运行 */
                                              // BEMF_STOP;            /* 锁步不能进入检测模式 */
                        if (FR == CLOSE)      /* 反方向回到原点 */
                        {
                            AGS_DATA.VCU_Target1 = 0; /* 关闭方向堵转，转向打开 */
                        }
                        else
                        {
                            AGS_DATA.VCU_Target1 = 100; /* 打开方向堵转，转向关闭 */
                        }
                    }
                    /* 判断手动模式》5次停止手动操作响应 */
                }
            }
        }
        break;

        case 1: /* 首次堵转 回退到堵转点 */
        {
            AGS_Move(AGS_DATA.VCU_Target1);                                       /* 电机运行函数 */
            if ((StallFault && (Uset.Run_flag == 3) && (Uset.run_time <= 100)) || /* 回退堵转 */
                (Uset.Run_flag == 12))                                            /* 回退正常运行 */
            {
                if (Uset.Run_flag == 12) /* 堵转回退正常运行 */
                {
                    BEMF_STOP;         /* 手动检测模式 */
                    Uset.Run_cont = 0; /* 返回到正常运行状态 */
                }
                else /* 堵转回退再次遇到堵转 */
                {
                    Brake_STOP;         /* 反偏运行一下防止反弹 */
                    StallFault = 0;     /* 清除堵转 */
                    Uset.Run_flag = 11; /* 进入换向等待 */
                    Uset.Run_cont = 2;  /* 进入下个状态反偏运行一下 */
                    if (FR == CLOSE)    /* 停机之前先反转一点角度 */
                    {
                        AGS_DATA.VCU_Target1 = (100.0 * Uset.New_post / Uset.Max_post) - 5;
                    }
                    else
                    {
                        AGS_DATA.VCU_Target1 = (100.0 * Uset.New_post / Uset.Max_post) + 5;
                    }
                }
            }
        }
        break;

        case 2:                             /* 回退堵转后进行反偏动作 */
            AGS_Move(AGS_DATA.VCU_Target1); /* 电机运行函数 */
            if (Uset.Run_flag == 12)        /* 堵转回退正常运行 */
            {
                BEMF_STOP;         /* 手动检测模式 */
                Uset.Run_cont = 0; /* 返回到正常运行状态 */
                TargetCnt = 0;     /* 手动检测模式 */
            }
            break;

        default:
            break;
        }
    }
}
/*****************************************************************************
    \brief          : 1ms运行的app
    \param          : None
    \retval         : None
*****************************************************************************/
void app(void)
{
    /*ADC数据读取*/
    if (StickTime == 0)
    {
        mcFocCtrl.mcIbusADC = ADC2_DR;                      /* RC滤波后的母线电流读取*/
        if (mcFocCtrl.mcIbusADC > mcCurOffset.Iw_busOffset) /*减去偏置电压*/
        {
            mcFocCtrl.mcIbusADC = mcFocCtrl.mcIbusADC - mcCurOffset.Iw_busOffset;
        }
        else
        {
            mcFocCtrl.mcIbusADC = 0;
        }

        LPF_MDU(mcFocCtrl.mcIbusADC, 30, mcFocCtrl.mcIbusFlt, mcFocCtrl.mcIbusFlt_LSB); /*对电流进行滤波*/
        LPF_MDU(ADC0_DR, 10, mcFocCtrl.mcNtcTempFlt, mcFocCtrl.mcNtcTempFlt_LSB);       /*读取NTC电压 */
        LPF_MDU(ADC14_DR, 10, mcFocCtrl.mcDcbusFlt, mcFocCtrl.mcDcbusFlt_LSB);          /*母线电压读取，过欠压保护使用 */

        AGS_Detection();    /*故障检测和保护*/
        StarRampDealwith(); /*延迟换相角度+续流屏蔽角度 调整*/

        if (AGS_SelfLearn.LearnFlag < 15) /*自学习没有完成 ，继续自学习*/
        {
            Self_Learn(); /*自学习*/
        }
        else
        {
            AGS_handle(); /*接收数据处理*/
        }
        StickTime = 1;
    }

    if ((Uset.ManualDelayTime > 0) && (Uset.ManualDelayTime < 3))
    {
        BEMFDetect.BEMFRun = 0;
    }
    if (BEMFDetect.BEMFState == 3) /* 检测到手动的换向次数满足要求，开始进入自动运行模式 */
    {
        BEMFDetect.BEMFState = 0;
        if (Uset.ManualDelayTime == 0)
        {
            /* 清除检测的状态机 */
            if (BEMFDetect.FRStatus == CW) /* 按照转动的方向确定电机转动的方向 */
            {
                AGS_DATA.VCU_Target1 = 100; /* 设置全关 */
                Uset.run_time = 0;
                CurrentManualDirection = CW;
                if ((Uset.New_post > (Uset.Max_post - 50)) && (Uset.New_post < (Uset.Max_post + 50)))
                {
                    One_flag = 0; /* 到位之后手动可以再次触发 */
                }
            }
            else if (BEMFDetect.FRStatus == CCW) /* 设置反向运行 */
            {
                AGS_DATA.VCU_Target1 = 0; /* 设置全开 */
                Uset.run_time = 0;
                CurrentManualDirection = CCW;
                if ((Uset.New_post < (0 - 50)) && (Uset.New_post < 50))
                {
                    One_flag = 0; /* 到位之后手动可以再次触发 */
                }
            }
            One_flagsys(AGS_DATA.VCU_Target1);
        }
        else
        {
            //等待堵转停止
        }
    }
}

/*  -------------------------------------------------------------------------------------------------
    Function Name  : Voltage_compensation
    Description    : 电压补偿，根据电压对运行duty进行补偿
    Date           :
                   : [输入]
    ------------------------------------------------------------------------------------------------- */
void Voltage_Compensa(void)
{
    //    /* 电压补偿范围 最大补偿0.15，高压减小0.1  ，13.5V使用默认duty*/
    //    uint16 Compensa = 0;
    //    if (mcFocCtrl.mcDcbusFlt < UNDER_RECOVER_VALUE)
    //    {
    //        Compensa = (uint16)((0.18) * PWM_VALUE_LOAD); /* 电压太低最大补偿 */
    //    }
    //    else if (mcFocCtrl.mcDcbusFlt > OVER_RECOVER_VALUE)
    //    {
    //        Compensa = 0; /* 电压太高不做补偿 */
    //    }
    //    else /* 动态电压补偿 */
    //    {
    //        {
    //            Compensa = ((OVER_RECOVER_VALUE - mcFocCtrl.mcDcbusFlt) / (ONE_VALUE * 1.0)) * AGS_COMP_Duty;
    //        }
    //    }
    //    /*设置运行的扭矩*/

    //    if (2 == AGS_DATA.VCU_TorqueCommand1) /*设置AGS运动力矩*/
    //    {
    //        Uset.Run_duty = AGS_RUN1_Duty + Compensa; /*设置AGS运动正常力矩*/
    //    }
    //    else if (0 == AGS_DATA.VCU_TorqueCommand1)
    //    {
    //        Uset.Run_duty = AGS_RUN3_Duty + Compensa; /*设置AGS运动增强力矩2*/
    //    }
}

/*  -------------------------------------------------------------------------------------------------
    Function Name  : LIN_list
    Description    : 总线接收发送列表设置
    Date           :
                   : [输入]
    ------------------------------------------------------------------------------------------------- */

void LIN_list(uint8 PID)
{
    uint8 i = 0;
    uint16 ibud = 0;
    uint8 LIN_ID1 = 0;
    Lin.Time4s = 4000;

    /* 发送的数值是个变量，无法使用 switch*/
    if ((PID == 0x08) || (PID == 0xA8))
    {
        Lin.RUN_flag = 13; /*根据数据头判断是接收数据  LIN_flag = 3 ，发送数据 ，不需要回应数据*/
        Lin.Leng = 8;      /*填写需要接收的数据长度*/
        Lin.CheckMode = 1; /*增强型校验*/
    }
    else if ((PID == 0x78) || (PID == 0x49))
    {
        if (((PID == 0x78) && (Uset.ID != 1)) || ((PID == 0x49) && (Uset.ID != 2)))
        {
            Cutover_IO;
            return;
        }
        Lin.RUN_flag = 23; /*根据数据头判断是接收数据  LIN_flag = 3 ，发送数据 ，不需要回应数据*/
        Lin.Leng = 8;      /*填写需要接收的数据长度*/
        Lin.CheckMode = 1; /*增强型校验*/

        if (Uset.New_post <= 0)
        {
            if ((Uset.Run_flag == 0xc) && (mcFocCtrl.State_Count == 0)) /* 再次回到vcu位置指令中 */
            {
                Lin.SData[0] = 0;
            }
            else
            {
                Lin.SData[0] = 1;
            }
        }
        else if (Uset.New_post >= Uset.Max_post)
        {
            if ((Uset.Run_flag == 0xc) && (mcFocCtrl.State_Count == 0)) /* 再次回到vcu位置指令中 */
            {
                Lin.SData[0] = 100;
            }
            else
            {
                Lin.SData[0] = 99;
            }
        }
        else
        {
            Lin.SData[0] = (unsigned char)(((Uset.New_post) * 100.0) / (Uset.Max_post)); /* 输出的位置参数 */
            if (((AGS_DATA.VCU_Target1 > Lin.SData[0] ? (AGS_DATA.VCU_Target1 - Lin.SData[0]) : (Lin.SData[0] - AGS_DATA.VCU_Target1)) <= 3))
            {
                Lin.SData[0] = AGS_DATA.VCU_Target1;
            }
        }

        if (Lin.Err > 2)
        {
            AGS_DATA.FaultCommunicationError = 1; /*LIN总线错误*/
        }

        Lin.SData[1] = (((AGS_DATA.VCU_TorqueCommand1) & 0x0f) | (AGS_DATA.TorqueResponse > 0 ? 0x10 : 0) | (AGS_DATA.MoveStatus > 0 ? 0x20 : 0) | (AGS_DATA.SelflearnStatus > 0 ? 0x40 : 0) | (AGS_DATA.VCU_Self1 > 0 ? 0x80 : 0));
        Lin.SData[2] = (AGS_DATA.FaultMechanicalBreak > 0 ? 0x01 : 0) | (AGS_DATA.FaultStall > 0 ? 0x02 : 0) | (AGS_DATA.FaultElectronic > 0 ? 0x04 : 0) | (AGS_DATA.FaultUnderVoltage > 0 ? 0x08 : 0) | (AGS_DATA.FaultOverVoltage > 0 ? 0x10 : 0) | (AGS_DATA.FaultOverheat > 0 ? 0x20 : 0) | (AGS_DATA.FaultCommunicationError > 0 ? 0x40 : 0);

        ibud = DRV_DR;
        // Lin.SData[2] =SPED2>>8;
        Lin.SData[3] = AGS_DATA.VCU_Target1;
        Lin.SData[4] = AGS_SelfLearn.LearnFlag;
        Lin.SData[5] = AGS_DATA.MoveStatus;
        Lin.SData[6] = One_flag;
        Lin.SData[7] = AGS_SelfLearn.LearnFlag;

        LIN_transmit();
    }

    else if (PID == 0x3C)
    {
        Lin.RUN_flag = 13; /*根据数据头判断是接收数据  LIN_flag = 3 ，发送数据 ，不需要回应数据*/
        Lin.Leng = 8;      /*填写需要接收的数据长度*/
        Lin.CheckMode = 0; /*普通型校验*/
    }
    else if (PID == 0x7d)
    {
        if (LinBack)
        {
            Lin.RUN_flag = 23; /*根据数据头判断是接收数据  LIN_flag = 3 ，发送数据 ，不需要回应数据*/
            Lin.Leng = 8;      /*填写需要接收的数据长度*/
            Lin.Count = 0;     /*清空计数*/
            Lin.CheckMode = 0; /*普通型校验*/

            Lin.SData[3] = 0xFf;
            Lin.SData[4] = 0xff;
            Lin.SData[5] = 0xff;
            Lin.SData[6] = 0xff;
            Lin.SData[7] = 0xff;
            LIN_transmit();
        }
        else
        {
            Cutover_IO;
        }
    }
    //    else if ((PID == 0x47)||(PID == 0xF0))
    //    {
    //        Cutover_IO;
    //    }
    else
    {
        Cutover_IO;
        //		Lin.RUN_flag = 14; /*根据数据头判断是接收数据  LIN_flag = 3 ，发送数据 ，不需要回应数据*/
        //        Lin.Leng = 8;      /*填写需要接收的数据长度*/
        //        Lin.CheckMode = 0; /*普通型校验*/
    }
}

/*  -------------------------------------------------------------------------------------------------
    Function Name  : ReceiveSYS
    Description    : 总线接收数据处理
    Date           :
                   : [输入]
    ------------------------------------------------------------------------------------------------- */
void ReceiveSYS(uint8 PID)
{

    uint8 temp = 0;

    if (((Uset.ID == 2) && (PID == 0x08)) || ((Uset.ID == 1) && (PID == 0xA8)))
    {
        if (Lin.Data[0] < 101)
        {
            // AGS_DATA.FaultCommunicationError = 0; /* 正确接收到到指令或发送指令 清空总线错误 */
            AGS_DATA.VCU_Target1 = Lin.Data[0];
            One_flagsys(AGS_DATA.VCU_Target1);
        }

        if (Lin.Data[0] < 101)
        {
            Uset.ManualDelayTime = 0;
            PreManualDirection = 2;
            CurrentManualDirection = 2;
            Uset.Stall_cont = 0;
        }
        temp = Lin.Data[1];                               /* AGS 自学习指令 */
        AGS_DATA.VCU_TorqueCommand1 = (temp >> 2) & 0x0F; /* VCU扭矩命令 */

        if ((temp & 0x02) && (AGS_SelfLearn.LearnFlag >= 15)) /* 接收到自学习指令，且当前状态为自学习成功或者自学习失败 */
        {
            AGS_DATA.VCU_Self1 = 1;
            AGS_SelfLearn.LearnFlag = 0;
            One_flag = 0;
        }

        AGS_DATA.FaultCommunicationError = 0; /* 正确接收到到指令或发送指令 清空总线错误 */
    }
    else if (PID == 0x3c) /* 诊断信号 */
    {

        if ((Lin.Data[0] == 0x00) && (Lin.Data[1] == 0xFF) &&
            (Lin.Data[2] == 0xFF) && (Lin.Data[3] == 0xFF) &&
            (Lin.Data[4] == 0xFF) && (Lin.Data[5] == 0xFF) &&
            (Lin.Data[6] == 0xFF) && (Lin.Data[7] == 0xFF))
        {
            Lin.Time4s = 20;
            Lin.Sleep_flag = 1; /* 保存数据开始休眠 */
        }

        if ((Lin.Data[0] == 0x00) && (Lin.Data[1] == 0x02) &&
            (Lin.Data[2] == 0x10) && (Lin.Data[3] == 0x02) &&
            (Lin.Data[4] == 0xff) && (Lin.Data[5] == 0xff) &&
            (Lin.Data[6] == 0xff) && (Lin.Data[7] == 0xff))
        { /* 进入编程模式：APP必须要包含此操作，不然回不到boot */
            EnterBootCnt++;
            if (EnterBootCnt > 1)
            {
                Flash_Sector_Erase(MAIN_RUN); /* 擦除运行标志位扇区 */
                SetBit(RST_SR, SOFTR);        /* 复位进入boot */
            }
        }

        if ((Lin.Data[0] == 0x7f) && (Lin.Data[1] == 0x06) &&
            (Lin.Data[2] == 0xB7) && (Lin.Data[3] == 0x00))
        {
            if ((Lin.Data[4] == 0x08) && (Lin.Data[5] == 0x49) && (Uset.ID != 2))
            {
                WriteDeviceAddress(0x0849); //没有boot先注掉
                Uset.ID = 2;
            }
            else if ((Lin.Data[4] == 0xA8) && (Lin.Data[5] == 0x78) && (Uset.ID != 1))
            {
                WriteDeviceAddress(0xA878); //没有boot先注掉
                Uset.ID = 1;
            }
            LinBack = 0x01;
            Lin.SData[0] = 0x01;
            Lin.SData[1] = 0x01;
            Lin.SData[2] = 0xF7;
        }

        AGS_DATA.FaultCommunicationError = 0; /* 正确接收到到指令或发送指令 清空总线错误*/
    }
}

void One_flagsys(uint8 Target1)
{

    static uint8 OldTarget = 0; /* 连续接收计数 */

    /*     if (Target1 != OldTarget)
        {
            if (TargetCnt < 10)
                TargetCnt = TargetCnt + 1;
        } */
    if (TargetCnt < 3)
    {
        One_flag = 0;
    }
    OldTarget = Lin.Data[0];

    if ((One_flag == 0) && (AGS_SelfLearn.LearnFlag >= 15) && (AGS_DATA.MoveStatus == 0))
    {
        if (AGS_DATA.VCU_Target1 == 0)
        {
            Uset.New_post = Uset.Max_post;
        }
        else if (AGS_DATA.VCU_Target1 == 100)
        {
            Uset.New_post = 0;
        }
        Run_post = 0x7f;
    }
}
/*  -------------------------------------------------------------------------------------------------
    Function Name  : LIN_transmit
    Description    : lin数据发送
    Date           :
                   : [输入]
    ------------------------------------------------------------------------------------------------- */
void LIN_transmit(void)
{
    if ((!Lin.Sleep_flag)) /*lin发送时间较长4.5ms，不放入中断*/
    {
        /*使用dma发送，减少发送数据被打断*/
        Lin.Check = LinCheck(Lin.CheckMode, Lin.PID, Lin.Leng, &Lin.SData); /*计算需要发送的校验和*/
        LIN_Send(&Lin.SData, Lin.Check, Lin.Leng);                          /*发送数据*/
    }
}
