/*  --------------------------- (C) COPYRIGHT 2020 Fortiortech ShenZhen -----------------------------
    File Name      : main.c
    Author         : Ray
    Version        : V1.0
    Date           : 2022-06-13
    Description    :
    ----------------------------------------------------------------------------------------------------
                                       All Rights Reserved
    ------------------------------------------------------------------------------------------------- */
/********************************************************************************

********************************************************************************/
#include <MyProject.h>
#define MAIN_NO_ENPTY 0x0D01
/********************************************************************************
    Internal Routine Prototypes
********************************************************************************/
void HardwareInit(void);
void SoftwareInit(void);
void VREFConfigInit(void);
void DebugSet(void);

void main(void)
{
    /*上电等待*/
    uint16 PowerUpCnt = 0;
    uint8 Frun = 0;
    GPIO_Init(); /* 上电 mcu接管电源 */

    /*ADC参考电压电压配置 5v */
    VREFConfigInit();

    /*硬件初始化*/
    HardwareInit();

    /*软件初始化*/
    SoftwareInit();

    /*总中断使能*/
    /* 初始化定时器2 用来计数 */
    if (*(uint8 *)MAIN_NO_ENPTY) /* 运行标志位已经置1 */
    {
        Frun = 0;
    }
    else
    {
        Frun = 1; /* 写入运行标志位 */ //没有boot要注掉
    }
    AGS_DATA.VCU_Self1 = 0;

    /*基准电压采集*/
    while (mcCurOffset.OffsetFlag == 0) /* 一直等待偏置采集完成 */
    {
        GetCurrentOffset();
    }
    Lin.Time4s = 4000;
    EA = 1;

    while (1)
    {

        if (WatchDogtime == 0) /*喂狗时间50ms*/
        {
            WatchDogtime = 50;
            WatchDogRefresh(); /*喂狗*/ //没有boot要注掉
            if (Frun)                   //没有boot要注掉
            {                           //没有boot要注掉
//			 Flash_Sector_Write(MAIN_NO_ENPTY, 0x55); /* 写入运行标志 *///没有boot要注掉
//			 SetBit(RST_SR, SOFTR);                  /* 回复完成进入软件复位 *///没有boot要注掉
			}                           //没有boot要注掉
        }

        //        /*电机控制状态机*/
        MC_Control();
        app();
    }
}

/*  -------------------------------------------------------------------------------------------------
    Function Name  : HardwareInit
    Description    : 硬件初始化
    Date           : 2020-04-12
    Parameter      : None
    ------------------------------------------------------------------------------------------------- */
void HardwareInit(void)
{
    /*看门狗初始化*/
    WatchDogConfig(); /*初始化看门狗*/

    /*比较器3初始化*/
    CMP3_Init(); //用于硬件过流比较保护,可通过 P2.6 引脚观察输出电压是否正确

    /*ADC初始化*/
    ADC_Init(); // 注意：ADC的初始化要放在DRV的初始化以前，否则会导致错误，因为DRV启动会自动触发ADC采样

    /*预驱初始化*/
    Driver_Init();

    /*运放初始化*/
    AMP_Init();

    /*LIN_Init();取消lin初始化*/
    TIM3_Init(); /*串口模拟lin总线 用到的定时器*/
    MODE_IO();   /*使能为LIN端口io模式*/
	
    PI3_Init();
	
	
    /*SYSTICK定时器配置*/
    SetBit(DRV_SR, SYSTIE); // 1ms中断配置
    PSYSTICK1 = 0;
    PSYSTICK0 = 0;
    /*比较器3中断配置*/
    CMP3_Interrupt_Init(); /* 硬件过流中断 */
    /*调试模式初始化*/
}

/*  -------------------------------------------------------------------------------------------------
    Function Name  : SoftwareInit
    Description    : 软件初始化，初始化所有定义变量，按键初始化扫描
    Date           : 2020-04-12
    Parameter      : None
    ------------------------------------------------------------------------------------------------- */
void SoftwareInit(void)
{
    /*程序中使用到的全局变量初始化*/
    MotorcontrolInit();
    /*初始状态机*/
    mcState = mcBrake;   /* 上电检测完等待触发 */
    Uset.Brake_flag = 2; /* 进入手动模式 */
    mcFaultSource = 0;             /*错误状态标志位清0*/
    AGS_SelfLearn.LearnTime = 100; /*上电等待电路检测完成，才开始上止点检测 */

    Uset.Max_post = RedMaxpos(); /* 读取上次存储的学习角度 */
    Uset.ID = ReadDeviceAddress();
    Uset.ManualDelayTime = 0;

    if (Uset.Max_post < 16000)
    {
        AGS_SelfLearn.LearnFlag = 16; /* 没有找到自学习位置 */
        Uset.Max_post = 2714;         // SELF_MAX_POST;
    }
    else
    {
        Uset.Max_post = Uset.Max_post - 16383;
        AGS_SelfLearn.LearnFlag = 15; /* 找到自学习位置 */
    }
    AGS_DATA.VCU_Target1 = 0x7f;  /* 保证上电的位置是0或100 */
	Uset.Run_flag = 0xc;
	//Run_post = AGS_DATA.VCU_Target1;
	//Uset.Max_post =2453;
}

/*  -------------------------------------------------------------------------------------------------
    Function Name  : VREFConfigInit
    Description    : 配置VREF/VHALF输出
    Date           : 2020-04-12
    Parameter      : None
    VREF电压在芯片内部用于ADC的参考电压和DAC的参考电压
    VREFEN：
          0 -- 禁止内部VREF参考，如设置P3_AN[5]=1，外部参考从P3.5输入
                    1 -- 使能内部VREF参考，如设置P3_AN[5]=1，内部VREF参考送出至P3.5引脚，可接0.1～1uF电容提高VREF稳定性

    Q:如果使用内部VREF，不输出至P3.5，该引脚是否能作为普通IO使用？
    A:可以，但是采样精度不如”基准电压4.5V输出+电容“的模式
    ------------------------------------------------------------------------------------------------- */
void VREFConfigInit(void)
{
    /*REF&VHALF Config*/
    SetBit(P3_AN, PIN5); // VREF Voltage -->P35 Output 是否输出到P35引脚
    SetBit(P3_AN, P32);
    ClrBit(P3_OE, P32);
    ClrBit(VREF_VHALF_CR, VRVSEL1);          // 00-->4.5V   01-->VDD5
    SetBit(VREF_VHALF_CR, VRVSEL0);          // 10-->3.0V   11-->4.0V
    SetBit(VREF_VHALF_CR, VREFEN | VHALFEN); // 使能Vref  使能Vhalf
}
