#ifndef __CONTROLLOOP_H_
#define __CONTROLLOOP_H_










extern uint16 xdata ControlLoopOut;



extern void ControlLoop_PIInit(void);
extern void ControlLoopFunction(void);
extern void ControlLoopInit(void);
extern void SpeedLoopFunction(void);
extern void PowerLoopFunction(void);

#endif