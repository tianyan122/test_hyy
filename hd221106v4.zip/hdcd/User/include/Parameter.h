/* --------------------------- (C) COPYRIGHT 2020 Fortiortech ShenZhen -----------------------------
    File Name      : Parameter.h
    Author         : Fortiortech  Appliction Team
    Version        : V1.0
    Date           : 2020-04-11
    Description    : This file contains all FOC debug  parameter used for Motor Control.
----------------------------------------------------------------------------------------------------
                                       All Rights Reserved
------------------------------------------------------------------------------------------------- */
/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __Parameter_H_
#define __Parameter_H_

#include "Develop.h"
#include "FU68xx_4_Type.h"
#include "Customer.h"
/* Q format define ---------------------------------------------------------------------------------*/
#define _Q7(A) (int8)((A) * (128))
#define _Q8(A) (int16)((A) * (256))
#define _Q9(A) (int16)((A) * (512))
#define _Q10(A) (int16)((A) * (1024))
#define _Q11(A) (int16)((A) * (2048))
#define _Q12(A) (int16)((A) * (4096))
#define _Q13(A) (int16)((A) * (8192))
#define _Q15(A) (int16)((A) * (32767))
#define _Q16(A) (int16)((A) * (65535)) // Q15 format
#define _2PI (3.1415926 * 2)           // 2 PI value
#define _Q16 (65535.0)                 // Q16 format value
/* Private define ------------------------------------------------------------*/
#define SystemPowerUpTime (5000) // 上电等待时间，cpu计数时钟

/*芯片参数值------------------------------------------------------------------*/
/*CPU and PWM Parameter*/
#define PWM_CYCLE (1000.0 / PWM_FREQUENCY)                            // 周期us
#define SAMP_FREQ (PWM_FREQUENCY * 1000)                              // 采样频率(HZ)
#define TPWM_VALUE (1.0 / SAMP_FREQ)                                  // 载波周期(S)
#define PWM_VALUE_LOAD (uint16)(MCU_CLOCK * 1000 * 2 / PWM_FREQUENCY) // PWM 定时器重载值 20190514修改

/*deadtime Parameter*/
#define PWM_LOAD_DEADTIME (PWM_DEADTIME * MCU_CLOCK) // 死区设置值

/*硬件板子参数设置值------------------------------------------------------------------*/
/*hardware current sample Parameter*/
/*电流基准的电路参数*/
#define HW_BOARD_CURR_MAX (HW_ADC_REF / 2 / HW_AMPGAIN / HW_RSHUNT) // 最大采样电流,2.702A
#define HW_BOARD_CURR_MIN (-HW_BOARD_CURR_MAX)                      // 最小采样电流,-2.702A
#define HW_BOARD_CURR_BASE (HW_BOARD_CURR_MAX * 2)                  // 电流基准//5.4A

/*hardware voltage sample Parameter*/
/*母线电压采样分压电路参数*/
#define HW_BOARD_VOLT_MAX (HW_ADC_REF * RV)               // (V)  ADC可测得的最大母线电压
#define HW_BOARD_VOLTAGE_BASE (HW_BOARD_VOLT_MAX / 1.732) // 电压基准
#define HW_BOARD_VOLTAGE_VC ((RV1 + RV2 + RV3 * VC1) / (RV3 * VC1))
#define HW_BOARD_VOLTAGE_BASE_Start (HW_ADC_REF * HW_BOARD_VOLTAGE_VC / 1.732) // 电压基准

/*硬件过流保护DAC值*/
#define DAC_OvercurrentValue (0xff+_Q9(I_ValueX((OverHardcurrentValue))))

#define BASE_FREQ ((MOTOR_SPEED_BASE / 60) * Pole_Pairs) // 基准频率

/*电压检测电路故障阈值*/
#define SENSOR_MIN_VALUE _Q15(Sensor_Min_Voltage / HW_BOARD_VOLT_MAX)
#define SENSOR_MAX_VALUE _Q15(Sensor_Max_Vlotage / HW_BOARD_VOLT_MAX)


/*保护参数值------------------------------------------------------------------*/
/* protect value */
#define OVER_PROTECT_VALUE              _Q15((Over_Protect_Voltage-DIODE_Vlotage)  / HW_BOARD_VOLT_MAX)
#define UNDER_PROTECT_VALUE             _Q15((Under_Protect_Voltage-DIODE_Vlotage) / HW_BOARD_VOLT_MAX)
#define OVER_RECOVER_VALUE              _Q15((Over_Recover_Vlotage-DIODE_Vlotage)  / HW_BOARD_VOLT_MAX)
#define LOW_COMPENSA_VALUE              _Q15((Low_MaxVoltalge_Vlotage-DIODE_Vlotage)  / HW_BOARD_VOLT_MAX)
#define UNDER_RECOVER_VALUE             _Q15((Under_Recover_Vlotage-DIODE_Vlotage) / HW_BOARD_VOLT_MAX)
#define OVER_COMPE_VALUE                _Q15((Under_Compensa_Vlotage-DIODE_Vlotage)  / HW_BOARD_VOLT_MAX)

#define V105_VALUE                      _Q15((10.5)  / HW_BOARD_VOLT_MAX)
#define V95_VALUE                       _Q15((9.5)  / HW_BOARD_VOLT_MAX)


#define UNDERV_FLASH                    _Q15((UnderV_flash_Protect-DIODE_Vlotage) / HW_BOARD_VOLT_MAX)  //禁止写flash最低电压
#define OVERV_FLASH                     _Q15((OverV_flash_Protect-DIODE_Vlotage) / HW_BOARD_VOLT_MAX)   //禁止写flash最高电压
#define VLOTAG_DIF                      (OVER_RECOVER_VALUE-UNDER_RECOVER_VALUE) //电压差值用来给运行duty做补偿
#define ONE_VALUE                       _Q15((1.0) / HW_BOARD_VOLT_MAX) //1V电压差值

/*BLS 电机启动运行参数*/
#define MIN_RUN_Duty  (uint16)(Min_RUN_Duty * PWM_VALUE_LOAD)     /* 最小运行duty 闭环使用*/
#define AGS_RUN1_Duty (uint16)(RUN1_Duty * PWM_VALUE_LOAD)       /* 运行正常扭矩*/
#define AGS_RUN2_Duty (uint16)(RUN2_Duty * PWM_VALUE_LOAD)       /* 运行增强1扭矩*/
#define AGS_RUN3_Duty (uint16)(RUN3_Duty * PWM_VALUE_LOAD)       /* 运行增强2扭矩*/
#define AGS_COMP_Duty (uint16)(0.04 * PWM_VALUE_LOAD)            /* 没v电压补偿的duty */

#define AGS_STALL1_Duty (uint16)(Max_Stall1_Duty * PWM_VALUE_LOAD)            /* 堵转判断duty */
#define AGS_STALL2_Duty (uint16)(Max_Stall2_Duty * PWM_VALUE_LOAD)            /* 堵转判断duty */
#define AGS_STALL3_Duty (uint16)(Max_Stall3_Duty * PWM_VALUE_LOAD)            /* 堵转判断duty */
#define AGS_STALL4_Duty (uint16)(Max_Stall4_Duty * PWM_VALUE_LOAD)            /* 堵转判断duty */
#define MAX_BLDC_Duty (uint16)(Max_BLDC_Duty * PWM_VALUE_LOAD)

#define BLDC_K _Q15((float)(MAX_BLDC_Duty - MAX_START_Duty) / (float)(MAXPWMDuty - Max_START_Duty))

/* 电机转速相关参数 */

//重要参数：TIM1的BASE定时器的分频系数——16(100)——1.5Mhz
/*
    • 时钟分频使用PSC表示，在设定完毕PSC以后时钟频率如下：
                                                                              24MHz/psc
    • 电机转速为RPM，计算每个扇区（BLDC一个电周期6个扇区）的频率：
                                                                          (RPM*Pole*6)/60
    •  则一个扇区转过的计数值个数柯如下计算：
                                                                时钟频率/扇区频率= ((24MHz/psc)*10)/(RPM*Pole)


    BCOR*( 1/f ) = 1/( (RPM*Pole*6)/60 )    ——————一个扇区的时间相等建立该等式

    RPM=10f/(BCOR*pole)

    若时钟频率为6M, pole为2, RPM = (10*6000000/2)/BCOR=30000000/BCOR

    将转速标幺到Q15格式，  (RPM/SPEED_BASE)*32767

     Q15_RPM=(10f*32767)/(BCOR*pole*SPEED_BASE)，可以提前计算出 (10f*32767)/(pole*SPEED_BASE)的值，在进行速度计算时直接带入BCOR即可

注意：不同的 TIM1_baseFre 对应的极限转速不同

*/

/*堵转保护*/
#define TIM1_baseFre (6000000.0)






#endif